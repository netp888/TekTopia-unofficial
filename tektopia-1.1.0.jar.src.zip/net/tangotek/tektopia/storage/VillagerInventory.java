/*     */ package net.tangotek.tektopia.storage;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.inventory.InventoryBasic;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.util.Tuple;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.tangotek.tektopia.ModItems;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ 
/*     */ public class VillagerInventory
/*     */   extends InventoryBasic
/*     */ {
/*     */   private final EntityVillagerTek owner;
/*     */   
/*     */   public VillagerInventory(EntityVillagerTek villager, String title, boolean customName, int slotCount) {
/*  27 */     super(title, customName, slotCount);
/*  28 */     this.owner = villager;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public VillagerInventory(ITextComponent title, int slotCount) {
/*  33 */     this((EntityVillagerTek)null, title.func_150260_c(), true, slotCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ItemStack> removeItems(Function<ItemStack, Integer> func, int itemCount) {
/*  41 */     return findItems(func, itemCount, true);
/*     */   }
/*     */   
/*     */   public List<ItemStack> removeItems(Predicate<ItemStack> pred, int itemCount) {
/*  45 */     return findItems(p -> Integer.valueOf(pred.test(p) ? 1 : 0), itemCount, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ItemStack> getItems(Predicate<ItemStack> pred, int itemCount) {
/*  53 */     return findItems(p -> Integer.valueOf(pred.test(p) ? 1 : 0), itemCount, false);
/*     */   }
/*     */   
/*     */   public ItemStack getItem(Function<ItemStack, Integer> func) {
/*  57 */     List<ItemStack> items = findItems(func, 1, false);
/*  58 */     if (!items.isEmpty()) {
/*  59 */       return items.get(0);
/*     */     }
/*  61 */     return ItemStack.field_190927_a;
/*     */   }
/*     */   
/*     */   public List<ItemStack> getItems(Function<ItemStack, Integer> func, int itemCount) {
/*  65 */     return findItems(func, itemCount, false);
/*     */   }
/*     */   
/*     */   public List<ItemStack> getItemsByStack(Function<ItemStack, Integer> func, int itemCount) {
/*  69 */     return findItems(func, itemCount, false);
/*     */   }
/*     */   
/*     */   public int getItemCount(Predicate<ItemStack> pred) {
/*  73 */     return getItemCount(item -> Integer.valueOf(pred.test(item) ? 1 : -1));
/*     */   }
/*     */   
/*     */   public int getItemCount(Function<ItemStack, Integer> func) {
/*  77 */     List<ItemStack> itemList = getItems(func, 0);
/*  78 */     int count = 0;
/*  79 */     for (ItemStack itemStack : itemList) {
/*  80 */       count += itemStack.func_190916_E();
/*     */     }
/*  82 */     return count;
/*     */   }
/*     */   
/*     */   public void cloneFrom(VillagerInventory other) {
/*  86 */     for (int i = 0; i < other.func_70302_i_(); i++) {
/*  87 */       func_174894_a(other.func_70301_a(i));
/*     */     }
/*     */   }
/*     */   
/*     */   public static int countItems(List<ItemStack> items) {
/*  92 */     return items.stream().mapToInt(ItemStack::func_190916_E).sum();
/*     */   }
/*     */   
/*     */   private List<ItemStack> findItems(Function<ItemStack, Integer> func, int itemCount, boolean remove) {
/*  96 */     ArrayList<ItemStack> outList = new ArrayList<>();
/*  97 */     int needed = (itemCount > 0) ? itemCount : Integer.MAX_VALUE;
/*  98 */     List<Tuple<ItemStack, Integer>> matchedItems = new ArrayList<>(); int i;
/*  99 */     for (i = 0; i < func_70302_i_(); i++) {
/* 100 */       ItemStack itemStack = func_70301_a(i);
/* 101 */       if (ModItems.canVillagerSee(itemStack) && (
/* 102 */         (Integer)func.apply(itemStack)).intValue() > 0) {
/* 103 */         matchedItems.add(new Tuple(itemStack, Integer.valueOf(i)));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 109 */     matchedItems.sort(Comparator.comparing(pair -> (Integer)func.apply(pair.func_76341_a())));
/*     */     
/* 111 */     for (i = matchedItems.size() - 1; i >= 0 && needed > 0; i--) {
/* 112 */       Tuple<ItemStack, Integer> pair = matchedItems.get(i);
/* 113 */       ItemStack itemStack = (ItemStack)pair.func_76341_a();
/* 114 */       int slot = ((Integer)pair.func_76340_b()).intValue();
/*     */       
/* 116 */       if (remove) {
/* 117 */         if (itemStack.func_190916_E() <= needed) {
/* 118 */           outList.add(itemStack);
/* 119 */           func_70299_a(slot, ItemStack.field_190927_a);
/* 120 */           needed -= itemStack.func_190916_E();
/*     */         } else {
/*     */           
/* 123 */           itemStack.func_190918_g(needed);
/* 124 */           ItemStack newItem = itemStack.func_77946_l();
/* 125 */           newItem.func_190920_e(needed);
/* 126 */           outList.add(newItem);
/* 127 */           needed = 0;
/* 128 */           onInventoryUpdated(newItem);
/*     */         } 
/*     */       } else {
/*     */         
/* 132 */         outList.add(itemStack);
/* 133 */         needed -= itemStack.func_190916_E();
/*     */       } 
/*     */     } 
/*     */     
/* 137 */     return outList;
/*     */   }
/*     */   
/*     */   private void onInventoryUpdated(ItemStack itemStack) {
/* 141 */     if (this.owner != null && !this.owner.field_70170_p.field_72995_K) {
/* 142 */       this.owner.onInventoryUpdated(itemStack);
/*     */     }
/*     */   }
/*     */   
/*     */   public void deleteOverstock(Item itemOuter, int max) {
/* 147 */     deleteOverstock(p -> (p.func_77973_b() == itemOuter), max);
/*     */   }
/*     */   
/*     */   public void deleteOverstock(Predicate<ItemStack> predicate, int max) {
/* 151 */     int count = 0;
/* 152 */     for (int i = 0; i < func_70302_i_(); i++) {
/* 153 */       ItemStack itemStack = func_70301_a(i);
/*     */       
/* 155 */       if (predicate.test(itemStack)) {
/* 156 */         if (count >= max) {
/* 157 */           func_70299_a(i, ItemStack.field_190927_a);
/*     */         }
/* 159 */         else if (count + itemStack.func_190916_E() > max) {
/* 160 */           itemStack.func_190920_e(max - count);
/* 161 */           onInventoryUpdated(itemStack);
/* 162 */           count = max;
/*     */         } else {
/*     */           
/* 165 */           count += itemStack.func_190916_E();
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean hasSlotFree() {
/* 172 */     for (int i = 0; i < func_70302_i_(); i++) {
/* 173 */       ItemStack itemStack = func_70301_a(i);
/* 174 */       if (itemStack.func_190926_b()) {
/* 175 */         return true;
/*     */       }
/*     */     } 
/* 178 */     return false;
/*     */   }
/*     */   
/*     */   public void mergeItems(VillagerInventory other) {
/* 182 */     for (int i = 0; i < other.func_70302_i_(); i++) {
/* 183 */       ItemStack itemStack = other.func_70301_a(i);
/* 184 */       if (itemStack.func_190926_b()) {
/* 185 */         func_174894_a(itemStack);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_174894_a(ItemStack stack) {
/* 193 */     ItemStack newItem = stack.func_77946_l();
/* 194 */     int emptySlot = -1;
/* 195 */     for (int i = 0; i < func_70302_i_(); i++) {
/*     */       
/* 197 */       ItemStack oldItem = func_70301_a(i);
/*     */       
/* 199 */       if (oldItem.func_190926_b() && emptySlot < 0) {
/*     */         
/* 201 */         emptySlot = i;
/*     */       }
/* 203 */       else if (areItemsStackable(oldItem, newItem)) {
/*     */         
/* 205 */         int j = Math.min(func_70297_j_(), oldItem.func_77976_d());
/* 206 */         int k = Math.min(newItem.func_190916_E(), j - oldItem.func_190916_E());
/*     */         
/* 208 */         if (k > 0) {
/*     */           
/* 210 */           oldItem.func_190917_f(k);
/* 211 */           newItem.func_190918_g(k);
/* 212 */           if (newItem.func_190926_b()) {
/*     */             
/* 214 */             onInventoryUpdated(oldItem);
/* 215 */             func_70296_d();
/* 216 */             return ItemStack.field_190927_a;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 222 */     if (emptySlot >= 0 && !newItem.func_190926_b()) {
/* 223 */       func_70299_a(emptySlot, newItem);
/* 224 */       return ItemStack.field_190927_a;
/*     */     } 
/*     */ 
/*     */     
/* 228 */     if (newItem.func_190916_E() != stack.func_190916_E())
/*     */     {
/* 230 */       func_70296_d();
/*     */     }
/*     */     
/* 233 */     return newItem;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70304_b(int index) {
/* 240 */     ItemStack itemStack = super.func_70304_b(index);
/* 241 */     if (!itemStack.func_190926_b()) {
/* 242 */       onInventoryUpdated(itemStack);
/*     */     }
/*     */     
/* 245 */     return itemStack;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70299_a(int index, ItemStack stack) {
/* 250 */     ItemStack oldItem = func_70301_a(index);
/* 251 */     super.func_70299_a(index, stack);
/*     */     
/* 253 */     if (!oldItem.func_190926_b()) {
/* 254 */       onInventoryUpdated(oldItem);
/*     */     }
/*     */     
/* 257 */     onInventoryUpdated(stack);
/*     */   }
/*     */   
/*     */   public static boolean areItemsStackable(ItemStack itemStack1, ItemStack itemStack2) {
/* 261 */     if (ItemStack.func_179545_c(itemStack1, itemStack2) && 
/* 262 */       ItemStack.func_77970_a(itemStack1, itemStack2)) {
/* 263 */       return true;
/*     */     }
/*     */     
/* 266 */     return false;
/*     */   }
/*     */   
/*     */   public void debugSpam() {
/* 270 */     for (int i = 0; i < func_70302_i_(); i++) {
/* 271 */       ItemStack itemStack = func_70301_a(i);
/* 272 */       if (!itemStack.func_190926_b())
/* 273 */         System.out.println("    Item: " + itemStack.toString()); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void writeNBT(NBTTagCompound compound) {
/* 278 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/* 280 */     for (int i = 0; i < func_70302_i_(); i++) {
/*     */       
/* 282 */       ItemStack itemstack = func_70301_a(i);
/*     */       
/* 284 */       if (!itemstack.func_190926_b())
/*     */       {
/* 286 */         nbttaglist.func_74742_a((NBTBase)itemstack.func_77955_b(new NBTTagCompound()));
/*     */       }
/*     */     } 
/*     */     
/* 290 */     compound.func_74782_a("Inventory", (NBTBase)nbttaglist);
/*     */   }
/*     */   
/*     */   public void readNBT(NBTTagCompound compound) {
/* 294 */     func_174888_l();
/* 295 */     NBTTagList nbttaglist = compound.func_150295_c("Inventory", 10);
/*     */     
/* 297 */     for (int i = 0; i < nbttaglist.func_74745_c(); i++) {
/*     */       
/* 299 */       ItemStack itemstack = new ItemStack(nbttaglist.func_150305_b(i));
/*     */       
/* 301 */       if (!itemstack.func_190926_b())
/*     */       {
/* 303 */         func_174894_a(itemstack);
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\storage\VillagerInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */