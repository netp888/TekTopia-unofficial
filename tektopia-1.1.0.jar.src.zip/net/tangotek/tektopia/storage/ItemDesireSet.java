/*     */ package net.tangotek.tektopia.storage;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntityChest;
/*     */ import net.tangotek.tektopia.VillageManager;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ import net.tangotek.tektopia.entities.crafting.Recipe;
/*     */ 
/*     */ 
/*     */ public class ItemDesireSet
/*     */ {
/*  15 */   protected List<ItemDesire> itemDesires = new ArrayList<>();
/*     */   protected boolean deliveryDirty = true;
/*  17 */   protected int deliveryId = 0;
/*  18 */   protected byte deliverySlot = -1;
/*  19 */   protected short deliveryCount = 0;
/*  20 */   protected int totalDeliverySize = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  27 */     this.itemDesires.clear();
/*     */   }
/*     */   
/*     */   public void addItemDesire(ItemDesire desire) {
/*  31 */     this.itemDesires.add(desire);
/*     */   }
/*     */   
/*     */   public void addRecipeDesire(Recipe r) {
/*  35 */     for (ItemStack need : r.getNeeds()) {
/*     */       Predicate<ItemStack> pred;
/*  37 */       if (need.func_77960_j() == 99) {
/*  38 */         pred = (p -> (p.func_77973_b() == need.func_77973_b() && !p.func_77948_v()));
/*     */       } else {
/*  40 */         pred = (p -> (ItemStack.func_179545_c(p, need) && !p.func_77948_v()));
/*     */       } 
/*  42 */       Predicate<EntityVillagerTek> shouldNeed = p -> p.isAIFilterEnabled(r.getAiFilter());
/*  43 */       if (r.shouldCraft != null) {
/*  44 */         shouldNeed = shouldNeed.and(r.shouldCraft);
/*     */       }
/*  46 */       addItemDesire(new ItemDesire(need.func_77973_b().func_77658_a(), pred, need.func_190916_E(), need.func_190916_E() * r.idealCount, need.func_190916_E() * r.limitCount, shouldNeed));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void forceUpdate() {
/*  51 */     this.itemDesires.forEach(d -> d.forceUpdate());
/*  52 */     this.deliveryDirty = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStorageUpdated(EntityVillagerTek villager, ItemStack storageItem) {
/*  57 */     this.itemDesires.forEach(d -> d.onStorageUpdated(villager, storageItem));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onInventoryUpdated(EntityVillagerTek villager, ItemStack updatedItem) {
/*  62 */     this.itemDesires.forEach(d -> d.onInventoryUpdated(villager, updatedItem));
/*  63 */     this.deliveryDirty = true;
/*     */   }
/*     */   
/*     */   public ItemDesire getNeededDesire(EntityVillagerTek villager) {
/*  67 */     for (ItemDesire d : this.itemDesires) {
/*  68 */       if (d.shouldPickUp(villager)) {
/*  69 */         return d;
/*     */       }
/*     */     } 
/*     */     
/*  73 */     return null;
/*     */   }
/*     */   
/*     */   private void updateDeliveryList(EntityVillagerTek villager) {
/*  77 */     if (this.deliveryDirty && villager.hasVillage()) {
/*  78 */       this.deliverySlot = -1;
/*  79 */       this.deliveryCount = 0;
/*  80 */       this.totalDeliverySize = 0;
/*  81 */       int bestValue = 0;
/*     */       
/*  83 */       for (int i = villager.getInventory().func_70302_i_() - 1; i >= 0; i--) {
/*  84 */         ItemStack itemStack = villager.getInventory().func_70301_a(i);
/*  85 */         if (!itemStack.func_190926_b()) {
/*  86 */           int minDeliver = Integer.MAX_VALUE;
/*  87 */           for (ItemDesire desire : this.itemDesires) {
/*  88 */             int toDeliver = desire.getDeliverToStorage(villager, itemStack);
/*  89 */             if (toDeliver <= 0) {
/*     */               
/*  91 */               minDeliver = Integer.MAX_VALUE; break;
/*     */             } 
/*  93 */             if (toDeliver > 0 && toDeliver < minDeliver) {
/*  94 */               minDeliver = toDeliver;
/*     */             }
/*     */           } 
/*     */           
/*  98 */           if (minDeliver < Integer.MAX_VALUE) {
/*  99 */             int value = VillageManager.getItemValue(itemStack.func_77973_b()) * minDeliver;
/*     */ 
/*     */             
/* 102 */             if (value > bestValue) {
/* 103 */               bestValue = value;
/* 104 */               this.deliveryCount = (short)minDeliver;
/* 105 */               this.deliverySlot = (byte)i;
/*     */             } 
/*     */             
/* 108 */             this.totalDeliverySize += value;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 117 */       this.deliveryDirty = false;
/* 118 */       this.deliveryId++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getDeliveryId(EntityVillagerTek villager, int requiredDeliverSize) {
/* 123 */     updateDeliveryList(villager);
/* 124 */     if (this.totalDeliverySize >= requiredDeliverSize) {
/* 125 */       return this.deliveryId;
/*     */     }
/*     */     
/* 128 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean isDeliveryMatch(int id) {
/* 132 */     return (this.deliveryId == id);
/*     */   }
/*     */   
/*     */   public ItemStack getDeliveryItemCopy(EntityVillagerTek villager) {
/* 136 */     updateDeliveryList(villager);
/*     */     
/* 138 */     if (this.deliverySlot >= 0) {
/*     */       
/* 140 */       ItemStack deliverItem = villager.getInventory().func_70301_a(this.deliverySlot).func_77946_l();
/* 141 */       deliverItem.func_190920_e(this.deliveryCount);
/* 142 */       return deliverItem;
/*     */     } 
/*     */     
/* 145 */     return ItemStack.field_190927_a;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean deliverItems(EntityVillagerTek villager, TileEntityChest destInv, int deliveryCheckId) {
/* 150 */     if (this.deliveryId != deliveryCheckId) {
/* 151 */       villager.debugOut("Delivery Id mismatch");
/* 152 */       this.deliveryDirty = true;
/* 153 */       return false;
/*     */     } 
/* 155 */     if (this.deliverySlot < 0) {
/* 156 */       villager.debugOut("Delivery FAILED. No active delivery.");
/* 157 */       this.deliveryDirty = true;
/* 158 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 163 */     ItemStack removedStack = villager.getInventory().func_70298_a(this.deliverySlot, this.deliveryCount);
/* 164 */     if (removedStack == ItemStack.field_190927_a) {
/* 165 */       villager.debugOut("Delivery FAILED. Delivery item not found in villager inventory");
/* 166 */       this.deliveryDirty = true;
/* 167 */       return false;
/*     */     } 
/*     */     
/* 170 */     if (!deliverOneItem(removedStack, destInv, villager)) {
/*     */       
/* 172 */       villager.debugOut("Delivery FAILED. Returning to villager inventory " + removedStack);
/* 173 */       villager.getInventory().func_174894_a(removedStack);
/* 174 */       this.deliveryDirty = true;
/* 175 */       return false;
/*     */     } 
/*     */     
/* 178 */     return true;
/*     */   }
/*     */   
/*     */   private boolean deliverOneItem(ItemStack sourceStack, TileEntityChest destChest, EntityVillagerTek villager) {
/* 182 */     int emptySlot = -1;
/* 183 */     for (int d = 0; d < destChest.func_70302_i_(); d++) {
/* 184 */       ItemStack destStack = destChest.func_70301_a(d);
/*     */       
/* 186 */       if (destStack.func_190926_b() && emptySlot < 0) {
/* 187 */         emptySlot = d;
/* 188 */       } else if (VillagerInventory.areItemsStackable(destStack, sourceStack)) {
/* 189 */         int k = Math.min(sourceStack.func_190916_E(), destStack.func_77976_d() - destStack.func_190916_E());
/* 190 */         if (k > 0) {
/*     */ 
/*     */           
/* 193 */           destStack.func_190917_f(k);
/*     */ 
/*     */           
/* 196 */           if (villager.hasVillage()) {
/* 197 */             villager.getVillage().onStorageChange(destChest, d, destStack);
/*     */           }
/* 199 */           villager.onInventoryUpdated(destStack);
/*     */           
/* 201 */           sourceStack.func_190918_g(k);
/* 202 */           if (sourceStack.func_190926_b()) {
/* 203 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 209 */     if (emptySlot >= 0) {
/*     */ 
/*     */       
/* 212 */       destChest.func_70299_a(emptySlot, sourceStack);
/*     */ 
/*     */       
/* 215 */       if (villager.hasVillage()) {
/* 216 */         villager.getVillage().onStorageChange(destChest, emptySlot, sourceStack);
/*     */       }
/* 218 */       return true;
/*     */     } 
/*     */     
/* 221 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\storage\ItemDesireSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */