/*    */ package net.tangotek.tektopia.blockfinder;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.block.BlockLeaves;
/*    */ import net.minecraft.block.properties.IProperty;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.tangotek.tektopia.Village;
/*    */ 
/*    */ public class TreeScanner
/*    */   extends BlockScanner {
/*    */   public TreeScanner(Village v, int scansPerTick) {
/* 15 */     super(Blocks.field_150364_r, v, scansPerTick);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public BlockPos testBlock(World w, BlockPos bp) {
/* 21 */     IBlockState blockState = w.func_180495_p(bp);
/* 22 */     if (isLeaf(blockState)) {
/* 23 */       return findTreeFromLeaf(w, bp);
/*    */     }
/*    */     
/* 26 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void scanNearby(BlockPos bp) {
/* 31 */     for (BlockPos scanPos : BlockPos.func_191532_a(bp.func_177958_n() - 7, bp.func_177956_o() + 2, bp.func_177952_p() - 7, bp.func_177958_n() + 7, bp.func_177956_o() + 2, bp.func_177952_p() + 7))
/*    */     {
/* 33 */       scanBlock(scanPos);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   protected BlockPos findTreeFromLeaf(World world, BlockPos leafPos) {
/* 40 */     for (BlockPos bp : BlockPos.func_191532_a(leafPos.func_177958_n() - 2, leafPos.func_177956_o() - 1, leafPos.func_177952_p() - 2, leafPos.func_177958_n() + 2, leafPos.func_177956_o() - 1, leafPos.func_177952_p() + 2)) {
/* 41 */       BlockPos treePos = treeTest(world, bp);
/* 42 */       if (treePos != null) {
/* 43 */         return treePos;
/*    */       }
/*    */     } 
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public static BlockPos treeTest(World world, BlockPos bp) {
/* 51 */     while (isLog(world.func_180495_p(bp))) {
/* 52 */       bp = bp.func_177977_b();
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 57 */       if (world.func_180495_p(bp).func_177230_c() == Blocks.field_150346_d) {
/*    */         
/* 59 */         BlockPos treePos = bp.func_177984_a();
/*    */ 
/*    */         
/* 62 */         bp = bp.func_177981_b(3);
/* 63 */         for (int i = 0; i < 9; i++) {
/*    */           
/* 65 */           IBlockState westBlock = world.func_180495_p(bp.func_177976_e());
/* 66 */           IBlockState eastBlock = world.func_180495_p(bp.func_177974_f());
/* 67 */           if ((isLeaf(westBlock) || isLog(westBlock)) && (isLeaf(eastBlock) || isLog(eastBlock))) {
/* 68 */             return treePos;
/*    */           }
/* 70 */           bp = bp.func_177984_a();
/*    */         } 
/* 72 */         return null;
/*    */       } 
/*    */     } 
/*    */     
/* 76 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean isLog(IBlockState blockState) {
/* 81 */     return (blockState.func_177230_c() == Blocks.field_150364_r || blockState.func_177230_c() == Blocks.field_150363_s);
/*    */   }
/*    */   
/*    */   public static boolean isLeaf(IBlockState blockState) {
/* 85 */     return ((blockState.func_177230_c() == Blocks.field_150362_t || blockState.func_177230_c() == Blocks.field_150361_u) && ((Boolean)blockState.func_177229_b((IProperty)BlockLeaves.field_176237_a)).booleanValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\blockfinder\TreeScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */