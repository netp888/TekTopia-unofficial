/*    */ package net.tangotek.tektopia.gui;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class GuiTekCheckBox
/*    */   extends GuiButton
/*    */ {
/*    */   private boolean isChecked;
/*    */   ResourceLocation resourceLocation;
/*    */   private int checkedTexX;
/*    */   private int checkedTexY;
/*    */   private int uncheckedTexX;
/*    */   private int uncheckedTexY;
/*    */   
/*    */   public GuiTekCheckBox(int buttonId, int x, int y, int widthIn, int heightIn, boolean isChecked, int checkedTexX, int checkedTexY, int uncheckedTexX, int uncheckedTexY, ResourceLocation resourceLocation) {
/* 19 */     super(buttonId, x, y, widthIn, heightIn, "");
/* 20 */     this.resourceLocation = resourceLocation;
/* 21 */     this.isChecked = isChecked;
/* 22 */     this.field_146120_f = widthIn;
/* 23 */     this.field_146121_g = heightIn;
/* 24 */     this.checkedTexX = checkedTexX;
/* 25 */     this.checkedTexY = checkedTexY;
/* 26 */     this.uncheckedTexX = uncheckedTexX;
/* 27 */     this.uncheckedTexY = uncheckedTexY;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partial) {
/* 36 */     if (this.field_146125_m) {
/*    */       
/* 38 */       this.field_146123_n = (mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g);
/* 39 */       mc.func_110434_K().func_110577_a(this.resourceLocation);
/* 40 */       GlStateManager.func_179097_i();
/*    */       
/* 42 */       if (this.isChecked) {
/* 43 */         func_73729_b(this.field_146128_h, this.field_146129_i, this.checkedTexX, this.checkedTexY, this.field_146120_f, this.field_146121_g);
/*    */       } else {
/*    */         
/* 46 */         func_73729_b(this.field_146128_h, this.field_146129_i, this.uncheckedTexX, this.uncheckedTexY, this.field_146120_f, this.field_146121_g);
/*    */       } 
/*    */       
/* 49 */       GlStateManager.func_179126_j();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_146116_c(Minecraft mc, int mouseX, int mouseY) {
/* 60 */     if (this.field_146124_l && this.field_146125_m && mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g) {
/*    */       
/* 62 */       this.isChecked = !this.isChecked;
/* 63 */       return true;
/*    */     } 
/*    */     
/* 66 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isChecked() {
/* 71 */     return this.isChecked;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setIsChecked(boolean isChecked) {
/* 76 */     this.isChecked = isChecked;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\gui\GuiTekCheckBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */