/*    */ package net.tangotek.tektopia.gui;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.IContainerListener;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ import net.tangotek.tektopia.storage.VillagerInventory;
/*    */ 
/*    */ public class ContainerVillager extends Container {
/*    */   private final IInventory villagerInventory;
/*    */   
/*    */   public ContainerVillager(VillagerInventory villagerInventory) {
/* 15 */     this.villagerInventory = (IInventory)villagerInventory;
/* 16 */     for (int i = 0; i < 3; i++) {
/*    */       
/* 18 */       for (int j = 0; j < 9; j++)
/*    */       {
/* 20 */         func_75146_a(new ReadOnlySlot((IInventory)villagerInventory, i * 9 + j, 9 + j * 18, 97 + i * 18));
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_75132_a(IContainerListener listener) {
/* 27 */     super.func_75132_a(listener);
/* 28 */     listener.func_175173_a(this, this.villagerInventory);
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void func_75137_b(int id, int data) {
/* 34 */     this.villagerInventory.func_174885_b(id, data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75145_c(EntityPlayer playerIn) {
/* 42 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\gui\ContainerVillager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */