/*     */ package net.tangotek.tektopia.gui;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.text.TextComponentTranslation;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ import net.tangotek.tektopia.ModItems;
/*     */ import net.tangotek.tektopia.TekVillager;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ import net.tangotek.tektopia.network.PacketAIFilter;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ public class GuiVillagerAI extends GuiContainer {
/*  27 */   public static final ResourceLocation GUI_VILLAGER_AI_TEXTURE = new ResourceLocation("tektopia", "textures/gui/container/villager_ai.png");
/*     */   
/*     */   private final EntityVillagerTek villager;
/*  30 */   private float currentScroll = 0.0F;
/*  31 */   private int scrollIndex = 0;
/*     */   private List<String> aiFilters;
/*  33 */   private final int MAX_VISIBLE_ROWS = 10;
/*     */   
/*     */   private boolean isScrolling;
/*     */   
/*     */   private boolean wasClicking;
/*     */ 
/*     */   
/*     */   public GuiVillagerAI(EntityVillagerTek villager) {
/*  41 */     super(new Container()
/*     */         {
/*     */           public boolean func_75145_c(EntityPlayer playerIn)
/*     */           {
/*  45 */             return false;
/*     */           }
/*     */         });
/*  48 */     this.field_146999_f = 178;
/*  49 */     this.field_147000_g = 157;
/*  50 */     this.villager = villager;
/*  51 */     this.aiFilters = villager.getAIFilters();
/*  52 */     Collections.sort(this.aiFilters);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_73866_w_() {
/*  57 */     super.func_73866_w_();
/*  58 */     for (int buttonId = 0; buttonId < 10; buttonId++) {
/*  59 */       func_189646_b(new GuiTekCheckBox(buttonId, this.field_147003_i + 8, this.field_147009_r + 11 * buttonId + 39, 10, 10, true, 190, 57, 180, 57, GUI_VILLAGER_AI_TEXTURE));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_146284_a(GuiButton button) throws IOException {
/*  65 */     if (button.field_146124_l && 
/*  66 */       button instanceof GuiTekCheckBox) {
/*  67 */       GuiTekCheckBox checkBox = (GuiTekCheckBox)button;
/*  68 */       int index = checkBox.field_146127_k + this.scrollIndex;
/*  69 */       String aiFilter = this.aiFilters.get(index);
/*     */ 
/*     */       
/*  72 */       TekVillager.NETWORK.sendToServer((IMessage)new PacketAIFilter((Entity)this.villager, aiFilter, checkBox.isChecked()));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean needsScrollBar() {
/*  78 */     return (this.aiFilters.size() > 10);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_146274_d() throws IOException {
/*  83 */     super.func_146274_d();
/*  84 */     int i = Mouse.getEventDWheel();
/*     */     
/*  86 */     if (i != 0 && needsScrollBar()) {
/*     */       
/*  88 */       int j = this.aiFilters.size() - 10;
/*     */ 
/*     */       
/*  91 */       if (i > 0)
/*     */       {
/*  93 */         i = 1;
/*     */       }
/*     */       
/*  96 */       if (i < 0)
/*     */       {
/*  98 */         i = -1;
/*     */       }
/*     */       
/* 101 */       this.currentScroll = (float)(this.currentScroll - i / j);
/* 102 */       this.currentScroll = MathHelper.func_76131_a(this.currentScroll, 0.0F, 1.0F);
/* 103 */       scrollTo(this.currentScroll);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void scrollTo(float scroll) {
/* 108 */     this.scrollIndex = (int)((this.aiFilters.size() - 10) * scroll);
/* 109 */     if (this.scrollIndex < 0) {
/* 110 */       this.scrollIndex = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
/* 116 */     if (func_146978_c(14, 0, 28, 29, mouseX, mouseY))
/*     */     {
/* 118 */       this.field_146297_k.func_147108_a((GuiScreen)new GuiVillager(this.villager));
/*     */     }
/*     */     
/* 121 */     super.func_73864_a(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
/* 129 */     func_146276_q_();
/*     */     
/* 131 */     boolean flag = Mouse.isButtonDown(0);
/* 132 */     int i = this.field_147003_i;
/* 133 */     int j = this.field_147009_r;
/* 134 */     int k = i + 160;
/* 135 */     int l = j + 39;
/* 136 */     int i1 = k + 14;
/* 137 */     int j1 = l + 112;
/*     */     
/* 139 */     if (!this.wasClicking && flag && mouseX >= k && mouseY >= l && mouseX < i1 && mouseY < j1)
/*     */     {
/* 141 */       this.isScrolling = needsScrollBar();
/*     */     }
/*     */     
/* 144 */     if (!flag)
/*     */     {
/* 146 */       this.isScrolling = false;
/*     */     }
/*     */     
/* 149 */     this.wasClicking = flag;
/*     */     
/* 151 */     if (this.isScrolling) {
/*     */       
/* 153 */       this.currentScroll = ((mouseY - l) - 7.5F) / ((j1 - l) - 15.0F);
/* 154 */       this.currentScroll = MathHelper.func_76131_a(this.currentScroll, 0.0F, 1.0F);
/* 155 */       scrollTo(this.currentScroll);
/*     */     } 
/*     */     
/* 158 */     updateChecks();
/* 159 */     super.func_73863_a(mouseX, mouseY, partialTicks);
/*     */   }
/*     */   
/*     */   private void updateChecks() {
/* 163 */     for (GuiButton button : this.field_146292_n) {
/* 164 */       if (button instanceof GuiTekCheckBox) {
/* 165 */         GuiTekCheckBox checkBox = (GuiTekCheckBox)button;
/* 166 */         int filterIndex = checkBox.field_146127_k + this.scrollIndex;
/* 167 */         if (filterIndex < this.aiFilters.size()) {
/* 168 */           checkBox.field_146125_m = true;
/* 169 */           checkBox.setIsChecked(this.villager.isAIFilterEnabled(this.aiFilters.get(filterIndex)));
/*     */           continue;
/*     */         } 
/* 172 */         checkBox.field_146125_m = false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_146979_b(int mouseX, int mouseY) {
/* 183 */     GlStateManager.func_179140_f();
/* 184 */     GlStateManager.func_179084_k();
/*     */     
/* 186 */     this.field_146296_j.func_184391_a((EntityLivingBase)this.field_146297_k.field_71439_g, new ItemStack((Item)ModItems.getProfessionToken(this.villager.getProfessionType())), 20, 10);
/*     */     
/* 188 */     int topY = 40;
/*     */     
/* 190 */     for (int i = 0; i < 10; i++) {
/* 191 */       int filterIndex = this.scrollIndex + i;
/* 192 */       if (filterIndex < this.aiFilters.size()) {
/* 193 */         String filterName = this.aiFilters.get(filterIndex);
/* 194 */         TextComponentTranslation textComponentTranslation = new TextComponentTranslation("ai.filter." + filterName, new Object[0]);
/* 195 */         this.field_146289_q.func_78276_b(textComponentTranslation.func_150260_c(), 20, 40 + i * 11, 4210752);
/*     */       } 
/*     */     } 
/*     */     
/* 199 */     GlStateManager.func_179145_e();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
/* 207 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 208 */     this.field_146297_k.func_110434_K().func_110577_a(GUI_VILLAGER_AI_TEXTURE);
/* 209 */     int i = (this.field_146294_l - this.field_146999_f) / 2;
/* 210 */     int j = (this.field_146295_m - this.field_147000_g) / 2;
/* 211 */     func_73729_b(i, j, 0, 0, this.field_146999_f, this.field_147000_g);
/*     */     
/* 213 */     int scrollLeft = this.field_147003_i + 160;
/* 214 */     int scrollTop = this.field_147009_r + 39;
/* 215 */     int scrollHeight = scrollTop + 112;
/*     */     
/* 217 */     func_73729_b(scrollLeft, scrollTop + (int)((scrollHeight - scrollTop - 17) * this.currentScroll), 180 + (needsScrollBar() ? 0 : 12), 38, 12, 15);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\gui\GuiVillagerAI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */