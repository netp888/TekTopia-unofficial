/*     */ package net.tangotek.tektopia.structures;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItemFrame;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.Village;
/*     */ import net.tangotek.tektopia.entities.EntityDruid;
/*     */ import net.tangotek.tektopia.entities.EntityMiner;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ import net.tangotek.tektopia.tickjob.TickJob;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VillageStructureMineshaft
/*     */   extends VillageStructure
/*     */ {
/*  30 */   private EntityVillagerTek currentMiner = null;
/*  31 */   private EntityDruid druid = null;
/*     */   private BlockPos miningPos;
/*     */   
/*     */   protected VillageStructureMineshaft(World world, Village v, EntityItemFrame itemFrame) {
/*  35 */     super(world, v, itemFrame, VillageStructureType.MINESHAFT, "Mineshaft");
/*     */   }
/*     */   
/*     */   public int getTunnelLength() {
/*  39 */     return this.floorTiles.size();
/*     */   }
/*     */   
/*     */   public BlockPos getMiningPos() {
/*  43 */     return this.miningPos;
/*     */   }
/*     */   
/*     */   public BlockPos getWalkingPos() {
/*  47 */     return this.miningPos.func_177967_a(this.signFacing, 1);
/*     */   }
/*     */   
/*     */   public boolean adjustsVillageCenter() {
/*  51 */     return false;
/*     */   }
/*     */   
/*     */   protected void setupServerJobs() {
/*  55 */     addJob(new TickJob(20, 10, true, () -> updateOccupants()));
/*  56 */     super.setupServerJobs();
/*     */   }
/*     */   
/*     */   public void updateOccupants() {
/*  60 */     List<EntityVillagerTek> occupants = this.world.func_72872_a(EntityVillagerTek.class, this.aabb);
/*     */     
/*  62 */     if (occupants.isEmpty()) {
/*  63 */       setTunnelMiner((EntityVillagerTek)null);
/*  64 */     } else if (getTunnelMiner() == null) {
/*  65 */       setTunnelMiner(occupants.get(0));
/*  66 */     } else if (!occupants.contains(getTunnelMiner())) {
/*  67 */       setTunnelMiner((EntityVillagerTek)null);
/*     */     } 
/*  69 */     EntityVillagerTek miner = getTunnelMiner();
/*  70 */     if (miner != null) {
/*  71 */       tryPlaceTorch(miner);
/*     */     }
/*     */   }
/*     */   
/*     */   public void tryPlaceTorch(EntityVillagerTek miner) {
/*  76 */     BlockPos pos = miner.func_180425_c();
/*  77 */     if (miner.field_70170_p.func_175671_l(pos) < 8)
/*     */     {
/*  79 */       if (!miner.getInventory().removeItems(EntityMiner.isTorch(), 1).isEmpty())
/*  80 */         miner.field_70170_p.func_175656_a(pos, Blocks.field_150478_aa.func_176223_P()); 
/*     */     }
/*     */   }
/*     */   
/*     */   public EntityVillagerTek getTunnelMiner() {
/*  85 */     return this.currentMiner;
/*     */   }
/*     */   
/*     */   private void setTunnelMiner(EntityVillagerTek miner) {
/*  89 */     this.currentMiner = miner;
/*     */   }
/*     */   
/*     */   public void setDruid(EntityDruid d) {
/*  93 */     this.druid = d;
/*     */   }
/*     */   
/*     */   public EntityDruid getDruid() {
/*  97 */     return this.druid;
/*     */   }
/*     */   
/*     */   public void checkExtendTunnel() {
/* 101 */     while (isTunnel(this, this.miningPos)) {
/* 102 */       addFloorTile(this.miningPos);
/* 103 */       this.miningPos = this.miningPos.func_177967_a(this.signFacing, -1);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void regrow(EntityVillagerTek villager) {
/* 108 */     if (getTunnelLength() > 3) {
/* 109 */       BlockPos regrowPos = getWalkingPos();
/* 110 */       regrowColumn(villager, regrowPos);
/* 111 */       regrowColumn(villager, regrowPos.func_177967_a(this.signFacing.func_176735_f(), 1));
/* 112 */       regrowColumn(villager, regrowPos.func_177967_a(this.signFacing.func_176746_e(), 1));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     doFloorScan();
/*     */   }
/*     */   
/*     */   protected void regrowColumn(EntityVillagerTek villager, BlockPos pos) {
/* 143 */     regrowBlock(villager, pos.func_177977_b());
/* 144 */     regrowBlock(villager, pos);
/* 145 */     regrowBlock(villager, pos.func_177984_a());
/* 146 */     regrowBlock(villager, pos.func_177981_b(2));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void regrowBlock(EntityVillagerTek villager, BlockPos pos) {
/* 151 */     if (!isOre(villager.field_70170_p, pos)) {
/* 152 */       if (villager.func_70681_au().nextInt(1000) < villager.getSkillLerp(ProfessionType.DRUID, 25, 40)) {
/* 153 */         this.world.func_180501_a(pos, getRegrowBlock(villager).func_176223_P(), 2);
/*     */       } else {
/* 155 */         this.world.func_180501_a(pos, Blocks.field_150348_b.func_176223_P(), 2);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Block getRegrowBlock(EntityVillagerTek villager) {
/* 176 */     int oreRoll = villager.func_70681_au().nextInt(325);
/* 177 */     if (oreRoll < 10) {
/* 178 */       return Blocks.field_150482_ag;
/*     */     }
/* 180 */     if (oreRoll < 20) {
/* 181 */       return Blocks.field_150369_x;
/*     */     }
/* 183 */     if (oreRoll < 35) {
/* 184 */       return Blocks.field_150352_o;
/*     */     }
/* 186 */     if (oreRoll < 100) {
/* 187 */       return Blocks.field_150366_p;
/*     */     }
/* 189 */     if (oreRoll < 200) {
/* 190 */       return Blocks.field_150365_q;
/*     */     }
/*     */     
/* 193 */     if (villager.func_70681_au().nextInt(3) == 0) {
/* 194 */       return Blocks.field_150450_ax;
/*     */     }
/* 196 */     return Blocks.field_150348_b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onFloorScanStart() {
/* 202 */     this.miningPos = this.door.func_177967_a(this.signFacing, -1);
/* 203 */     super.onFloorScanStart();
/*     */   }
/*     */   
/*     */   public BlockPos findOre(BlockPos pos, int distance, EnumFacing fromDir) {
/* 207 */     if (distance > 3)
/* 208 */       return null; 
/* 209 */     if (this.world.func_175623_d(pos)) {
/* 210 */       BlockPos next = null;
/* 211 */       if (fromDir != EnumFacing.DOWN) {
/* 212 */         next = findOre(pos.func_177984_a(), distance + 1, EnumFacing.UP);
/* 213 */         if (next != null) {
/* 214 */           return next;
/*     */         }
/*     */       } 
/* 217 */       if (fromDir != EnumFacing.UP) {
/* 218 */         next = findOre(pos.func_177977_b(), distance + 1, EnumFacing.DOWN);
/* 219 */         if (next != null) {
/* 220 */           return next;
/*     */         }
/*     */       } 
/* 223 */       if (fromDir != this.signFacing.func_176746_e()) {
/* 224 */         next = findOre(pos.func_177967_a(this.signFacing.func_176735_f(), 1), distance + 1, this.signFacing.func_176735_f());
/* 225 */         if (next != null) {
/* 226 */           return next;
/*     */         }
/*     */       } 
/* 229 */       if (fromDir != this.signFacing.func_176735_f()) {
/* 230 */         next = findOre(pos.func_177967_a(this.signFacing.func_176746_e(), 1), distance + 1, this.signFacing.func_176746_e());
/* 231 */         if (next != null) {
/* 232 */           return next;
/*     */         }
/*     */       }
/*     */     
/* 236 */     } else if (isOre(this.world, pos) && 
/* 237 */       canDig(this.world, pos)) {
/* 238 */       return pos;
/*     */     } 
/*     */     
/* 241 */     return null;
/*     */   }
/*     */   
/*     */   public static boolean isOre(World world, BlockPos pos) {
/* 245 */     Block b = world.func_180495_p(pos).func_177230_c();
/* 246 */     return (b == Blocks.field_150365_q || b == Blocks.field_150366_p || b == Blocks.field_150482_ag || b == Blocks.field_150352_o || b == Blocks.field_150369_x || b == Blocks.field_150412_bA || b == Blocks.field_150450_ax);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canDig(World world, BlockPos pos) {
/* 251 */     if (world.func_180495_p(pos.func_177984_a()).func_185904_a().func_76224_d() || world
/* 252 */       .func_180495_p(pos.func_177976_e()).func_185904_a().func_76224_d() || world
/* 253 */       .func_180495_p(pos.func_177974_f()).func_185904_a().func_76224_d() || world
/* 254 */       .func_180495_p(pos.func_177978_c()).func_185904_a().func_76224_d() || world
/* 255 */       .func_180495_p(pos.func_177968_d()).func_185904_a().func_76224_d()) {
/* 256 */       return false;
/*     */     }
/* 258 */     return true;
/*     */   }
/*     */   
/*     */   public boolean canMine() {
/* 262 */     if (this.miningPos == null) {
/* 263 */       return false;
/*     */     }
/* 265 */     if (!this.village.isInVillage(this.miningPos.func_177967_a(this.signFacing, -1))) {
/* 266 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 270 */     if (this.world.func_180495_p(this.miningPos).func_185904_a().func_76224_d()) {
/* 271 */       return false;
/*     */     }
/* 273 */     if (this.world.func_180495_p(this.miningPos.func_177984_a()).func_185904_a().func_76224_d()) {
/* 274 */       return false;
/*     */     }
/* 276 */     if (isSolid(this, this.miningPos) && !canDig(this.world, this.miningPos)) {
/* 277 */       return false;
/*     */     }
/* 279 */     if (isSolid(this, this.miningPos.func_177984_a()) && !canDig(this.world, this.miningPos.func_177984_a())) {
/* 280 */       return false;
/*     */     }
/* 282 */     return true;
/*     */   }
/*     */   
/*     */   protected BlockPos findDoor() {
/* 286 */     BlockPos dp = null;
/*     */     
/* 288 */     dp = this.framePos.func_177967_a(this.signFacing, -1).func_177967_a(this.signFacing.func_176746_e(), 1).func_177977_b();
/* 289 */     if (!isTunnel(this, dp)) {
/* 290 */       dp = this.framePos.func_177967_a(this.signFacing, -1).func_177967_a(this.signFacing.func_176746_e(), -1).func_177977_b();
/* 291 */       if (!isTunnel(this, dp))
/* 292 */         dp = this.framePos.func_177967_a(this.signFacing, -1).func_177979_c(2); 
/* 293 */       if (!isTunnel(this, dp)) {
/* 294 */         dp = null;
/*     */       }
/*     */     } 
/* 297 */     return dp;
/*     */   }
/*     */   
/*     */   public static boolean isTunnel(VillageStructureMineshaft mineshaft, BlockPos floorPos) {
/* 301 */     BlockPos upPos = floorPos.func_177984_a();
/* 302 */     if (isAir(mineshaft, upPos) && isAir(mineshaft, floorPos) && 
/* 303 */       isSolid(mineshaft, upPos.func_177984_a()) && isSolid(mineshaft, floorPos.func_177977_b()) && 
/* 304 */       isSolid(mineshaft, upPos.func_177967_a(mineshaft.signFacing.func_176746_e(), 1)) && 
/* 305 */       isSolid(mineshaft, upPos.func_177967_a(mineshaft.signFacing.func_176746_e(), -1)) && 
/* 306 */       isSolid(mineshaft, floorPos.func_177967_a(mineshaft.signFacing.func_176746_e(), 1)) && 
/* 307 */       isSolid(mineshaft, floorPos.func_177967_a(mineshaft.signFacing.func_176746_e(), -1))) {
/* 308 */       return true;
/*     */     }
/*     */     
/* 311 */     return false;
/*     */   }
/*     */   
/*     */   public static BlockPos getTunnelFlaw(VillageStructureMineshaft mineshaft, BlockPos pos) {
/* 315 */     BlockPos testPos = pos.func_177977_b();
/* 316 */     if (!isSolid(mineshaft, testPos)) {
/* 317 */       return testPos;
/*     */     }
/* 319 */     testPos = pos.func_177967_a(mineshaft.signFacing.func_176746_e(), 1);
/* 320 */     if (!isSolid(mineshaft, testPos)) {
/* 321 */       return testPos;
/*     */     }
/* 323 */     testPos = pos.func_177967_a(mineshaft.signFacing.func_176746_e(), -1);
/* 324 */     if (!isSolid(mineshaft, testPos)) {
/* 325 */       return testPos;
/*     */     }
/* 327 */     testPos = pos.func_177984_a().func_177967_a(mineshaft.signFacing.func_176746_e(), 1);
/* 328 */     if (!isSolid(mineshaft, testPos)) {
/* 329 */       return testPos;
/*     */     }
/* 331 */     testPos = pos.func_177984_a().func_177967_a(mineshaft.signFacing.func_176746_e(), -1);
/* 332 */     if (!isSolid(mineshaft, testPos)) {
/* 333 */       return testPos;
/*     */     }
/* 335 */     testPos = pos.func_177981_b(2);
/* 336 */     if (!isSolid(mineshaft, testPos)) {
/* 337 */       return testPos;
/*     */     }
/* 339 */     return null;
/*     */   }
/*     */   
/*     */   public static boolean isAir(VillageStructureMineshaft mineshaft, BlockPos pos) {
/* 343 */     return (mineshaft.world.func_180495_p(pos).func_185904_a() == Material.field_151579_a || mineshaft.world.func_180495_p(pos).func_177230_c() == Blocks.field_150478_aa);
/*     */   }
/*     */   
/*     */   public static boolean isSolid(VillageStructureMineshaft mineshaft, BlockPos pos) {
/* 347 */     return mineshaft.world.func_180495_p(pos).func_185913_b();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void scanFloor(BlockPos pos) {
/* 352 */     if (!this.floorTiles.contains(pos) && 
/* 353 */       isTunnel(this, pos) && 
/* 354 */       this.village.getPathingGraph().isInGraph(pos)) {
/* 355 */       this.miningPos = pos.func_177967_a(this.signFacing, -1);
/* 356 */       this.ceilingHeightSum += 2;
/* 357 */       addFloorTile(pos);
/*     */       
/* 359 */       scanFloor(pos.func_177967_a(this.signFacing, -1));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void addFloorTile(BlockPos pos) {
/* 366 */     this.floorTiles.add(pos);
/* 367 */     this.aabb = this.aabb.func_111270_a(new AxisAlignedBB(pos));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean validate() {
/* 372 */     this.isValid = true;
/*     */     
/* 374 */     if (this.door == null)
/*     */     {
/* 376 */       this.isValid = false;
/*     */     }
/*     */     
/* 379 */     Entity e = this.world.func_73045_a(this.signEntityId);
/* 380 */     if (this.isValid && (e == null || !(e instanceof EntityItemFrame))) {
/* 381 */       debugOut("Mineshaft struct frame is missing or wrong type");
/* 382 */       this.isValid = false;
/*     */     } 
/*     */     
/* 385 */     EntityItemFrame itemFrame = (EntityItemFrame)e;
/* 386 */     if (this.isValid && itemFrame.func_174857_n() != this.framePos) {
/* 387 */       debugOut("Mineshaft struct center has moved");
/* 388 */       this.isValid = false;
/*     */     } 
/*     */     
/* 391 */     if (this.isValid && !itemFrame.func_82335_i().func_77969_a(this.type.itemStack)) {
/* 392 */       debugOut("Mineshaft struct frame item has changed");
/* 393 */       this.isValid = false;
/*     */     } 
/*     */     
/* 396 */     if (!canMine())
/*     */     {
/* 398 */       this.isValid = false;
/*     */     }
/*     */     
/* 401 */     return this.isValid;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\structures\VillageStructureMineshaft.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */