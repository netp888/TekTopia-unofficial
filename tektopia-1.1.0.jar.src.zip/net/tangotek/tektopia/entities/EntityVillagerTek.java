/*      */ package net.tangotek.tektopia.entities;
/*      */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Map;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import javax.annotation.Nullable;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.EntityLiving;
/*      */ import net.minecraft.entity.EntityLivingBase;
/*      */ import net.minecraft.entity.IEntityLivingData;
/*      */ import net.minecraft.entity.SharedMonsterAttributes;
/*      */ import net.minecraft.entity.ai.EntityAIBase;
/*      */ import net.minecraft.entity.ai.EntityAITasks;
/*      */ import net.minecraft.entity.ai.attributes.IAttribute;
/*      */ import net.minecraft.entity.ai.attributes.IAttributeInstance;
/*      */ import net.minecraft.entity.ai.attributes.RangedAttribute;
/*      */ import net.minecraft.entity.item.EntityItem;
/*      */ import net.minecraft.entity.passive.EntityAnimal;
/*      */ import net.minecraft.entity.player.EntityPlayer;
/*      */ import net.minecraft.entity.player.EntityPlayerMP;
/*      */ import net.minecraft.init.Items;
/*      */ import net.minecraft.init.SoundEvents;
/*      */ import net.minecraft.inventory.EntityEquipmentSlot;
/*      */ import net.minecraft.item.Item;
/*      */ import net.minecraft.item.ItemStack;
/*      */ import net.minecraft.nbt.NBTTagCompound;
/*      */ import net.minecraft.nbt.NBTTagList;
/*      */ import net.minecraft.network.datasync.DataParameter;
/*      */ import net.minecraft.network.datasync.DataSerializers;
/*      */ import net.minecraft.network.datasync.EntityDataManager;
/*      */ import net.minecraft.potion.PotionEffect;
/*      */ import net.minecraft.util.DamageSource;
/*      */ import net.minecraft.util.EnumHand;
/*      */ import net.minecraft.util.EnumParticleTypes;
/*      */ import net.minecraft.util.SoundCategory;
/*      */ import net.minecraft.util.math.AxisAlignedBB;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ import net.minecraft.util.math.MathHelper;
/*      */ import net.minecraft.util.text.translation.I18n;
/*      */ import net.minecraft.world.World;
/*      */ import net.minecraftforge.fml.relauncher.Side;
/*      */ import net.minecraftforge.fml.relauncher.SideOnly;
/*      */ import net.tangotek.tektopia.ItemTagType;
/*      */ import net.tangotek.tektopia.ModItems;
/*      */ import net.tangotek.tektopia.ModPotions;
/*      */ import net.tangotek.tektopia.ModSoundEvents;
/*      */ import net.tangotek.tektopia.ProfessionType;
/*      */ import net.tangotek.tektopia.TekVillager;
/*      */ import net.tangotek.tektopia.Village;
/*      */ import net.tangotek.tektopia.VillageManager;
/*      */ import net.tangotek.tektopia.VillagerRole;
/*      */ import net.tangotek.tektopia.caps.IVillageData;
/*      */ import net.tangotek.tektopia.client.ParticleThought;
/*      */ import net.tangotek.tektopia.entities.ai.EntityAIEatFood;
/*      */ import net.tangotek.tektopia.items.ItemProfessionToken;
/*      */ import net.tangotek.tektopia.network.PacketVillagerThought;
/*      */ import net.tangotek.tektopia.storage.ItemDesireSet;
/*      */ import net.tangotek.tektopia.storage.VillagerInventory;
/*      */ import net.tangotek.tektopia.structures.VillageStructure;
/*      */ import net.tangotek.tektopia.structures.VillageStructureHome;
/*      */ import net.tangotek.tektopia.structures.VillageStructureType;
/*      */ import net.tangotek.tektopia.tickjob.TickJob;
/*      */ 
/*      */ public abstract class EntityVillagerTek extends EntityVillageNavigator {
/*   69 */   public static final IAttribute MAX_HUNGER = (IAttribute)(new RangedAttribute((IAttribute)null, "generic.hunger", 100.0D, 0.0D, 100.0D)).func_111117_a("Hunger").func_111112_a(true);
/*   70 */   public static final IAttribute MAX_HAPPY = (IAttribute)(new RangedAttribute((IAttribute)null, "generic.happy", 100.0D, 0.0D, 100.0D)).func_111117_a("Happy").func_111112_a(true);
/*   71 */   public static final IAttribute MAX_INTELLIGENCE = (IAttribute)(new RangedAttribute((IAttribute)null, "generic.intelligence", 100.0D, 0.0D, 100.0D)).func_111117_a("Intelligence").func_111112_a(true);
/*   72 */   private static final DataParameter<Integer> HUNGER = EntityDataManager.func_187226_a(EntityVillagerTek.class, DataSerializers.field_187192_b);
/*   73 */   private static final DataParameter<Integer> HAPPY = EntityDataManager.func_187226_a(EntityVillagerTek.class, DataSerializers.field_187192_b);
/*   74 */   private static final DataParameter<Integer> INTELLIGENCE = EntityDataManager.func_187226_a(EntityVillagerTek.class, DataSerializers.field_187192_b);
/*   75 */   private static final DataParameter<Integer> FORCE_AXIS = EntityDataManager.func_187226_a(EntityVillagerTek.class, DataSerializers.field_187192_b);
/*   76 */   private static final DataParameter<Boolean> SLEEPING = EntityDataManager.func_187226_a(EntityVillagerTek.class, DataSerializers.field_187198_h);
/*   77 */   private static final DataParameter<Boolean> SITTING = EntityDataManager.func_187226_a(EntityVillagerTek.class, DataSerializers.field_187198_h);
/*   78 */   private static final DataParameter<ItemStack> ACTION_ITEM = EntityDataManager.func_187226_a(EntityVillagerTek.class, DataSerializers.field_187196_f);
/*   79 */   private static final DataParameter<Byte> MOVEMENT_MODE = EntityDataManager.func_187226_a(EntityVillagerTek.class, DataSerializers.field_187191_a);
/*   80 */   private static final DataParameter<Integer> BLESSED = EntityDataManager.func_187226_a(EntityVillagerTek.class, DataSerializers.field_187192_b);
/*      */ 
/*      */   
/*   83 */   private static final DataParameter<Boolean> VISIT_TAVERN = EntityDataManager.func_187226_a(EntityVillagerTek.class, DataSerializers.field_187198_h);
/*   84 */   private static final DataParameter<Boolean> READ_BOOK = EntityDataManager.func_187226_a(EntityVillagerTek.class, DataSerializers.field_187198_h);
/*      */ 
/*      */   
/*   87 */   public static int SLEEP_DURATION = 8000;
/*   88 */   public static int SLEEP_START_TIME = 16000;
/*   89 */   public static int SLEEP_END_TIME = SLEEP_START_TIME + SLEEP_DURATION;
/*   90 */   public static int WORK_START_TIME = 500;
/*   91 */   public static int WORK_END_TIME = 11500;
/*      */   
/*      */   private static final boolean ALL_MALES = false;
/*      */   private static final boolean ALL_FEMALES = false;
/*      */   protected static final int DEFAULT_JOB_PRIORITY = 50;
/*   96 */   private PacketVillagerThought nextThought = null;
/*      */   
/*   98 */   private static int[] recentEatPenalties = new int[] { 2, 0, -3, -7, -12, -18 };
/*      */   
/*  100 */   private static final Map<ProfessionType, DataParameter<Integer>> SKILLS = new EnumMap<>(ProfessionType.class); protected ItemDesireSet desireSet; protected VillagerInventory villagerInventory;
/*      */   static {
/*  102 */     for (ProfessionType pt : ProfessionType.values()) {
/*  103 */       SKILLS.put(pt, EntityDataManager.func_187226_a(EntityVillagerTek.class, DataSerializers.field_187192_b));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  110 */   protected BlockPos bedPos = null;
/*  111 */   protected BlockPos homeFrame = null;
/*      */   
/*  113 */   protected EntityAnimal leadAnimal = null;
/*      */   private MovementMode lastMovementMode;
/*  115 */   private VillageStructure lastCrowdCheck = null;
/*      */   
/*  117 */   protected int sleepOffset = 0;
/*      */   
/*  119 */   protected int wantsLearning = 0;
/*      */   protected boolean wantsTavern = false;
/*  121 */   protected int lastSadTick = 0;
/*  122 */   protected int lastSadThrottle = 200;
/*  123 */   private int idle = 0;
/*  124 */   protected int daysAlive = 0;
/*  125 */   private int dayCheckTime = 0;
/*      */   
/*      */   private final ProfessionType professionType;
/*      */   private Map<String, DataParameter<Boolean>> aiFilters;
/*  129 */   private LinkedList<Integer> recentEats = new LinkedList<>();
/*      */   
/*      */   public enum MovementMode {
/*  132 */     WALK((byte)1, 1.0F, "villager_walk"),
/*  133 */     SKIP((byte)2, 1.1F, "villager_skip"),
/*  134 */     RUN((byte)3, 1.4F, "villager_run"),
/*  135 */     SULK((byte)4, 0.7F, "villager_walk_sad"); public float speedMult; public byte id; public String anim;
/*      */     
/*      */     MovementMode(byte id, float mult, String anim) {
/*  138 */       this.speedMult = mult;
/*  139 */       this.id = id;
/*  140 */       this.anim = anim;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum VillagerThought
/*      */   {
/*  157 */     BED(115, "red_bed.png"),
/*  158 */     HUNGRY(116, "food.png"),
/*  159 */     PICK(117, "iron_pick.png"),
/*  160 */     HOE(118, "iron_hoe.png"),
/*  161 */     AXE(119, "iron_axe.png"),
/*  162 */     SWORD(120, "iron_sword.png"),
/*  163 */     BOOKSHELF(121, "bookshelf.png"),
/*  164 */     PIG_FOOD(122, "pig_carrot.png"),
/*  165 */     SHEEP_FOOD(123, "sheep_wheat.png"),
/*  166 */     COW_FOOD(124, "cow_wheat.png"),
/*  167 */     CHICKEN_FOOD(125, "chicken_seeds.png"),
/*  168 */     BUCKET(126, "bucket.png"),
/*  169 */     SHEARS(127, "shears.png"),
/*  170 */     TAVERN(128, "structure_tavern.png"),
/*  171 */     NOTEBLOCK(129, "noteblock.png"),
/*  172 */     TEACHER(130, "prof_teacher.png"),
/*  173 */     TORCH(131, "torch.png"),
/*  174 */     INSOMNIA(132, "insomnia.png"),
/*  175 */     CROWDED(133, "crowded.png"),
/*  176 */     DO_NOT_USE(999, "meh.png");
/*      */     private int numVal;
/*      */     private String texture;
/*      */     
/*      */     VillagerThought(int val, String tex) {
/*  181 */       this.numVal = val;
/*  182 */       this.texture = tex;
/*      */     }
/*      */     
/*  185 */     public int getVal() { return this.numVal; }
/*  186 */     public String getTex() { return this.texture; } public float getScale() {
/*  187 */       return 1.0F;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EntityVillagerTek(World worldIn, ProfessionType profType, int roleMask) {
/*  201 */     super(worldIn, roleMask);
/*  202 */     this.professionType = profType;
/*  203 */     func_98053_h(true);
/*  204 */     this.villagerInventory = new VillagerInventory(this, "Items", false, 27);
/*  205 */     func_70105_a(0.6F, 1.95F);
/*  206 */     setHunger(getMaxHunger());
/*  207 */     setHappy(getMaxHappy());
/*  208 */     setIntelligence(0);
/*      */     
/*  210 */     ModEntities.makeTaggedEntity((Entity)this, EntityTagType.VILLAGER);
/*      */     
/*  212 */     Runnable foodChomp = () -> this.field_70170_p.func_184134_a(this.field_70165_t, this.field_70163_u, this.field_70161_v, SoundEvents.field_187537_bA, SoundCategory.NEUTRAL, 1.0F, this.field_70146_Z.nextFloat() * 0.2F + 0.9F, false);
/*      */ 
/*      */ 
/*      */     
/*  216 */     Runnable doneEating = () -> {
/*      */         unequipActionItem();
/*      */         if (func_70681_au().nextInt(12) == 0) {
/*      */           this.field_70170_p.func_184134_a(this.field_70165_t, this.field_70163_u, this.field_70161_v, SoundEvents.field_187739_dZ, SoundCategory.NEUTRAL, 1.0F, this.field_70146_Z.nextFloat() * 0.2F + 0.9F, false);
/*      */         }
/*      */       };
/*  222 */     if (this.field_70170_p.field_72995_K) {
/*  223 */       addAnimationTrigger("tektopia:villager_eat", 25, foodChomp);
/*  224 */       addAnimationTrigger("tektopia:villager_eat", 50, foodChomp);
/*  225 */       addAnimationTrigger("tektopia:villager_eat", 75, foodChomp);
/*  226 */       addAnimationTrigger("tektopia:villager_eat", 90, doneEating);
/*      */     } 
/*      */     
/*  229 */     if (!worldIn.field_72995_K) {
/*  230 */       randomizeGoals();
/*  231 */       if (this.professionType != null && getBaseSkill(this.professionType) < 1) {
/*  232 */         setSkill(this.professionType, 1);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected static void setupAnimations(AnimationHandler animHandler, String modelName) {
/*  238 */     EntityVillageNavigator.setupAnimations(animHandler, modelName);
/*  239 */     animHandler.addAnim("tektopia", "villager_eat", modelName, false);
/*  240 */     animHandler.addAnim("tektopia", "villager_sleep", modelName, true);
/*  241 */     animHandler.addAnim("tektopia", "villager_sit", modelName, true);
/*  242 */     animHandler.addAnim("tektopia", "villager_sit_cheer", modelName, false);
/*  243 */     animHandler.addAnim("tektopia", "villager_walk", modelName, true);
/*  244 */     animHandler.addAnim("tektopia", "villager_walk_sad", modelName, true);
/*  245 */     animHandler.addAnim("tektopia", "villager_run", modelName, true);
/*  246 */     animHandler.addAnim("tektopia", "villager_read", modelName, false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initEntityAIBase() {
/*  251 */     Function<ItemStack, Integer> bestFood = p -> Integer.valueOf(EntityAIEatFood.getFoodScore(p.func_77973_b(), this));
/*  252 */     getDesireSet().addItemDesire((ItemDesire)new UpgradeItemDesire("Food", bestFood, 1, 3, 4, p -> (p.isHungry() || p.isStoragePriority())));
/*      */     
/*  254 */     addTask(50, (EntityAIBase)new EntityAIEatFood(this));
/*  255 */     addTask(50, (EntityAIBase)new EntityAIRetrieveFromStorage2(this));
/*  256 */     addTask(50, (EntityAIBase)new EntityAISleep(this));
/*  257 */     addTask(50, (EntityAIBase)new EntityAIDeliverToStorage2(this));
/*  258 */     addTask(50, (EntityAIBase)new EntityAITavernVisit(this, p -> (p.wantsTavern() && !p.isWorkTime() && !p.shouldSleep())));
/*  259 */     addTask(50, (EntityAIBase)new EntityAIWanderStructure(this, getVillagerHome(), p -> (!p.isWorkTime() && !wantsTavern()), 12));
/*  260 */     addTask(50, (EntityAIBase)new EntityAIReadBook(this));
/*      */ 
/*      */     
/*  263 */     addTask(60, (EntityAIBase)new EntityAIGenericMove(this, p -> (p.isWorkTime() && p.hasVillage() && p.getIdle() > 100), v -> this.village.getLastVillagerPos(), MovementMode.WALK, null, null));
/*      */ 
/*      */     
/*  266 */     addTask(150, (EntityAIBase)new EntityAIIdleCheck(this));
/*      */   }
/*      */ 
/*      */   
/*      */   protected void func_184651_r() {
/*  271 */     this.desireSet = new ItemDesireSet();
/*      */     
/*  273 */     addTask(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
/*  274 */     addTask(1, (EntityAIBase)new EntityAIFleeEntity(this, p -> isFleeFrom(p), 16.0F));
/*      */     
/*  276 */     addTask(15, (EntityAIBase)new EntityAIUseDoor((EntityLiving)this, true));
/*  277 */     addTask(15, (EntityAIBase)new EntityAIOpenGate(this));
/*      */     
/*  279 */     initEntityAIBase();
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public IEntityLivingData func_180482_a(DifficultyInstance difficulty, @Nullable IEntityLivingData livingdata) {
/*  284 */     func_96094_a(generateName());
/*      */     
/*  286 */     double intel = func_70681_au().nextGaussian() * 10.0D;
/*  287 */     if (intel < 0.0D) {
/*  288 */       intel *= 0.3D;
/*      */     }
/*  290 */     intel = Math.max(intel + 10.0D, 2.0D);
/*  291 */     setIntelligence((int)intel);
/*      */     
/*  293 */     return super.func_180482_a(difficulty, livingdata);
/*      */   }
/*      */   
/*      */   public String generateName() {
/*  297 */     String nameTytpe = isMale() ? "malename" : "femalename";
/*      */     
/*  299 */     String firstSTotal = I18n.func_74838_a("villager." + nameTytpe + ".total");
/*  300 */     int firstTotal = Integer.parseInt(firstSTotal);
/*  301 */     String lastSTotal = I18n.func_74838_a("villager.lastname.total");
/*  302 */     int lastTotal = Integer.parseInt(lastSTotal);
/*      */     
/*  304 */     String firstName = I18n.func_74838_a("villager." + nameTytpe + "." + func_70681_au().nextInt(firstTotal));
/*  305 */     String lastName = I18n.func_74838_a("villager.lastname." + func_70681_au().nextInt(lastTotal));
/*      */     
/*  307 */     return firstName + " " + lastName;
/*      */   }
/*      */   
/*      */   public String getLastName() {
/*  311 */     String name = func_95999_t();
/*  312 */     String[] splitNames = name.split("\\s+");
/*  313 */     if (splitNames.length >= 2) {
/*  314 */       return splitNames[1];
/*      */     }
/*      */     
/*  317 */     return "";
/*      */   }
/*      */   
/*      */   public String getFirstName() {
/*  321 */     String name = func_95999_t();
/*  322 */     String[] splitNames = name.split("\\s+");
/*  323 */     if (splitNames.length >= 2) {
/*  324 */       return splitNames[0];
/*      */     }
/*      */     
/*  327 */     return "";
/*      */   }
/*      */   
/*      */   public String getDebugName() {
/*  331 */     return getClass().getSimpleName() + func_145782_y();
/*      */   }
/*      */   public ProfessionType getProfessionType() {
/*  334 */     return this.professionType;
/*      */   }
/*      */   protected boolean hasTavern() {
/*  337 */     return (hasVillage() && getVillage().hasStructure(VillageStructureType.TAVERN));
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean wantsTavern() {
/*  342 */     if (getHappy() >= 100 || !hasTavern()) {
/*  343 */       return false;
/*      */     }
/*  345 */     if (!isWorkTime() && (
/*  346 */       getHappy() < 70 || this.wantsTavern)) {
/*  347 */       return true;
/*      */     }
/*      */ 
/*      */     
/*  351 */     if (getHappy() < 10) {
/*  352 */       return true;
/*      */     }
/*      */     
/*  355 */     return false;
/*      */   }
/*      */   
/*      */   protected void addTask(int priority, EntityAIBase task) {
/*  359 */     this.field_70714_bg.func_75776_a(priority, task);
/*      */   }
/*      */   
/*      */   public boolean isDeliveryTime() {
/*  363 */     return isWorkTime();
/*      */   }
/*      */   
/*      */   private static class CleanUpRunnable implements Runnable {
/*      */     private final WeakReference<EntityVillagerTek> villager;
/*      */     
/*      */     public CleanUpRunnable(EntityVillagerTek v) {
/*  370 */       this.villager = new WeakReference<>(v);
/*      */     }
/*      */     public void run() {
/*  373 */       if (this.villager.get() != null)
/*  374 */         ((EntityVillagerTek)this.villager.get()).cleanUpInventory(); 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class GoalRandomizerRunnable implements Runnable {
/*      */     private final WeakReference<EntityVillagerTek> villager;
/*      */     
/*      */     public GoalRandomizerRunnable(EntityVillagerTek v) {
/*  382 */       this.villager = new WeakReference<>(v);
/*      */     }
/*      */     public void run() {
/*  385 */       if (this.villager.get() != null)
/*  386 */         ((EntityVillagerTek)this.villager.get()).randomizeGoals(); 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class BedCheckRunnable implements Runnable {
/*      */     private final WeakReference<EntityVillagerTek> villager;
/*      */     
/*      */     public BedCheckRunnable(EntityVillagerTek v) {
/*  394 */       this.villager = new WeakReference<>(v);
/*      */     }
/*      */     public void run() {
/*  397 */       if (this.villager.get() != null)
/*  398 */         ((EntityVillagerTek)this.villager.get()).bedCheck(); 
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setupServerJobs() {
/*  403 */     super.setupServerJobs();
/*      */     
/*  405 */     addJob(new TickJob(60, 120, true, new CleanUpRunnable(this)));
/*  406 */     addJob(new TickJob(23900, 200, true, new GoalRandomizerRunnable(this)));
/*      */ 
/*      */     
/*  409 */     addJob(new TickJob(80, 10, true, () -> {
/*      */             if (isStarving()) {
/*      */               func_70097_a(DamageSource.field_76366_f, 1.0F);
/*      */             }
/*      */           }));
/*      */ 
/*      */     
/*  416 */     addJob(new TickJob(30, 30, true, () -> scanForEnemies()));
/*      */     
/*  418 */     addJob(new TickJob(100, 200, true, () -> fixOffGraph()));
/*      */     
/*  420 */     addJob(new TickJob(200, 300, true, () -> dayCheck()));
/*      */     
/*  422 */     addJob(new TickJob(200, 100, true, () -> crowdingCheck()));
/*      */ 
/*      */     
/*  425 */     addJob(new TickJob(40, 100, true, new BedCheckRunnable(this)));
/*      */ 
/*      */     
/*  428 */     addJob(new TickJob(20, 30, false, () -> {
/*      */             VillageManager vm = VillageManager.get(this.field_70170_p);
/*      */             vm.addScanBox((new AxisAlignedBB(func_180425_c())).func_186662_g(64.0D));
/*      */           }));
/*      */   }
/*      */ 
/*      */   
/*      */   protected void func_110147_ax() {
/*  436 */     super.func_110147_ax();
/*  437 */     func_110140_aT().func_111150_b(MAX_HUNGER);
/*  438 */     func_110140_aT().func_111150_b(MAX_HAPPY);
/*  439 */     func_110140_aT().func_111150_b(MAX_INTELLIGENCE);
/*  440 */     func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(64.0D);
/*  441 */     func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.4D);
/*  442 */     func_110148_a(MAX_HUNGER).func_111128_a(100.0D);
/*  443 */     func_110148_a(MAX_HAPPY).func_111128_a(100.0D);
/*  444 */     func_110148_a(MAX_INTELLIGENCE).func_111128_a(100.0D);
/*  445 */     func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(20.0D);
/*      */     
/*  447 */     this.field_70180_af.func_187227_b(HUNGER, Integer.valueOf(getMaxHunger()));
/*  448 */     this.field_70180_af.func_187227_b(HAPPY, Integer.valueOf(getMaxHappy()));
/*  449 */     this.field_70180_af.func_187227_b(INTELLIGENCE, Integer.valueOf(getMaxIntelligence()));
/*  450 */     this.field_70180_af.func_187227_b(FORCE_AXIS, Integer.valueOf(-1));
/*  451 */     this.field_70180_af.func_187227_b(SLEEPING, Boolean.valueOf(false));
/*  452 */     this.field_70180_af.func_187227_b(SITTING, Boolean.valueOf(false));
/*  453 */     this.field_70180_af.func_187227_b(ACTION_ITEM, ItemStack.field_190927_a);
/*  454 */     this.field_70180_af.func_187227_b(MOVEMENT_MODE, Byte.valueOf(MovementMode.WALK.id));
/*  455 */     this.field_70180_af.func_187227_b(BLESSED, Integer.valueOf(0));
/*      */ 
/*      */     
/*  458 */     for (DataParameter<Integer> skill : SKILLS.values()) {
/*  459 */       this.field_70180_af.func_187227_b(skill, Integer.valueOf(0));
/*      */     }
/*      */     
/*  462 */     for (DataParameter<Boolean> aiFilter : this.aiFilters.values()) {
/*  463 */       this.field_70180_af.func_187227_b(aiFilter, Boolean.valueOf(true));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void func_70088_a() {
/*  469 */     this.aiFilters = new HashMap<>();
/*  470 */     registerAIFilter("read_book", READ_BOOK);
/*  471 */     registerAIFilter("visit_tavern", VISIT_TAVERN);
/*      */     
/*  473 */     this.field_70180_af.func_187214_a(HUNGER, Integer.valueOf(0));
/*  474 */     this.field_70180_af.func_187214_a(HAPPY, Integer.valueOf(0));
/*  475 */     this.field_70180_af.func_187214_a(INTELLIGENCE, Integer.valueOf(1));
/*  476 */     this.field_70180_af.func_187214_a(FORCE_AXIS, Integer.valueOf(-1));
/*  477 */     this.field_70180_af.func_187214_a(SLEEPING, Boolean.valueOf(false));
/*  478 */     this.field_70180_af.func_187214_a(SITTING, Boolean.valueOf(false));
/*  479 */     this.field_70180_af.func_187214_a(ACTION_ITEM, ItemStack.field_190927_a);
/*  480 */     this.field_70180_af.func_187214_a(MOVEMENT_MODE, Byte.valueOf((byte)0));
/*  481 */     this.field_70180_af.func_187214_a(BLESSED, Integer.valueOf(0));
/*      */     
/*  483 */     for (DataParameter<Integer> skill : SKILLS.values()) {
/*  484 */       this.field_70180_af.func_187214_a(skill, Integer.valueOf(0));
/*      */     }
/*      */     
/*  487 */     super.func_70088_a();
/*  488 */     onStopSit();
/*      */   }
/*      */   
/*      */   public boolean isAITick(String aiFilter) {
/*  492 */     return (isAITick() && isAIFilterEnabled(aiFilter));
/*      */   }
/*      */   
/*      */   protected boolean villageHasStorageCount(Predicate<ItemStack> pred, int count) {
/*  496 */     if (hasVillage()) {
/*  497 */       return (getVillage().getStorageCount(pred) >= count);
/*      */     }
/*      */     
/*  500 */     return false;
/*      */   }
/*      */   
/*      */   protected void crowdingCheck() {
/*  504 */     if (!isSleeping()) {
/*  505 */       VillageStructure struct = getCurrentStructure();
/*  506 */       if (struct != this.lastCrowdCheck) {
/*  507 */         this.lastCrowdCheck = struct;
/*  508 */         if (struct != null) {
/*  509 */           float crowdFactor = struct.getCrowdedFactor();
/*  510 */           if (crowdFactor > 0.0F) {
/*  511 */             int CROWD_PENALTY = -5;
/*  512 */             setThought(VillagerThought.CROWDED);
/*  513 */             int penalty = (int)(-5.0F * crowdFactor);
/*  514 */             modifyHappy(penalty);
/*  515 */             debugOut("Crowding penalty [" + penalty + "] in " + struct.type.name() + " at " + func_180425_c());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getDaysAlive() {
/*  523 */     return this.daysAlive;
/*      */   }
/*      */   
/*      */   protected void dayCheck() {
/*  527 */     int curTime = (int)Village.getTimeOfDay(this.field_70170_p);
/*  528 */     if (curTime < this.dayCheckTime) {
/*  529 */       this.dayCheckTime = curTime;
/*  530 */       this.daysAlive++;
/*  531 */       onNewDay();
/*      */     } else {
/*      */       
/*  534 */       this.dayCheckTime = curTime;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void onNewDay() {
/*  539 */     randomizeGoals();
/*      */   }
/*      */   
/*      */   protected void fixOffGraph() {
/*  543 */     if (!hasVillage()) {
/*  544 */       Village v = VillageManager.get(this.field_70170_p).getNearestVillage(func_180425_c(), 130);
/*  545 */       if (v != null) {
/*      */         
/*  547 */         BlockPos bestPos = null;
/*  548 */         double bestDist = Double.MAX_VALUE;
/*  549 */         for (BlockPos testPos : BlockPos.func_177980_a(func_180425_c().func_177982_a(-3, -3, -3), func_180425_c().func_177982_a(3, 3, 3))) {
/*  550 */           if (v.getPathingGraph().isInGraph(testPos)) {
/*  551 */             double dist = func_180425_c().func_177951_i((Vec3i)testPos);
/*  552 */             if (bestPos == null || dist < bestDist) {
/*  553 */               bestPos = testPos;
/*  554 */               bestDist = dist;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/*  559 */         if (bestPos != null) {
/*  560 */           func_70634_a(bestPos.func_177958_n(), bestPos.func_177956_o(), bestPos.func_177952_p());
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void scanForEnemies() {
/*  568 */     if (!isRole(VillagerRole.VENDOR) && !isRole(VillagerRole.VISITOR)) {
/*  569 */       ListIterator<EntityLiving> itr = this.field_70170_p.func_175647_a(EntityLiving.class, func_174813_aQ().func_72314_b(30.0D, 6.0D, 30.0D), isEnemy()).listIterator();
/*  570 */       while (itr.hasNext()) {
/*  571 */         EntityLiving enemy = itr.next();
/*  572 */         if (func_70685_l((Entity)enemy) && hasVillage()) {
/*  573 */           getVillage().addOrRenewEnemy((EntityLivingBase)enemy, 1);
/*      */         }
/*  575 */         IAttributeInstance attribute = enemy.func_110148_a(SharedMonsterAttributes.field_111265_b);
/*  576 */         if (attribute != null) {
/*  577 */           double distMe = enemy.func_70068_e((Entity)this);
/*  578 */           double enemyRange = attribute.func_111126_e() * attribute.func_111126_e();
/*      */           
/*  580 */           if (distMe < enemyRange) {
/*      */             
/*  582 */             if (enemy.func_70638_az() == null) {
/*  583 */               enemy.func_70624_b((EntityLivingBase)this);
/*      */               continue;
/*      */             } 
/*  586 */             double distTarget = enemy.func_70068_e((Entity)enemy.func_70638_az());
/*      */             
/*  588 */             if (distMe < distTarget) {
/*  589 */               enemy.func_70624_b((EntityLivingBase)this); continue;
/*  590 */             }  if (hasVillage()) {
/*  591 */               boolean meIndoors = getVillage().isInStructure(func_180425_c());
/*  592 */               boolean currentTargetIndoors = getVillage().isInStructure(enemy.func_70638_az().func_180425_c());
/*      */               
/*  594 */               if (!meIndoors && currentTargetIndoors) {
/*  595 */                 enemy.func_70624_b((EntityLivingBase)this);
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void func_70675_k(float damage) {
/*  607 */     if (damage < 1.0F)
/*      */     {
/*  609 */       damage = 1.0F;
/*      */     }
/*      */     
/*  612 */     int finalDmg = (int)damage;
/*  613 */     func_184193_aE().forEach(a -> {
/*      */           if (a.func_77973_b() instanceof net.minecraft.item.ItemArmor && func_70681_au().nextBoolean()) {
/*      */             damageItem(a, finalDmg);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void damageItem(ItemStack itemStack, int amount) {
/*  622 */     int itemDamage = ModItems.isTaggedItem(itemStack, ItemTagType.VILLAGER) ? amount : (amount * 5);
/*      */     
/*  624 */     ItemStack oldItem = null;
/*  625 */     if (itemStack.func_77952_i() + itemDamage >= itemStack.func_77958_k()) {
/*  626 */       oldItem = itemStack.func_77946_l();
/*      */     }
/*  628 */     itemStack.func_77972_a(itemDamage, (EntityLivingBase)this);
/*      */     
/*  630 */     if (itemStack.func_190926_b() && oldItem != null) {
/*  631 */       onInventoryUpdated(oldItem);
/*      */     }
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   public Entity changeDimension(int dimensionIn, ITeleporter teleporter) {
/*  637 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean func_70104_M() {
/*  642 */     if (isSitting() || isSleeping()) {
/*  643 */       return false;
/*      */     }
/*  645 */     return super.func_70104_M();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void func_82167_n(Entity entityIn) {
/*  650 */     if (!isSitting()) {
/*  651 */       if (entityIn instanceof EntityVillagerTek && 
/*  652 */         isDoorNearby(1, 1)) {
/*      */         return;
/*      */       }
/*      */       
/*  656 */       super.func_82167_n(entityIn);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void func_85033_bc() {
/*  662 */     if (!isSitting() && !isSleeping())
/*  663 */       super.func_85033_bc(); 
/*      */   }
/*      */   
/*      */   protected boolean isDoorNearby(int xx, int zz) {
/*  667 */     for (int x = -xx; x <= xx; x++) {
/*  668 */       for (int z = -zz; z <= zz; z++) {
/*  669 */         BlockPos bp = func_180425_c().func_177965_g(x).func_177964_d(z);
/*  670 */         if (VillageStructure.isWoodDoor(this.field_70170_p, bp) || VillageStructure.isGate(this.field_70170_p, bp)) {
/*  671 */           return true;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  676 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected SoundEvent func_184639_G() {
/*  681 */     if (isSleeping() && 
/*  682 */       this.field_70170_p.field_73012_v.nextInt(2) == 0) {
/*  683 */       return ModSoundEvents.villagerSleep;
/*      */     }
/*  685 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void bedCheck() {
/*  690 */     if (hasVillage()) {
/*  691 */       if (getBedPos() != null && this.homeFrame != null) {
/*  692 */         VillageStructure struct = this.village.getStructureFromFrame(this.homeFrame);
/*  693 */         if (struct != null && struct instanceof VillageStructureHome) {
/*  694 */           VillageStructureHome home = (VillageStructureHome)struct;
/*  695 */           if (!home.canVillagerSleep(this)) {
/*  696 */             clearHome();
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  701 */       if (getBedPos() == null) {
/*  702 */         if (this.homeFrame != null) {
/*      */           
/*  704 */           VillageStructure struct = this.village.getStructureFromFrame(this.homeFrame);
/*  705 */           if (struct != null && struct instanceof VillageStructureHome) {
/*  706 */             VillageStructureHome home = (VillageStructureHome)struct;
/*  707 */             if (home.canVillagerSleep(this) && !home.isFull()) {
/*  708 */               this.homeFrame = null;
/*  709 */               home.addResident(this);
/*      */             } else {
/*  711 */               clearHome();
/*      */             } 
/*  713 */           } else if (this.field_70173_aa > 200) {
/*      */             
/*  715 */             clearHome();
/*      */           } 
/*      */         } else {
/*  718 */           VillageStructureHome home = this.village.getAvailableHome(this);
/*  719 */           if (home != null) {
/*  720 */             home.addResident(this);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public VillageStructure getCurrentStructure() {
/*  728 */     if (hasVillage()) {
/*  729 */       return getVillage().getStructure(func_180425_c());
/*      */     }
/*  731 */     return null;
/*      */   }
/*      */   
/*      */   public static Function<EntityVillagerTek, VillageStructure> findLocalTavern() {
/*  735 */     return p -> {
/*      */         if (p.hasVillage()) {
/*      */           VillageStructure tavern = p.getVillage().getNearestStructure(VillageStructureType.TAVERN, p.func_180425_c());
/*      */           if (tavern != null) {
/*      */             return tavern;
/*      */           }
/*      */         } 
/*      */         return null;
/*      */       };
/*      */   }
/*      */   
/*      */   public static Function<EntityVillagerTek, VillageStructure> getVillagerHome() {
/*  747 */     return p -> p.func_110175_bO() ? p.getVillage().getStructureFromFrame(p.homeFrame) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void attachToVillage(Village v) {
/*  757 */     super.attachToVillage(v);
/*      */     
/*  759 */     this.sleepOffset = genOffset(400);
/*      */     
/*  761 */     if (isRole(VillagerRole.VILLAGER)) {
/*  762 */       v.addResident(this);
/*      */     }
/*      */     
/*  765 */     if (getIntelligence() < 1) {
/*  766 */       setIntelligence(1);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void detachVillage() {
/*  771 */     if (hasVillage()) {
/*  772 */       this.village.removeResident(this);
/*      */     }
/*  774 */     super.detachVillage();
/*      */   }
/*      */   
/*      */   protected int genOffset(int range) {
/*  778 */     return func_70681_au().nextInt(range) - range / 2;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void randomizeGoals() {
/*  784 */     if (func_70681_au().nextInt(100) < 28 && getIntelligence() < getMaxIntelligence()) {
/*  785 */       this.wantsLearning = func_70681_au().nextInt(6) + 3;
/*      */     } else {
/*  787 */       this.wantsLearning = 0;
/*      */     } 
/*      */     
/*  790 */     this.wantsTavern = (func_70681_au().nextInt(10) < 3);
/*      */   }
/*      */   
/*      */   private static void cleanUpInventory(EntityVillagerTek v) {
/*  794 */     v.cleanUpInventory();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void cleanUpInventory() {}
/*      */   
/*      */   protected void func_70670_a(PotionEffect effect) {
/*  801 */     if (effect.func_188419_a() == ModPotions.potionBless) {
/*  802 */       this.field_70180_af.func_187227_b(BLESSED, Integer.valueOf(effect.func_76458_c()));
/*      */     }
/*      */     
/*  805 */     super.func_70670_a(effect);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void func_70688_c(PotionEffect effect) {
/*  810 */     if (effect.func_188419_a() == ModPotions.potionBless) {
/*  811 */       this.field_70180_af.func_187227_b(BLESSED, Integer.valueOf(0));
/*      */     }
/*      */     
/*  814 */     super.func_70688_c(effect);
/*      */   }
/*      */   
/*      */   public void func_70636_d() {
/*  818 */     super.func_70636_d();
/*      */     
/*  820 */     if (func_110167_bD() && func_70681_au().nextInt((getHappy() < 50) ? 30 : 50) == 0) {
/*  821 */       modifyHappy(-1);
/*  822 */       if (getHappy() <= 0) {
/*  823 */         func_110160_i(true, true);
/*      */       }
/*      */     } 
/*      */     
/*  827 */     if (!isWorldRemote()) {
/*  828 */       this.lastSadTick++;
/*      */       
/*  830 */       if (this.nextThought != null && this.field_70173_aa % 80 == 0) {
/*  831 */         TekVillager.NETWORK.sendToAllAround((IMessage)this.nextThought, new NetworkRegistry.TargetPoint(getDimension(), this.field_70165_t, this.field_70163_u, this.field_70161_v, 64.0D));
/*  832 */         this.nextThought = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   protected void startWalking() {
/*  840 */     MovementMode mode = getMovementMode();
/*  841 */     if (mode != this.lastMovementMode) {
/*  842 */       if (this.lastMovementMode != null) {
/*  843 */         stopWalking();
/*      */       }
/*      */       
/*  846 */       this.lastMovementMode = mode;
/*      */       
/*  848 */       if (mode != null) {
/*  849 */         playClientAnimation(mode.anim);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   protected void stopWalking() {
/*  857 */     if (this.lastMovementMode != null) {
/*  858 */       stopClientAnimation(this.lastMovementMode.anim);
/*  859 */       this.lastMovementMode = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public BlockPos getBedPos() {
/*  864 */     return this.bedPos;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   public void func_180426_a(double x, double y, double z, float yaw, float pitch, int posRotationIncrements, boolean teleport) {
/*  873 */     super.func_180426_a(x, y, z, yaw, pitch, 1, teleport);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setHome(BlockPos bedPos, BlockPos homeFrame) {
/*  878 */     this.bedPos = bedPos;
/*  879 */     this.homeFrame = homeFrame;
/*      */   }
/*      */   
/*      */   public void clearHome() {
/*  883 */     this.bedPos = null;
/*  884 */     this.homeFrame = null;
/*      */   }
/*      */   
/*      */   public boolean func_110175_bO() {
/*  888 */     return (hasVillage() && this.homeFrame != null);
/*      */   }
/*      */   
/*      */   public VillageStructureHome getHome() {
/*  892 */     if (func_110175_bO()) {
/*  893 */       VillageStructureHome home = (VillageStructureHome)this.village.getStructureFromFrame(this.homeFrame);
/*  894 */       return home;
/*      */     } 
/*      */     
/*  897 */     return null;
/*      */   }
/*      */   
/*      */   public void addVillagerPosition() {
/*  901 */     if (hasVillage()) {
/*  902 */       getVillage().addVillagerPosition(this);
/*      */     }
/*      */   }
/*      */   
/*      */   public final int getMaxHunger() {
/*  907 */     return (int)func_110148_a(MAX_HUNGER).func_111126_e();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getHunger() {
/*  912 */     return ((Integer)this.field_70180_af.func_187225_a(HUNGER)).intValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setHunger(int hunger) {
/*  917 */     if (isRole(VillagerRole.VILLAGER)) {
/*  918 */       this.field_70180_af.func_187227_b(HUNGER, Integer.valueOf(MathHelper.func_76125_a(hunger, 0, getMaxHunger())));
/*  919 */       if (hunger < 0 && isHungry())
/*      */       {
/*  921 */         setThought(VillagerThought.HUNGRY);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getMaxHappy() {
/*  928 */     return (int)func_110148_a(MAX_HAPPY).func_111126_e();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getHappy() {
/*  933 */     return ((Integer)this.field_70180_af.func_187225_a(HAPPY)).intValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public int setHappy(int happy) {
/*  938 */     int prevHappy = getHappy();
/*  939 */     this.field_70180_af.func_187227_b(HAPPY, Integer.valueOf(MathHelper.func_76125_a(happy, 0, getMaxHappy())));
/*  940 */     return getHappy() - prevHappy;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getMaxIntelligence() {
/*  945 */     return (int)func_110148_a(MAX_INTELLIGENCE).func_111126_e();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getIntelligence() {
/*  950 */     int intel = Math.max(((Integer)this.field_70180_af.func_187225_a(INTELLIGENCE)).intValue(), 1);
/*  951 */     return intel;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setIntelligence(int intel) {
/*  956 */     this.field_70180_af.func_187227_b(INTELLIGENCE, Integer.valueOf(MathHelper.func_76125_a(intel, 1, getMaxIntelligence())));
/*      */   }
/*      */   
/*      */   public int getBlessed() {
/*  960 */     return ((Integer)this.field_70180_af.func_187225_a(BLESSED)).intValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getSkill(ProfessionType pt) {
/*  965 */     int skill = getBaseSkill(pt);
/*      */     
/*  967 */     if (pt == getProfessionType()) {
/*  968 */       skill += getBlessed();
/*      */     }
/*  970 */     return Math.min(skill, 100);
/*      */   }
/*      */   
/*      */   public int getBaseSkill(ProfessionType pt) {
/*  974 */     int skill = ((Integer)this.field_70180_af.func_187225_a(SKILLS.get(pt))).intValue();
/*  975 */     return Math.min(skill, 100);
/*      */   }
/*      */   
/*      */   public int getSkillLerp(ProfessionType pt, int min, int max) {
/*  979 */     if (min < max) {
/*  980 */       return (int)MathHelper.func_151238_b(min, max, getSkill(pt) / 100.0D);
/*      */     }
/*  982 */     return (int)MathHelper.func_151238_b(max, min, (100.0D - getSkill(pt)) / 100.0D);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSkill(ProfessionType pt, int val) {
/*  987 */     debugOut("Skill Change - " + pt.name + " --> " + val);
/*  988 */     this.field_70180_af.func_187227_b(SKILLS.get(pt), Integer.valueOf(MathHelper.func_76125_a(val, 0, 100)));
/*      */   }
/*      */   
/*      */   public int getForceAxis() {
/*  992 */     return ((Integer)this.field_70180_af.func_187225_a(FORCE_AXIS)).intValue();
/*      */   }
/*      */   
/*      */   public void setForceAxis(int axes) {
/*  996 */     this.field_70180_af.func_187227_b(FORCE_AXIS, Integer.valueOf(axes));
/*      */   }
/*      */   
/*      */   public boolean isSleeping() {
/* 1000 */     return ((Boolean)this.field_70180_af.func_187225_a(SLEEPING)).booleanValue();
/*      */   }
/*      */   public boolean isSitting() {
/* 1003 */     return ((Boolean)this.field_70180_af.func_187225_a(SITTING)).booleanValue();
/*      */   }
/*      */   
/*      */   public MovementMode getMovementMode() {
/* 1007 */     MovementMode mode = MovementMode.valueOf(((Byte)this.field_70180_af.func_187225_a(MOVEMENT_MODE)).byteValue());
/* 1008 */     return mode;
/*      */   }
/*      */   
/*      */   public void setMovementMode(MovementMode mode) {
/* 1012 */     this.field_70180_af.func_187227_b(MOVEMENT_MODE, Byte.valueOf(mode.id));
/*      */   }
/*      */   
/*      */   protected void setSleeping(boolean sleep) {
/* 1016 */     this.field_70180_af.func_187227_b(SLEEPING, Boolean.valueOf(sleep));
/*      */   } public void setSitting(boolean sit) {
/* 1018 */     this.field_70180_af.func_187227_b(SITTING, Boolean.valueOf(sit));
/*      */   }
/* 1020 */   public boolean isHungry() { return (getHunger() < 30); } public boolean isStarving() {
/* 1021 */     return (getHunger() <= 0);
/*      */   }
/*      */   public boolean shouldSleep() {
/* 1024 */     return (isSleepingTime() || (!isRole(VillagerRole.DEFENDER) && func_110143_aJ() < func_110138_aP() * 0.5F));
/*      */   }
/*      */   
/*      */   public boolean isSleepingTime() {
/* 1028 */     if (Village.isTimeOfDay(this.field_70170_p, (SLEEP_START_TIME + this.sleepOffset + (wantsTavern() ? 4000 : 0)), (SLEEP_END_TIME + this.sleepOffset))) {
/* 1029 */       return true;
/*      */     }
/*      */     
/* 1032 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isWorkTime() {
/* 1036 */     return (Village.isTimeOfDay(this.field_70170_p, WORK_START_TIME, WORK_END_TIME, this.sleepOffset) && !this.field_70170_p.func_72896_J());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLearningTime() {
/* 1042 */     if (this.wantsLearning > 0 && Village.isTimeOfDay(this.field_70170_p, (this.sleepOffset + 2500), (this.sleepOffset + 8000))) {
/* 1043 */       return isAIFilterEnabled("read_book");
/*      */     }
/*      */     
/* 1046 */     return false;
/*      */   }
/*      */   
/*      */   public void addIntelligence(int delta) {
/* 1050 */     if (delta > 0 && getIntelligence() < 100)
/*      */     {
/*      */       
/* 1053 */       if (func_70681_au().nextInt(100) * 2 > getIntelligence()) {
/* 1054 */         setIntelligence(getIntelligence() + delta);
/* 1055 */         setItemThought(Items.field_151122_aG);
/* 1056 */         this.wantsLearning--;
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   public void addIntelligenceDelay(int delta, int ticks) {
/* 1062 */     addJob(new TickJob(ticks, 0, false, () -> addIntelligence(delta)));
/*      */   }
/*      */   
/*      */   public void incrementSkill(ProfessionType pt) {
/* 1066 */     setSkill(pt, getBaseSkill(pt) + 1);
/* 1067 */     setItemThought((Item)ModItems.getProfessionToken(pt));
/* 1068 */     skillUpdated(pt);
/*      */ 
/*      */     
/* 1071 */     if (!func_70631_g_()) {
/* 1072 */       List<EntityChild> children = this.field_70170_p.func_72872_a(EntityChild.class, func_174813_aQ().func_72314_b(12.0D, 8.0D, 12.0D));
/* 1073 */       if (!children.isEmpty()) {
/* 1074 */         children.forEach(c -> {
/*      */               boolean proximityLearn = true;
/*      */               if (c.hasVillage()) {
/*      */                 VillageStructure struct = c.getVillage().getStructure(c.func_180425_c());
/*      */                 if (struct != null && struct instanceof net.tangotek.tektopia.structures.VillageStructureSchool) {
/*      */                   proximityLearn = false;
/*      */                 }
/*      */               } 
/*      */               if (proximityLearn && c.getSkill(pt) < getSkill(pt) / 2) {
/*      */                 int chance = Math.max(c.getBaseSkill(pt) / 2, 1);
/*      */                 if (c.func_70681_au().nextInt(chance) == 0) {
/*      */                   c.incrementSkill(pt);
/*      */                 }
/*      */               } 
/*      */             });
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setIdle(int idle) {
/* 1095 */     this.idle = idle;
/*      */   }
/*      */   
/*      */   public int getIdle() {
/* 1099 */     return this.idle;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void skillUpdated(ProfessionType pt) {}
/*      */   
/*      */   public void tryAddSkill(ProfessionType pt, int chance) {
/* 1106 */     if (!this.field_70170_p.field_72995_K) {
/* 1107 */       double skill = getBaseSkill(pt);
/* 1108 */       if (skill < 100.0D) {
/* 1109 */         double intel = Math.max(getIntelligence(), 5.0D);
/*      */         
/* 1111 */         double gapMod = 1.0D / Math.pow(skill / intel, 2.0D);
/*      */ 
/*      */ 
/*      */         
/* 1115 */         double intMod = 0.2D;
/*      */         
/* 1117 */         double intCheck = Math.min(gapMod * 0.2D, 1.0D);
/*      */ 
/*      */         
/* 1120 */         int rate = FMLCommonHandler.instance().getMinecraftServerInstance().func_71218_a(0).func_82736_K().func_180263_c("villagerSkillRate");
/*      */         
/* 1122 */         double roll = this.field_70170_p.field_73012_v.nextDouble();
/* 1123 */         double rollModded = roll * rate / 100.0D;
/* 1124 */         if (rollModded <= intCheck && 
/* 1125 */           this.field_70170_p.field_73012_v.nextInt(chance) == 0) {
/* 1126 */           incrementSkill(pt);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void modifyHungerDelay(int delta, int ticks) {
/* 1134 */     addJob(new TickJob(ticks, 0, false, () -> modifyHunger(delta)));
/*      */   }
/*      */ 
/*      */   
/*      */   public void modifyHunger(int delta) {
/* 1139 */     if (delta < 0 && hasVillage() && !getVillage().hasStructure(VillageStructureType.STORAGE)) {
/*      */       return;
/*      */     }
/* 1142 */     setHunger(getHunger() + delta);
/*      */   }
/*      */   
/*      */   public void modifyHappyDelay(int delta, int ticks) {
/* 1146 */     addJob(new TickJob(ticks, 0, false, () -> modifyHappy(delta)));
/*      */   }
/*      */   
/*      */   public void modifyHappy(int delta) {
/* 1150 */     if (delta > 0) {
/* 1151 */       this.field_70170_p.func_72960_a((Entity)this, (byte)14);
/*      */       
/* 1153 */       if (func_70681_au().nextInt(6) == 0 && !isSleeping()) {
/* 1154 */         playSound(ModSoundEvents.villagerHappy);
/*      */       }
/* 1156 */     } else if (delta < 0) {
/* 1157 */       this.field_70170_p.func_72960_a((Entity)this, (byte)13);
/* 1158 */       if (func_70681_au().nextInt(2) == 0 && !isSleeping()) {
/* 1159 */         playSound(ModSoundEvents.villagerAngry);
/*      */       }
/*      */     } 
/* 1162 */     int realChange = setHappy(getHappy() + delta);
/*      */     
/* 1164 */     if (hasVillage() && realChange != 0)
/* 1165 */       getVillage().trackHappy(realChange); 
/*      */   }
/*      */   
/*      */   public void throttledSadness(int delta) {
/* 1169 */     if (this.lastSadTick > this.lastSadThrottle && func_70681_au().nextBoolean()) {
/* 1170 */       addJob(new TickJob(20, 60, false, () -> modifyHappy(delta)));
/* 1171 */       this.lastSadTick = 0;
/* 1172 */       this.lastSadThrottle = 50 + func_70681_au().nextInt(100);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void cheerBeer(int happy) {
/* 1177 */     int offset = func_70681_au().nextInt(25);
/* 1178 */     if (!isPlayingAnimation("villager_sit_cheer")) {
/* 1179 */       if (isSitting()) {
/* 1180 */         addJob(new TickJob(offset, 0, false, () -> playServerAnimation("villager_sit_cheer")));
/* 1181 */         addJob(new TickJob(8 + offset, 0, false, () -> equipActionItem(new ItemStack((Item)ModItems.beer))));
/* 1182 */         addJob(new TickJob(52 + offset, 0, false, () -> unequipActionItem()));
/* 1183 */         addJob(new TickJob(58 + offset, 0, false, () -> {
/*      */                 if (isSitting()) {
/*      */                   playServerAnimation("villager_sit");
/*      */                 }
/*      */               }));
/*      */       } 
/* 1189 */       addJob(new TickJob(10 + offset * 2, 0, false, () -> func_184185_a(ModSoundEvents.villagerHappy, 1.2F, func_70681_au().nextFloat() * 0.4F + 0.8F)));
/* 1190 */       addJob(new TickJob(40, 0, false, () -> modifyHappy(happy)));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void func_184178_b(EntityPlayerMP player) {
/* 1197 */     super.func_184178_b(player);
/*      */ 
/*      */     
/* 1200 */     if (!this.curAnim.isEmpty()) {
/* 1201 */       playServerAnimation(this.curAnim);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float func_70689_ay() {
/* 1208 */     float baseSpeed = 0.45F * (getMovementMode()).speedMult;
/*      */     
/* 1210 */     float modifiedSpeed = baseSpeed;
/*      */     
/* 1212 */     int blessed = getBlessed();
/* 1213 */     if (blessed > 0) {
/* 1214 */       modifiedSpeed = (float)(modifiedSpeed * (1.05D + blessed * 0.002D));
/*      */     }
/* 1216 */     return modifiedSpeed;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLeadAnimal(EntityAnimal animal) {
/* 1221 */     this.leadAnimal = animal;
/*      */   }
/*      */   
/*      */   public EntityAnimal getLeadAnimal() {
/* 1225 */     return this.leadAnimal;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean func_70692_ba() {
/* 1230 */     return false;
/*      */   }
/*      */   
/*      */   public VillagerInventory getInventory() {
/* 1234 */     return this.villagerInventory;
/*      */   }
/*      */   
/*      */   public ItemDesireSet getDesireSet() {
/* 1238 */     return this.desireSet;
/*      */   }
/*      */ 
/*      */   
/*      */   public void onStorageChange(ItemStack storageItem) {
/* 1243 */     this.desireSet.onStorageUpdated(this, storageItem);
/*      */   }
/*      */ 
/*      */   
/*      */   public void onInventoryUpdated(ItemStack updatedItem) {
/* 1248 */     this.desireSet.onInventoryUpdated(this, updatedItem);
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean canVillagerPickupItem(ItemStack itemIn) {
/* 1253 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean func_189652_ae() {
/* 1258 */     return (isSitting() || super.func_189652_ae());
/*      */   }
/*      */   
/*      */   public double getSitOffset() {
/* 1262 */     return 0.0D;
/*      */   }
/*      */   
/*      */   public void onStartSit(int sitAxis) {
/* 1266 */     setForceAxis(sitAxis);
/* 1267 */     setSitting(true);
/* 1268 */     equipActionItem(ModItems.EMPTY_HAND_ITEM);
/* 1269 */     if (!this.curAnim.isEmpty() && this.curAnim != "villager_sit") {
/* 1270 */       stopServerAnimation(this.curAnim);
/*      */     }
/* 1272 */     playServerAnimation("villager_sit");
/*      */   }
/*      */   
/*      */   public void onStopSit() {
/* 1276 */     setSitting(false);
/* 1277 */     setForceAxis(-1);
/* 1278 */     stopServerAnimation("villager_sit");
/* 1279 */     func_189654_d(false);
/* 1280 */     unequipActionItem(ModItems.EMPTY_HAND_ITEM);
/*      */   }
/*      */ 
/*      */   
/*      */   public void onStartSleep(int sleepAxis) {
/* 1285 */     setForceAxis(sleepAxis);
/* 1286 */     setSleeping(true);
/* 1287 */     if (!this.curAnim.isEmpty() && this.curAnim != "villager_sleep") {
/* 1288 */       stopServerAnimation(this.curAnim);
/*      */     }
/* 1290 */     playServerAnimation("villager_sleep");
/*      */   }
/*      */   
/*      */   public void onStopSleep() {
/* 1294 */     if (isSleeping() && 
/* 1295 */       !isSleepingTime()) {
/*      */ 
/*      */       
/* 1298 */       checkSpawnHeart();
/*      */       
/* 1300 */       modifyHappy(this.field_70146_Z.nextInt(20) + 10);
/*      */     } 
/*      */ 
/*      */     
/* 1304 */     setForceAxis(-1);
/* 1305 */     setSleeping(false);
/* 1306 */     stopServerAnimation("villager_sleep");
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkSpawnHeart() {
/* 1311 */     int MIN_HAPPY = (int)(getMaxHappy() * 0.7F);
/* 1312 */     if (hasVillage() && getHappy() >= MIN_HAPPY) {
/*      */       
/* 1314 */       float happyFactor = (getMaxHappy() - getHappy()) / (getMaxHappy() - MIN_HAPPY);
/* 1315 */       int CONSTANT_DIFFICULTY = 15;
/* 1316 */       int chance = 15 + this.village.getResidentCount() + (int)(this.village.getResidentCount() * happyFactor * 2.0F);
/* 1317 */       if (func_70681_au().nextInt(chance) == 0 && 
/* 1318 */         hasVillage() && !func_70631_g_() && getProfessionType() != ProfessionType.NITWIT) {
/* 1319 */         IVillageData vd = getVillage().getTownData();
/* 1320 */         if (vd != null && this.bedPos != null && 
/* 1321 */           vd.isChildReady(this.field_70170_p.func_82737_E())) {
/* 1322 */           VillageStructure struct = getVillagerHome().apply(this);
/* 1323 */           if (struct != null && struct.type.isHome()) {
/* 1324 */             VillageStructureHome home = (VillageStructureHome)struct;
/* 1325 */             vd.childSpawned(this.field_70170_p);
/* 1326 */             addJob(new TickJob(100, 0, false, () -> {
/*      */                     ItemStack itemHeart = ModItems.createTaggedItem((Item)ModItems.heart, ItemTagType.VILLAGER);
/*      */                     itemHeart.func_179543_a("village").func_186854_a("parent", func_110124_au());
/*      */                     EntityItem heartEntity = new EntityItem(this.field_70170_p, this.bedPos.func_177958_n(), (this.bedPos.func_177956_o() + 1), this.bedPos.func_177952_p(), itemHeart);
/*      */                     this.field_70170_p.func_72838_d((Entity)heartEntity);
/*      */                   }));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MovementMode getDefaultMovement() {
/* 1343 */     if (getHappy() < getMaxHappy() / 5) {
/* 1344 */       return MovementMode.SULK;
/*      */     }
/* 1346 */     return MovementMode.WALK;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateMovement(boolean arrived) {
/* 1362 */     if (this.field_70170_p.field_73012_v.nextInt(50) == 0) {
/* 1363 */       modifyHunger(-1);
/*      */     }
/* 1365 */     if (!arrived)
/*      */     {
/*      */       
/* 1368 */       if (hasVillage() && func_70681_au().nextInt(20) == 0) {
/* 1369 */         addVillagerPosition();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void resetMovement() {
/* 1375 */     super.resetMovement();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected ItemStack modifyPickUpStack(ItemStack itemStack) {
/* 1381 */     return itemStack;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void func_175445_a(EntityItem itemEntity) {
/* 1387 */     ItemStack itemStack = itemEntity.func_92059_d();
/*      */     
/* 1389 */     if (canVillagerPickupItem(itemStack) && ModItems.canVillagerSee(itemStack)) {
/*      */       
/* 1391 */       ItemStack modStack = modifyPickUpStack(itemStack.func_77946_l());
/* 1392 */       if (!modStack.func_190926_b()) {
/* 1393 */         ItemStack leftOverStack = this.villagerInventory.func_174894_a(modStack);
/*      */         
/* 1395 */         if (leftOverStack.func_190926_b()) {
/* 1396 */           itemEntity.func_70106_y();
/*      */         } else {
/* 1398 */           int actuallyTaken = modStack.func_190916_E() - leftOverStack.func_190916_E();
/* 1399 */           int newCount = itemStack.func_190916_E() - actuallyTaken;
/* 1400 */           if (newCount <= 0) {
/* 1401 */             itemEntity.func_70106_y();
/*      */           } else {
/* 1403 */             itemStack.func_190920_e(newCount);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean func_180431_b(DamageSource source) {
/* 1412 */     if (source == DamageSource.field_76368_d) {
/* 1413 */       return true;
/*      */     }
/*      */     
/* 1416 */     return super.func_180431_b(source);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean func_70097_a(DamageSource source, float amount) {
/* 1421 */     float beforeHealth = func_110143_aJ();
/* 1422 */     if (super.func_70097_a(source, amount)) {
/* 1423 */       float afterHealth = func_110143_aJ();
/*      */       
/* 1425 */       float actualDamage = beforeHealth - afterHealth;
/* 1426 */       if (actualDamage > 0.0F) {
/*      */         
/* 1428 */         if (!isRole(VillagerRole.DEFENDER)) {
/* 1429 */           modifyHappy(-8);
/*      */         }
/* 1431 */         if (hasVillage() && actualDamage > 0.0F) {
/* 1432 */           getVillage().reportVillagerDamage(this, source, actualDamage);
/*      */         }
/* 1434 */         if (isSleeping()) {
/* 1435 */           onStopSleep();
/*      */         }
/*      */       } 
/*      */       
/* 1439 */       return true;
/*      */     } 
/*      */     
/* 1442 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void func_70645_a(DamageSource cause) {
/* 1468 */     if (hasVillage() && getBedPos() != null) {
/* 1469 */       int happyMod = -25;
/* 1470 */       if (func_70631_g_()) {
/* 1471 */         happyMod *= 2;
/*      */       }
/* 1473 */       List<EntityVillagerTek> villagers = this.field_70170_p.func_175647_a(EntityVillagerTek.class, func_174813_aQ().func_186662_g(200.0D), p -> (p != this));
/* 1474 */       for (EntityVillagerTek v : villagers) {
/* 1475 */         if (v.getVillage() == getVillage() && v.getBedPos() != null && !v.isSleeping()) {
/* 1476 */           v.modifyHappy(happyMod - func_70681_au().nextInt(15));
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1481 */     if (hasVillage() && isRole(VillagerRole.VILLAGER)) {
/* 1482 */       getVillage().reportVillagerDeath(this, cause);
/*      */     }
/* 1484 */     super.func_70645_a(cause);
/*      */     
/* 1486 */     if (!this.field_70170_p.field_72995_K)
/* 1487 */       dropAllItems(); 
/*      */   }
/*      */   
/*      */   private void dropAllItems() {
/* 1491 */     VillagerInventory villagerInventory = getInventory();
/* 1492 */     for (int i = 0; i < villagerInventory.func_70302_i_(); i++) {
/*      */       
/* 1494 */       ItemStack itemStack = villagerInventory.func_70301_a(i);
/* 1495 */       if (!itemStack.func_190926_b())
/*      */       {
/* 1497 */         func_70099_a(itemStack, 0.5F);
/*      */       }
/*      */     } 
/* 1500 */     villagerInventory.func_174888_l();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pickupItems(int grow) {
/* 1510 */     for (EntityItem entityitem : this.field_70170_p.func_72872_a(EntityItem.class, func_174813_aQ().func_72314_b(grow, 3.0D, grow))) {
/*      */       
/* 1512 */       if (!entityitem.field_70128_L && !entityitem.func_92059_d().func_190926_b() && !entityitem.func_174874_s())
/*      */       {
/* 1514 */         func_175445_a(entityitem);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setThought(VillagerThought thought) {
/* 1520 */     this.nextThought = new PacketVillagerThought(this, thought, thought.getScale());
/*      */   }
/*      */   
/*      */   public void setItemThought(Item item) {
/* 1524 */     ModEntities.sendItemThought((Entity)this, item);
/*      */   }
/*      */ 
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   public void func_70103_a(byte id) {
/* 1530 */     if (id == 12) {
/*      */       
/* 1532 */       spawnParticles(EnumParticleTypes.HEART);
/*      */     }
/* 1534 */     else if (id == 13) {
/*      */       
/* 1536 */       spawnParticles(EnumParticleTypes.VILLAGER_ANGRY);
/*      */     }
/* 1538 */     else if (id == 14) {
/*      */       
/* 1540 */       spawnParticles(EnumParticleTypes.VILLAGER_HAPPY);
/*      */     }
/*      */     else {
/*      */       
/* 1544 */       super.func_70103_a(id);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   private void spawnParticles(EnumParticleTypes particleType) {
/* 1551 */     for (int i = 0; i < 5; i++) {
/*      */       
/* 1553 */       double d0 = this.field_70146_Z.nextGaussian() * 0.02D;
/* 1554 */       double d1 = this.field_70146_Z.nextGaussian() * 0.02D;
/* 1555 */       double d2 = this.field_70146_Z.nextGaussian() * 0.02D;
/* 1556 */       this.field_70170_p.func_175688_a(particleType, this.field_70165_t + (this.field_70146_Z.nextFloat() * this.field_70130_N * 2.0F) - this.field_70130_N, this.field_70163_u + 1.0D + (this.field_70146_Z.nextFloat() * this.field_70131_O), this.field_70161_v + (this.field_70146_Z.nextFloat() * this.field_70130_N * 2.0F) - this.field_70130_N, d0, d1, d2, new int[0]);
/*      */     } 
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   public void handleThought(PacketVillagerThought msg) {
/* 1562 */     ParticleThought part = new ParticleThought(this.field_70170_p, Minecraft.func_71410_x().func_110434_K(), (Entity)this, msg.getScale(), msg.getThought().getTex());
/* 1563 */     (Minecraft.func_71410_x()).field_71452_i.func_78873_a((Particle)part);
/*      */   }
/*      */   
/*      */   public boolean func_184645_a(EntityPlayer player, EnumHand hand) {
/* 1567 */     ItemStack itemStack = player.func_184586_b(hand);
/*      */     
/* 1569 */     if (itemStack.func_77973_b() == Items.field_151057_cb) {
/*      */       
/* 1571 */       itemStack.func_111282_a(player, (EntityLivingBase)this, hand);
/* 1572 */       return true;
/*      */     } 
/* 1574 */     if (itemStack.func_77973_b() instanceof ItemProfessionToken && hasVillage()) {
/* 1575 */       ItemProfessionToken token = (ItemProfessionToken)itemStack.func_77973_b();
/* 1576 */       if (canConvertProfession(token.getProfessionType()) && (ModItems.isItemVillageBound(itemStack, getVillage()) || !ModItems.isItemVillageBound(itemStack)) && 
/* 1577 */         !this.field_70170_p.field_72995_K) {
/* 1578 */         itemStack.func_190918_g(1);
/* 1579 */         EntityVillagerTek villager = token.createVillager(this.field_70170_p, this);
/* 1580 */         if (villager != null) {
/* 1581 */           villager.func_70012_b(this.field_70165_t, this.field_70163_u, this.field_70161_v, this.field_70177_z, this.field_70125_A);
/* 1582 */           villager.func_180482_a(this.field_70170_p.func_175649_E(func_180425_c()), (IEntityLivingData)null);
/* 1583 */           villager.cloneFrom(this);
/*      */           
/* 1585 */           this.field_70170_p.func_72838_d((Entity)villager);
/*      */           
/* 1587 */           player.func_184185_a(SoundEvents.field_193784_dd, 1.0F, 1.0F);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1597 */           return true;
/*      */         } 
/*      */         
/* 1600 */         return false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1608 */     if (!this.field_70170_p.field_72995_K) {
/*      */       
/* 1610 */       player.openGui(TekVillager.instance, 0, this.field_70170_p, func_145782_y(), 0, 0);
/* 1611 */       func_70661_as().func_75499_g();
/*      */     } 
/*      */     
/* 1614 */     if (player.func_70093_af()) {
/* 1615 */       debugSpam();
/*      */     }
/*      */     
/* 1618 */     return true;
/*      */   }
/*      */   
/*      */   protected void debugSpam() {
/* 1622 */     debugOut("+ + + + + + + + + + + + + +");
/* 1623 */     debugOut("Debug for " + getDebugName());
/* 1624 */     getInventory().debugSpam();
/* 1625 */     for (EntityAITasks.EntityAITaskEntry task : this.field_70714_bg.field_75782_a) {
/* 1626 */       if (task.field_188524_c) {
/* 1627 */         debugOut("    Active Task: " + task.field_75733_a.getClass().getSimpleName());
/*      */       }
/*      */     } 
/* 1630 */     debugOut("Hunger: " + getHunger());
/* 1631 */     debugOut("Happy: " + getHappy());
/* 1632 */     debugOut("Health: " + func_110143_aJ());
/* 1633 */     debugOut("Intelligence: " + getIntelligence());
/*      */     
/* 1635 */     for (ProfessionType pt : ProfessionType.values()) {
/* 1636 */       if (getBaseSkill(pt) > 0) {
/* 1637 */         debugOut("     " + pt.name + ": " + getBaseSkill(pt));
/*      */       }
/*      */     } 
/* 1640 */     debugOut("^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^");
/*      */   }
/*      */   
/*      */   protected void registerAIFilter(String filterName, DataParameter<Boolean> param) {
/* 1644 */     if (this.aiFilters.put(filterName, param) != null) {
/* 1645 */       debugOut("ERROR: registerAIFilter( " + filterName + " ).  Double registration");
/*      */     }
/* 1647 */     this.field_70180_af.func_187214_a(param, Boolean.valueOf(true));
/*      */   }
/*      */   
/*      */   protected void removeAIFilter(String filterName) {
/* 1651 */     this.aiFilters.remove(filterName);
/*      */   }
/*      */   
/*      */   public List<String> getAIFilters() {
/* 1655 */     return new ArrayList<>(this.aiFilters.keySet());
/*      */   }
/*      */   
/*      */   public boolean isAIFilterEnabled(String filterName) {
/* 1659 */     DataParameter<Boolean> param = this.aiFilters.get(filterName);
/* 1660 */     if (param != null) {
/* 1661 */       boolean result = ((Boolean)this.field_70180_af.func_187225_a(param)).booleanValue();
/* 1662 */       return result;
/*      */     } 
/*      */     
/* 1665 */     debugOut("ERROR: (isAIFilterEnabled) AI Filter " + filterName + " does not exist!");
/* 1666 */     debugOut("ERROR: (isAIFilterEnabled) AI Filter " + filterName + " does not exist!");
/* 1667 */     debugOut("ERROR: (isAIFilterEnabled) AI Filter " + filterName + " does not exist!");
/* 1668 */     debugOut("ERROR: (isAIFilterEnabled) AI Filter " + filterName + " does not exist!");
/* 1669 */     debugOut("ERROR: (isAIFilterEnabled) AI Filter " + filterName + " does not exist!");
/* 1670 */     return true;
/*      */   }
/*      */   
/*      */   public void setAIFilter(String filterName, boolean enabled) {
/* 1674 */     DataParameter<Boolean> param = this.aiFilters.get(filterName);
/* 1675 */     if (param != null) {
/* 1676 */       debugOut("AI Filer " + filterName + " -> " + enabled);
/* 1677 */       this.field_70180_af.func_187227_b(param, Boolean.valueOf(enabled));
/*      */     } else {
/*      */       
/* 1680 */       debugOut("ERROR: (setAIFilter) AI Filter " + filterName + " does not exist!");
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean canConvertProfession(ProfessionType pt) {
/* 1685 */     return (pt != this.professionType && pt != ProfessionType.CAPTAIN);
/*      */   }
/*      */ 
/*      */   
/*      */   public void func_70604_c(@Nullable EntityLivingBase target) {
/* 1690 */     if (target instanceof EntityPlayer) {
/*      */       return;
/*      */     }
/* 1693 */     super.func_70604_c(target);
/*      */     
/* 1695 */     if (hasVillage() && target != null) {
/* 1696 */       getVillage().addOrRenewEnemy(target, 5);
/*      */       
/* 1698 */       if (func_70089_S()) {
/* 1699 */         this.field_70170_p.func_72960_a((Entity)this, (byte)14);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void func_184206_a(DataParameter<?> key) {
/* 1706 */     super.func_184206_a(key);
/*      */     
/* 1708 */     if (MOVEMENT_MODE.equals(key))
/*      */     {
/* 1710 */       if (isWalking()) {
/* 1711 */         startWalking();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void equipActionItem(ItemStack toolItem) {
/* 1717 */     this.field_70180_af.func_187227_b(ACTION_ITEM, toolItem.func_77946_l());
/*      */   }
/*      */   
/*      */   public ItemStack getActionItem() {
/* 1721 */     return (ItemStack)this.field_70180_af.func_187225_a(ACTION_ITEM);
/*      */   }
/*      */ 
/*      */   
/*      */   public void unequipActionItem() {
/* 1726 */     this.field_70180_af.func_187227_b(ACTION_ITEM, ItemStack.field_190927_a);
/*      */   }
/*      */   
/*      */   public void unequipActionItem(ItemStack actionItem) {
/* 1730 */     if (actionItem != null && actionItem.func_77973_b() == getActionItem().func_77973_b())
/* 1731 */       this.field_70180_af.func_187227_b(ACTION_ITEM, ItemStack.field_190927_a); 
/*      */   }
/*      */   
/*      */   public Predicate<Entity> isEnemy() {
/* 1735 */     return e -> (isHostile().test(e) || (e instanceof EntityLivingBase && EntityNecromancer.isMinion((EntityLivingBase)e)));
/*      */   }
/*      */   
/*      */   public Predicate<Entity> isHostile() {
/* 1739 */     return e -> ((e instanceof net.minecraft.entity.monster.EntityZombie && !(e instanceof net.minecraft.entity.monster.EntityPigZombie)) || e instanceof net.minecraft.entity.monster.EntityWitherSkeleton || e instanceof net.minecraft.entity.monster.EntityEvoker || e instanceof net.minecraft.entity.monster.EntityVex || e instanceof net.minecraft.entity.monster.EntityVindicator || e instanceof EntityNecromancer);
/*      */   }
/*      */   
/*      */   public boolean isFleeFrom(Entity e) {
/* 1743 */     return isHostile().test(e);
/*      */   }
/*      */   
/*      */   public void addRecentEat(Item item) {
/* 1747 */     this.recentEats.add(Integer.valueOf(Item.func_150891_b(item)));
/* 1748 */     while (this.recentEats.size() > 5) {
/* 1749 */       this.recentEats.remove();
/*      */     }
/*      */   }
/*      */   
/*      */   public int getRecentEatModifier(Item item) {
/* 1754 */     int itemId = Item.func_150891_b(item);
/* 1755 */     int eatCount = MathHelper.func_76125_a((int)this.recentEats.stream().filter(i -> (i.intValue() == itemId)).count(), 0, 5);
/* 1756 */     return recentEatPenalties[eatCount];
/*      */   }
/*      */   public static Function<ItemStack, Integer> foodBetterThan(EntityVillagerTek v, int foodValue) {
/* 1759 */     return p -> {
/*      */         int val = ((Integer)foodValue(v).apply(p)).intValue();
/*      */         return Integer.valueOf((val > foodValue) ? val : -1);
/*      */       };
/*      */   }
/*      */   
/*      */   public static Function<ItemStack, Integer> foodValue(EntityVillagerTek v) {
/* 1766 */     return p -> Integer.valueOf((int)((ModItems.isTaggedItem(p, ItemTagType.VILLAGER) ? 1.0F : 0.5F) * ((Integer)foodItemValue(v).apply(p.func_77973_b())).intValue()));
/*      */   }
/*      */   
/*      */   public static Function<Item, Integer> foodItemValue(EntityVillagerTek v) {
/* 1770 */     return i -> Integer.valueOf(EntityAIEatFood.getFoodScore(i, v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isVillageMember(Village v) {
/* 1788 */     return (getVillage() == v && getBedPos() != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isMale() {
/* 1796 */     return (func_110124_au().getLeastSignificantBits() % 2L == 0L);
/*      */   }
/*      */   
/*      */   public Predicate<ItemStack> isHarvestItem() {
/* 1800 */     return p -> false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void equipBestGear() {}
/*      */ 
/*      */   
/*      */   public void equipBestGear(EntityEquipmentSlot slot, Function<ItemStack, Integer> bestFunc) {
/* 1809 */     ItemStack bestItem = func_184582_a(slot);
/* 1810 */     int bestScore = ((Integer)bestFunc.apply(bestItem)).intValue();
/* 1811 */     int swapSlot = -1;
/*      */     
/* 1813 */     for (int i = 0; i < getInventory().func_70302_i_(); i++) {
/* 1814 */       ItemStack itemStack = getInventory().func_70301_a(i);
/* 1815 */       int thisScore = ((Integer)bestFunc.apply(itemStack)).intValue();
/* 1816 */       if (thisScore > bestScore) {
/* 1817 */         bestScore = thisScore;
/* 1818 */         bestItem = itemStack;
/* 1819 */         swapSlot = i;
/*      */       } 
/*      */     } 
/*      */     
/* 1823 */     if (swapSlot >= 0) {
/* 1824 */       ItemStack oldGear = func_184582_a(slot);
/* 1825 */       func_184201_a(slot, bestItem);
/* 1826 */       getInventory().func_70299_a(swapSlot, oldGear);
/* 1827 */       debugOut("Equipping new gear: " + bestItem + "   Removing old gear: " + oldGear);
/*      */     }
/* 1829 */     else if (bestScore == -1) {
/* 1830 */       ItemStack oldGear = func_184582_a(slot);
/* 1831 */       if (!oldGear.func_190926_b()) {
/* 1832 */         func_184201_a(slot, ItemStack.field_190927_a);
/* 1833 */         getInventory().func_174894_a(oldGear);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void cloneFrom(EntityVillagerTek source) {
/* 1840 */     func_96094_a(source.func_95999_t());
/*      */ 
/*      */ 
/*      */     
/* 1844 */     while (source.isMale() != isMale()) {
/* 1845 */       func_184221_a(UUID.randomUUID());
/*      */     }
/*      */     
/* 1848 */     setHappy(source.getHappy());
/* 1849 */     setIntelligence(source.getIntelligence());
/* 1850 */     setHunger(source.getHunger());
/*      */     
/* 1852 */     this.villagerInventory.mergeItems(source.villagerInventory);
/* 1853 */     this.bedPos = source.bedPos;
/* 1854 */     this.homeFrame = source.homeFrame;
/* 1855 */     this.daysAlive = source.daysAlive;
/* 1856 */     this.dayCheckTime = source.dayCheckTime;
/*      */ 
/*      */     
/* 1859 */     source.applySkillsTo(this);
/*      */     
/* 1861 */     getInventory().cloneFrom(source.getInventory());
/*      */ 
/*      */ 
/*      */     
/* 1865 */     source.func_70106_y();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void applySkillsTo(EntityVillagerTek target) {
/* 1870 */     for (ProfessionType pt : SKILLS.keySet()) {
/* 1871 */       int skill = getBaseSkill(pt);
/* 1872 */       if (skill > target.getBaseSkill(pt) && pt.canCopy) {
/* 1873 */         target.setSkill(pt, skill);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void func_70014_b(NBTTagCompound compound) {
/* 1880 */     super.func_70014_b(compound);
/*      */     
/* 1882 */     compound.func_74768_a("happy", getHappy());
/* 1883 */     compound.func_74768_a("hunger", getHunger());
/* 1884 */     compound.func_74768_a("intelligence", getIntelligence());
/* 1885 */     compound.func_74768_a("daysAlive", this.daysAlive);
/* 1886 */     compound.func_74768_a("dayCheckTime", this.dayCheckTime);
/*      */     
/* 1888 */     for (ProfessionType pt : SKILLS.keySet()) {
/* 1889 */       if (pt.canCopy) {
/* 1890 */         compound.func_74768_a(pt.name, getBaseSkill(pt));
/*      */       }
/*      */     } 
/* 1893 */     for (String filterName : this.aiFilters.keySet()) {
/* 1894 */       compound.func_74757_a("ai_" + filterName, isAIFilterEnabled(filterName));
/*      */     }
/*      */     
/* 1897 */     compound.func_74757_a("hasHome", (this.homeFrame != null));
/* 1898 */     if (this.homeFrame != null) {
/* 1899 */       writeBlockPosNBT(compound, "homeFrame", this.homeFrame);
/*      */     }
/* 1901 */     compound.func_74783_a("recentEats", this.recentEats.stream().mapToInt(i -> i.intValue()).toArray());
/* 1902 */     this.villagerInventory.writeNBT(compound);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void func_70037_a(NBTTagCompound compound) {
/* 1908 */     super.func_70037_a(compound);
/*      */     
/* 1910 */     setHappy(compound.func_74762_e("happy"));
/* 1911 */     setHunger(compound.func_74762_e("hunger"));
/* 1912 */     setIntelligence(compound.func_74762_e("intelligence"));
/* 1913 */     this.daysAlive = compound.func_74762_e("daysAlive");
/* 1914 */     this.dayCheckTime = compound.func_74762_e("dayCheckTime");
/*      */     
/* 1916 */     for (ProfessionType pt : SKILLS.keySet()) {
/* 1917 */       if (pt.canCopy) {
/* 1918 */         setSkill(pt, compound.func_74762_e(pt.name));
/*      */       }
/*      */     } 
/* 1921 */     for (String filterName : this.aiFilters.keySet()) {
/* 1922 */       String key = "ai_" + filterName;
/* 1923 */       if (compound.func_74764_b(key)) {
/* 1924 */         setAIFilter(filterName, compound.func_74767_n("ai_" + filterName)); continue;
/*      */       } 
/* 1926 */       setAIFilter(filterName, true);
/*      */     } 
/*      */     
/* 1929 */     boolean hasHome = compound.func_74767_n("hasHome");
/* 1930 */     if (hasHome) {
/* 1931 */       this.homeFrame = readBlockPosNBT(compound, "homeFrame");
/*      */     }
/* 1933 */     this.recentEats.clear();
/* 1934 */     int[] eats = compound.func_74759_k("recentEats");
/* 1935 */     Arrays.stream(eats).forEach(i -> this.recentEats.add(Integer.valueOf(i)));
/*      */     
/* 1937 */     func_189654_d(false);
/*      */     
/* 1939 */     this.villagerInventory.readNBT(compound);
/* 1940 */     getDesireSet().forceUpdate();
/*      */   }
/*      */ 
/*      */   
/*      */   protected BlockPos readBlockPosNBT(NBTTagCompound compound, String key) {
/* 1945 */     NBTTagList nbttaglist = compound.func_150295_c(key, 6);
/* 1946 */     return new BlockPos(nbttaglist.func_150309_d(0), nbttaglist.func_150309_d(1), nbttaglist.func_150309_d(2));
/*      */   }
/*      */   
/*      */   protected void writeBlockPosNBT(NBTTagCompound compound, String key, BlockPos val) {
/* 1950 */     compound.func_74782_a(key, (NBTBase)func_70087_a(new double[] { val.func_177958_n(), val.func_177956_o(), val.func_177952_p() }));
/*      */   }
/*      */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityVillagerTek.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */