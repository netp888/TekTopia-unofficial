/*     */ package net.tangotek.tektopia.entities;
/*     */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.Particle;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.EntityAIMoveTowardsRestriction;
/*     */ import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
/*     */ import net.minecraft.entity.ai.EntityAITasks;
/*     */ import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
/*     */ import net.minecraft.entity.monster.AbstractSkeleton;
/*     */ import net.minecraft.entity.monster.EntityHusk;
/*     */ import net.minecraft.entity.monster.EntityMob;
/*     */ import net.minecraft.entity.monster.EntityWitherSkeleton;
/*     */ import net.minecraft.entity.monster.EntityZombie;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.SoundCategory;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.tangotek.tektopia.ModSoundEvents;
/*     */ import net.tangotek.tektopia.caps.IVillageData;
/*     */ import net.tangotek.tektopia.client.ParticleDarkness;
/*     */ import net.tangotek.tektopia.client.ParticleSkull;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAIFollowLeader;
/*     */ import net.tangotek.tektopia.tickjob.TickJob;
/*     */ 
/*     */ public class EntityNecromancer extends EntityVillageNavigator implements IMob {
/*  45 */   protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityNecromancer.class);
/*  46 */   private static final DataParameter<Integer> SPELL_TARGET = EntityDataManager.func_187226_a(EntityNecromancer.class, DataSerializers.field_187192_b);
/*  47 */   private static final DataParameter<Integer> LEVEL = EntityDataManager.func_187226_a(EntityNecromancer.class, DataSerializers.field_187192_b);
/*  48 */   private static final DataParameter<List<Integer>> MINIONS = EntityDataManager.func_187226_a(EntityNecromancer.class, TekDataSerializers.INT_LIST);
/*     */   
/*     */   static {
/*  51 */     animHandler.addAnim("tektopia", "necro_walk", "necromancer", true);
/*  52 */     animHandler.addAnim("tektopia", "necro_idle", "necromancer", true);
/*  53 */     animHandler.addAnim("tektopia", "necro_summon", "necromancer", false);
/*  54 */     animHandler.addAnim("tektopia", "necro_siphon", "necromancer", false);
/*  55 */     animHandler.addAnim("tektopia", "necro_cast_forward", "necromancer", false);
/*     */   }
/*     */   
/*  58 */   private final int SKULL_COOLDOWN_NORMAL = 100;
/*  59 */   private final int SKULL_COOLDOWN_ATTACKED = 40;
/*     */ 
/*     */   
/*  62 */   private List<EntitySpiritSkull> skulls = new ArrayList<>();
/*  63 */   private int lastSkullGained = 0;
/*  64 */   private int skullCooldown = 100;
/*  65 */   private final int MAX_LEVEL = 5;
/*  66 */   private int maxSkulls = 1;
/*     */   private boolean isAngry = false;
/*     */   private BlockPos firstCheck;
/*     */   private boolean villagerDied = false;
/*     */   
/*     */   public EntityNecromancer(World worldIn) {
/*  72 */     super(worldIn, VillagerRole.ENEMY.value | VillagerRole.VISITOR.value);
/*  73 */     func_70105_a(0.6F, 1.95F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     func_70101_b(0.0F, 0.0F);
/*  80 */     if (this.field_70170_p.field_72995_K) {
/*  81 */       addAnimationTriggerRange("tektopia:necro_summon", 102, 108, () -> skullParticles((Entity)this, 4));
/*     */ 
/*     */       
/*  84 */       addAnimationTrigger("tektopia:necro_summon", 1, () -> skullParticles((Entity)this, 1));
/*     */ 
/*     */       
/*  87 */       addAnimationTrigger("tektopia:necro_summon", 20, () -> skullParticles((Entity)this, 1));
/*     */ 
/*     */       
/*  90 */       addAnimationTrigger("tektopia:necro_summon", 40, () -> skullParticles((Entity)this, 1));
/*     */ 
/*     */       
/*  93 */       addAnimationTrigger("tektopia:necro_summon", 60, () -> skullParticles((Entity)this, 1));
/*     */ 
/*     */       
/*  96 */       addAnimationTrigger("tektopia:necro_summon", 80, () -> skullParticles((Entity)this, 1));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLevel(int powerLevel) {
/* 104 */     int level = Math.max(1, Math.min(powerLevel, 5));
/* 105 */     this.field_70180_af.func_187227_b(LEVEL, Integer.valueOf(level));
/* 106 */     this.maxSkulls = level;
/*     */   }
/*     */   
/*     */   public int getLevel() {
/* 110 */     return ((Integer)this.field_70180_af.func_187225_a(LEVEL)).intValue();
/*     */   }
/*     */   
/*     */   protected void func_184651_r() {
/* 114 */     this.field_70714_bg.func_75776_a(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
/* 115 */     this.field_70714_bg.func_75776_a(9, (EntityAIBase)new EntityAISoulLink(this));
/* 116 */     this.field_70714_bg.func_75776_a(9, (EntityAIBase)new EntityAIDeathCloud(this));
/* 117 */     this.field_70714_bg.func_75776_a(9, (EntityAIBase)new EntityAISummonUndead(this, 1));
/* 118 */     this.field_70714_bg.func_75776_a(10, (EntityAIBase)new EntityAINecroMove(this));
/*     */ 
/*     */ 
/*     */     
/* 122 */     this.field_70715_bh.func_75776_a(2, (EntityAIBase)(new EntityAINearestAttackableTarget(this, EntityPlayer.class, true)).func_190882_b(300));
/* 123 */     this.field_70715_bh.func_75776_a(3, (EntityAIBase)(new EntityAINearestAttackableTarget(this, EntityVillagerTek.class, false)).func_190882_b(300));
/* 124 */     this.field_70715_bh.func_75776_a(5, (EntityAIBase)(new EntityAINearestAttackableTarget(this, EntityVillager.class, false)).func_190882_b(300));
/* 125 */     this.field_70715_bh.func_75776_a(5, (EntityAIBase)new EntityAINearestAttackableTarget(this, EntityIronGolem.class, false));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setupServerJobs() {
/* 130 */     super.setupServerJobs();
/*     */     
/* 132 */     addJob(new TickJob(40, 50, true, () -> convertNearbyZombies()));
/* 133 */     addJob(new TickJob(75, 50, true, () -> convertNearbySkeletons()));
/*     */ 
/*     */     
/* 136 */     addJob(new TickJob(3, 3, true, () -> decaySurroundings()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasVillagerDied() {
/* 141 */     return this.villagerDied;
/*     */   }
/*     */ 
/*     */   
/*     */   public void notifyVillagerDeath() {
/* 146 */     this.villagerDied = true;
/*     */   }
/*     */   
/*     */   private void prepStuck() {
/* 150 */     this.firstCheck = func_180425_c();
/*     */   }
/*     */   
/*     */   private void checkStuck() {
/* 154 */     if (hasVillage() && this.firstCheck.func_177951_i((Vec3i)func_180425_c()) < 2.0D) {
/* 155 */       IVillageData vd = this.village.getTownData();
/* 156 */       if (vd != null) {
/* 157 */         vd.setNomadsCheckedToday(true);
/* 158 */         vd.setMerchantCheckedToday(true);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldDecayBlock(BlockPos bp) {
/* 167 */     Block testBlock = this.field_70170_p.func_180495_p(bp).func_177230_c();
/* 168 */     if (testBlock instanceof net.minecraft.block.BlockBush) {
/* 169 */       return true;
/*     */     }
/* 171 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decaySurroundings() {
/* 176 */     for (int i = 0; i < 20; i++) {
/* 177 */       BlockPos testPos = new BlockPos(this.field_70165_t + func_70681_au().nextGaussian() * 8.0D, this.field_70163_u + func_70681_au().nextGaussian() * 0.6D, this.field_70161_v + func_70681_au().nextGaussian() * 8.0D);
/* 178 */       if (shouldDecayBlock(testPos)) {
/* 179 */         this.field_70170_p.func_175698_g(testPos);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_110147_ax() {
/* 201 */     super.func_110147_ax();
/* 202 */     func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(20.0D);
/* 203 */     func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(64.0D);
/*     */     
/* 205 */     this.field_70180_af.func_187227_b(MINIONS, new ArrayList());
/*     */   }
/*     */   
/*     */   protected void func_70088_a() {
/* 209 */     this.field_70180_af.func_187214_a(MINIONS, new ArrayList());
/* 210 */     this.field_70180_af.func_187214_a(SPELL_TARGET, Integer.valueOf(0));
/* 211 */     this.field_70180_af.func_187214_a(LEVEL, Integer.valueOf(1));
/* 212 */     super.func_70088_a();
/*     */   }
/*     */   
/*     */   public boolean isSpellcasting() {
/* 216 */     int entityId = ((Integer)this.field_70180_af.func_187225_a(SPELL_TARGET)).intValue();
/* 217 */     return (entityId > 0);
/*     */   }
/*     */   
/*     */   public Entity getSpellTargetEntity() {
/* 221 */     int entityId = ((Integer)this.field_70180_af.func_187225_a(SPELL_TARGET)).intValue();
/* 222 */     if (entityId > 0) {
/* 223 */       return this.field_70170_p.func_73045_a(entityId);
/*     */     }
/* 225 */     return null;
/*     */   }
/*     */   
/*     */   public void setSpellTarget(Entity entity) {
/* 229 */     if (entity == null) {
/* 230 */       this.field_70180_af.func_187227_b(SPELL_TARGET, Integer.valueOf(0));
/*     */     } else {
/* 232 */       this.field_70180_af.func_187227_b(SPELL_TARGET, Integer.valueOf(entity.func_145782_y()));
/*     */     } 
/*     */   }
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void skullParticles(Entity entity, int count) {
/* 237 */     for (int i = 0; i < count; i++) {
/* 238 */       Random rand = entity.field_70170_p.field_73012_v;
/* 239 */       double motionY = Math.random() * 0.03D + 0.01D;
/* 240 */       Vec3d pos = new Vec3d(entity.field_70165_t + rand.nextGaussian() * 0.5D, entity.field_70163_u + rand.nextFloat(), entity.field_70161_v + rand.nextGaussian() * 0.5D);
/* 241 */       ParticleSkull part = new ParticleSkull(entity.field_70170_p, Minecraft.func_71410_x().func_110434_K(), pos, motionY);
/* 242 */       part.radius = rand.nextGaussian() * 0.1D;
/* 243 */       part.radiusGrow = 0.005D;
/* 244 */       part.torque = Math.random() * 0.04D - 0.02D;
/* 245 */       part.lifeTime = rand.nextInt(15) + 10;
/* 246 */       part.func_189213_a();
/* 247 */       (Minecraft.func_71410_x()).field_71452_i.func_78873_a((Particle)part);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void minionsDefendMe(EntityLivingBase enemy) {
/* 252 */     List<EntityMob> minions = getMinions();
/* 253 */     for (EntityMob minion : minions) {
/* 254 */       minion.func_70624_b(enemy);
/*     */     }
/*     */   }
/*     */   
/*     */   private void cleanMinions() {
/* 259 */     if (!this.field_70170_p.field_72995_K) {
/* 260 */       List<Integer> idList = (List<Integer>)this.field_70180_af.func_187225_a(MINIONS);
/* 261 */       if (idList.removeIf(entityId -> !isValidMinion(this.field_70170_p.func_73045_a(entityId.intValue())))) {
/* 262 */         debugOut("Minion(s) removed. Now " + idList.size());
/* 263 */         this.field_70180_af.func_187227_b(MINIONS, idList);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addMinion(EntityMob mob) {
/* 269 */     List<Integer> idList = (List<Integer>)this.field_70180_af.func_187225_a(MINIONS);
/* 270 */     idList.add(Integer.valueOf(mob.func_145782_y()));
/* 271 */     this.field_70180_af.func_187227_b(MINIONS, idList);
/* 272 */     debugOut("Minion " + mob.func_145782_y() + " added to list. Now " + idList.size());
/*     */   }
/*     */   
/*     */   private boolean isValidMinion(Entity e) {
/* 276 */     return (e != null && e instanceof EntityMob && e.func_70089_S());
/*     */   }
/*     */   
/*     */   public List<EntityMob> getMinions() {
/* 280 */     List<Integer> idList = (List<Integer>)this.field_70180_af.func_187225_a(MINIONS);
/* 281 */     List<EntityMob> mobList = new ArrayList<>();
/* 282 */     idList.forEach(id -> {
/*     */           EntityMob mob = (EntityMob)this.field_70170_p.func_73045_a(id.intValue());
/*     */           if (isValidMinion((Entity)mob))
/*     */             mobList.add(mob); 
/*     */         });
/* 287 */     return mobList;
/*     */   }
/*     */   
/*     */   public void func_70071_h_() {
/* 291 */     super.func_70071_h_();
/*     */     
/* 293 */     if (!this.field_70170_p.field_72995_K && this.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL) {
/* 294 */       func_70106_y();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public float func_70689_ay() {
/* 300 */     return 0.22F;
/*     */   }
/*     */   
/*     */   protected SoundEvent func_184639_G() {
/* 304 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isAITick() {
/* 308 */     return (super.isAITick() || this.field_70737_aN > 0);
/*     */   }
/*     */   
/*     */   public int getMaxSummons() {
/* 312 */     if (this.villagerDied) {
/* 313 */       return 0;
/*     */     }
/* 315 */     return 4 + getLevel();
/*     */   }
/*     */   
/*     */   public boolean isReadyForSkull() {
/* 319 */     if (this.skulls.isEmpty()) {
/* 320 */       return true;
/*     */     }
/* 322 */     if (this.skulls.size() < this.maxSkulls && !this.villagerDied && func_70681_au().nextInt(2) == 0 && this.field_70173_aa - this.skullCooldown > this.lastSkullGained) {
/* 323 */       return true;
/*     */     }
/*     */     
/* 326 */     return false;
/*     */   }
/*     */   
/*     */   private void convertNearbyZombies() {
/* 330 */     if (!this.villagerDied) {
/* 331 */       List<EntityZombie> zombies = this.field_70170_p.func_72872_a(EntityZombie.class, func_174813_aQ().func_186662_g((15 + getLevel() * 4)));
/* 332 */       zombies.forEach(z -> convertZombie(z));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void convertNearbySkeletons() {
/* 337 */     if (!this.villagerDied) {
/* 338 */       List<AbstractSkeleton> skels = this.field_70170_p.func_72872_a(AbstractSkeleton.class, func_174813_aQ().func_186662_g((15 + getLevel() * 4)));
/* 339 */       skels.forEach(s -> convertSkeleton(s));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isMinion(EntityLivingBase mob) {
/* 344 */     return mob.getEntityData().func_186855_b("master");
/*     */   }
/*     */   
/*     */   public static void makeMinion(EntityLivingBase minion, EntityNecromancer necro) {
/* 348 */     minion.getEntityData().func_186854_a("master", necro.func_110124_au());
/*     */   }
/*     */   
/*     */   public void convertZombie(EntityZombie z) {
/* 352 */     if (!isMinion((EntityLivingBase)z)) {
/* 353 */       z.field_70714_bg.field_75782_a.removeIf(entry -> (entry.field_75733_a.getClass() == EntityAIWanderAvoidWater.class));
/* 354 */       z.field_70714_bg.field_75782_a.removeIf(entry -> (entry.field_75733_a.getClass() == EntityAIMoveTowardsRestriction.class));
/* 355 */       z.field_70714_bg.field_75782_a.removeIf(entry -> (entry.field_75733_a.getClass() == EntityAIFollowLeader.class));
/* 356 */       z.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIFollowLeader((EntityCreature)z, this, 8, 1.0D));
/* 357 */       z.func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(64.0D);
/* 358 */       makeMinion((EntityLivingBase)z, this);
/*     */       
/* 360 */       debugOut("Converted nearby zombie | " + z.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void convertSkeleton(AbstractSkeleton skel) {
/* 367 */     if (!isMinion((EntityLivingBase)skel)) {
/* 368 */       skel.field_70714_bg.field_75782_a.removeIf(entry -> (entry.field_75733_a.getClass() == EntityAIWanderAvoidWater.class));
/* 369 */       skel.field_70714_bg.field_75782_a.removeIf(entry -> (entry.field_75733_a.getClass() == EntityAIFollowLeader.class));
/* 370 */       skel.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIFollowLeader((EntityCreature)skel, this, 8, 1.0D));
/* 371 */       skel.func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(32.0D);
/* 372 */       makeMinion((EntityLivingBase)skel, this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityWitherSkeleton createWitherSkeleton(BlockPos summonPos) {
/* 380 */     EntityWitherSkeleton skel = new EntityWitherSkeleton(this.field_70170_p);
/*     */     
/* 382 */     convertSkeleton((AbstractSkeleton)skel);
/* 383 */     skel.func_70012_b(summonPos.func_177958_n() + 0.5D, summonPos.func_177956_o(), summonPos.func_177952_p() + 0.5D, this.field_70177_z, this.field_70125_A);
/* 384 */     skel.func_180482_a(this.field_70170_p.func_175649_E(summonPos), null);
/* 385 */     skel.func_70690_d(new PotionEffect(MobEffects.field_76441_p, 15));
/*     */     
/* 387 */     return skel;
/*     */   }
/*     */   
/*     */   public EntityZombie createZombie(BlockPos summonPos) {
/*     */     EntityHusk entityHusk;
/* 392 */     getVillage(); if (Village.isTimeOfDay(this.field_70170_p, 13000L, 17000L)) {
/* 393 */       EntityZombie zombie = new EntityZombie(this.field_70170_p);
/*     */     } else {
/* 395 */       entityHusk = new EntityHusk(this.field_70170_p);
/*     */     } 
/* 397 */     convertZombie((EntityZombie)entityHusk);
/* 398 */     entityHusk.func_70012_b(summonPos.func_177958_n() + 0.5D, summonPos.func_177956_o(), summonPos.func_177952_p() + 0.5D, this.field_70177_z, this.field_70125_A);
/* 399 */     entityHusk.func_180482_a(this.field_70170_p.func_175649_E(summonPos), null);
/* 400 */     entityHusk.func_70690_d(new PotionEffect(MobEffects.field_76441_p, 15));
/*     */     
/* 402 */     return (EntityZombie)entityHusk;
/*     */   }
/*     */   
/*     */   public boolean isCreatureSkulled(EntityCreature creature) {
/* 406 */     this.skulls.removeIf(s -> (!s.func_70089_S() || s.func_70068_e((Entity)this) > 625.0D));
/* 407 */     return this.skulls.stream().anyMatch(s -> {
/*     */           EntityCreature c = s.getSkullCreature();
/* 409 */           return (c != null && c.equals(creature));
/*     */         });
/*     */   }
/*     */   
/*     */   public void addSkull(EntitySpiritSkull skull) {
/* 414 */     this.skulls.add(skull);
/* 415 */     this.lastSkullGained = this.field_70173_aa;
/* 416 */     this.skullCooldown = getLevelCooldown(100);
/* 417 */     skull.setNecro(this);
/*     */     
/* 419 */     func_184185_a(ModSoundEvents.deathFullSkulls, 1.3F, func_70681_au().nextFloat() * 0.4F + 0.8F);
/*     */   }
/*     */   
/*     */   public void releaseSkull(EntitySpiritSkull skull) {
/* 423 */     this.skulls.remove(skull);
/* 424 */     skull.func_70106_y();
/* 425 */     skull.setNecro((EntityNecromancer)null);
/* 426 */     playSound(ModSoundEvents.deathSkullLeave);
/* 427 */     this.isAngry = true;
/*     */   }
/*     */   
/*     */   public boolean isAngry() {
/* 431 */     return this.isAngry;
/*     */   }
/*     */   
/*     */   public void func_70636_d() {
/* 435 */     super.func_70636_d();
/*     */     
/* 437 */     if (isWorldRemote()) {
/* 438 */       updateIdle(isWalking());
/*     */       
/* 440 */       spawnCloud((Entity)this, isWalking() ? 30 : 20);
/*     */       
/* 442 */       if (isSpellcasting()) {
/* 443 */         skullParticles((Entity)this, getLevel() * 2);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 457 */       cleanMinions();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void spawnSmoke(Entity entity, float spread, int count) {
/* 469 */     for (int i = 0; i < count; i++) {
/* 470 */       double xOffset = entity.field_70170_p.field_73012_v.nextGaussian() * spread;
/* 471 */       double zOffset = entity.field_70170_p.field_73012_v.nextGaussian() * spread;
/*     */       
/* 473 */       Vec3d pos = new Vec3d(entity.field_70165_t + xOffset, entity.field_70163_u + Math.min(entity.field_70170_p.field_73012_v.nextFloat(), entity.field_70170_p.field_73012_v.nextFloat()) * 0.5D * entity.field_70131_O, entity.field_70161_v + zOffset);
/* 474 */       entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, pos.field_72450_a, pos.field_72448_b, pos.field_72449_c, 0.0D, 0.08D, 0.0D, new int[0]);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void spawnCloud(Vec3d pos, int count) {
/* 480 */     for (int i = 0; i < count; i++) {
/* 481 */       double motionY = Math.random() * 0.03D + 0.01D;
/* 482 */       Vec3d newPos = new Vec3d(pos.field_72450_a + this.field_70170_p.field_73012_v.nextGaussian() * 0.5D, pos.field_72448_b, pos.field_72449_c + this.field_70170_p.field_73012_v.nextGaussian() * 0.5D);
/* 483 */       ParticleDarkness part = new ParticleDarkness(this.field_70170_p, Minecraft.func_71410_x().func_110434_K(), newPos, motionY);
/* 484 */       part.radius = this.field_70170_p.field_73012_v.nextGaussian() * 0.3D;
/* 485 */       part.radiusGrow = 0.015D;
/* 486 */       part.torque = Math.random() * 0.04D - 0.02D;
/* 487 */       part.lifeTime = this.field_70170_p.field_73012_v.nextInt(15) + 10;
/* 488 */       part.func_189213_a();
/* 489 */       (Minecraft.func_71410_x()).field_71452_i.func_78873_a((Particle)part);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void spawnCloud(Entity entity, int count) {
/* 496 */     for (int i = 0; i < count; i++) {
/* 497 */       double motionY = Math.random() * 0.03D + 0.01D;
/* 498 */       Vec3d pos = new Vec3d(entity.field_70165_t, entity.field_70163_u + Math.min(this.field_70170_p.field_73012_v.nextFloat(), this.field_70170_p.field_73012_v.nextFloat()) * 0.5D * entity.field_70131_O, entity.field_70161_v);
/* 499 */       ParticleDarkness part = new ParticleDarkness(this.field_70170_p, Minecraft.func_71410_x().func_110434_K(), pos, motionY);
/* 500 */       part.radius = this.field_70170_p.field_73012_v.nextGaussian() * 0.3D;
/*     */       
/* 502 */       part.radiusGrow = 0.015D;
/* 503 */       part.torque = Math.random() * 0.04D - 0.02D;
/* 504 */       part.lifeTime = this.field_70170_p.field_73012_v.nextInt(15) + 15;
/*     */       
/* 506 */       part.func_189213_a();
/* 507 */       (Minecraft.func_71410_x()).field_71452_i.func_78873_a((Particle)part);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   protected void startWalking() {
/* 514 */     playClientAnimation("necro_walk");
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   protected void stopWalking() {
/* 520 */     stopClientAnimation("necro_walk");
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   protected void updateIdle(boolean isWalking) {
/* 525 */     if (!isCasting() && !isWalking) {
/* 526 */       if (!getAnimationHandler().isAnimationActive("tektopia", "necro_idle", this)) {
/* 527 */         getAnimationHandler().startAnimation("tektopia", "necro_idle", this);
/*     */       }
/*     */     }
/* 530 */     else if (getAnimationHandler().isAnimationActive("tektopia", "necro_idle", this)) {
/* 531 */       getAnimationHandler().stopAnimation("tektopia", "necro_idle", this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isCasting() {
/* 536 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean func_70692_ba() {
/* 541 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_70097_a(DamageSource source, float amount) {
/* 546 */     boolean livingAttack = source.func_76346_g() instanceof EntityLivingBase;
/* 547 */     if (livingAttack) {
/* 548 */       minionsDefendMe((EntityLivingBase)source.func_76346_g());
/*     */     }
/*     */ 
/*     */     
/* 552 */     List<EntitySpiritSkull> nearbySkullls = this.field_70170_p.func_72872_a(EntitySpiritSkull.class, func_174813_aQ().func_186662_g(5.0D));
/* 553 */     if (nearbySkullls.isEmpty() || source == DamageSource.field_76380_i) {
/* 554 */       this.skullCooldown -= 20;
/* 555 */       return super.func_70097_a(source, amount);
/*     */     } 
/*     */     
/* 558 */     func_184185_a(ModSoundEvents.deathShield, 1.2F + func_70681_au().nextFloat() * 0.4F, func_70681_au().nextFloat() * 0.2F + 0.9F);
/* 559 */     func_70690_d(new PotionEffect(MobEffects.field_188423_x, 20));
/* 560 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLevelCooldown(int baseValue) {
/* 585 */     return baseValue - (int)(baseValue * MathHelper.func_151238_b(0.0D, 0.6D, getLevel() / 5.0D));
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70645_a(DamageSource cause) {
/* 590 */     getMinions().stream().forEach(m -> m.func_70606_j(0.0F));
/* 591 */     playSound(ModSoundEvents.necroDead);
/* 592 */     super.func_70645_a(cause);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_70628_a(boolean wasRecentlyHit, int lootingModifier) {
/* 597 */     func_145779_a(Items.field_151166_bC, getLevel() * 4);
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_70103_a(byte id) {
/* 603 */     super.func_70103_a(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70604_c(@Nullable EntityLivingBase target) {
/* 612 */     super.func_70604_c(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_184645_a(EntityPlayer player, EnumHand hand) {
/* 624 */     ItemStack itemStack = player.func_184586_b(hand);
/*     */ 
/*     */     
/* 627 */     if (itemStack.func_77973_b() == ModItems.beer && 
/* 628 */       getLevel() < 5) {
/* 629 */       setLevel(getLevel() + 1);
/* 630 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 634 */     return super.func_184645_a(player, hand);
/*     */   }
/*     */ 
/*     */   
/*     */   public SoundCategory func_184176_by() {
/* 639 */     return SoundCategory.HOSTILE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound compound) {
/* 645 */     super.func_70014_b(compound);
/* 646 */     compound.func_74768_a("level", getLevel());
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound compound) {
/* 651 */     super.func_70037_a(compound);
/* 652 */     setLevel(compound.func_74762_e("level"));
/*     */   }
/*     */   
/*     */   public AnimationHandler getAnimationHandler() {
/* 656 */     return animHandler;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityNecromancer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */