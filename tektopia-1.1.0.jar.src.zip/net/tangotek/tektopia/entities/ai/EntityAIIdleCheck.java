/*    */ package net.tangotek.tektopia.entities.ai;
/*    */ 
/*    */ import net.minecraft.entity.ai.EntityAIBase;
/*    */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityAIIdleCheck
/*    */   extends EntityAIBase
/*    */ {
/*    */   protected final EntityVillagerTek villager;
/* 14 */   private int idleTicks = 0;
/*    */ 
/*    */   
/*    */   public EntityAIIdleCheck(EntityVillagerTek v) {
/* 18 */     this.villager = v;
/* 19 */     func_75248_a(7);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean func_75250_a() {
/* 24 */     if (this.villager.isAITick() && this.villager.hasVillage()) {
/* 25 */       return true;
/*    */     }
/*    */     
/* 28 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_75249_e() {
/* 33 */     this.idleTicks = 0;
/*    */   }
/*    */   
/*    */   public boolean func_75253_b() {
/* 37 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_75246_d() {
/* 42 */     this.idleTicks++;
/* 43 */     if (this.idleTicks % 80 == 0) {
/* 44 */       this.villager.setStoragePriority();
/*    */     }
/* 46 */     this.villager.setIdle(this.idleTicks);
/*    */     
/* 48 */     if (this.idleTicks % 1200 == 0) {
/* 49 */       this.villager.debugOut("Idle for " + (this.idleTicks / 20) + " seconds");
/*    */     }
/*    */   }
/*    */   
/*    */   public void func_75251_c() {
/* 54 */     this.villager.setIdle(0);
/* 55 */     if (this.idleTicks >= 1200)
/* 56 */       this.villager.debugOut(" was idle for " + (this.idleTicks / 20) + " seconds."); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAIIdleCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */