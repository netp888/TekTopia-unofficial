/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.passive.EntityAnimal;
/*     */ import net.minecraft.entity.passive.EntitySheep;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.tangotek.tektopia.EntityTagType;
/*     */ import net.tangotek.tektopia.ItemTagType;
/*     */ import net.tangotek.tektopia.ModEntities;
/*     */ import net.tangotek.tektopia.ModItems;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.entities.EntityVillageNavigator;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ import net.tangotek.tektopia.structures.VillageStructure;
/*     */ import net.tangotek.tektopia.structures.VillageStructureRancherPen;
/*     */ import net.tangotek.tektopia.structures.VillageStructureType;
/*     */ 
/*     */ public class EntityAIHarvestAnimal extends EntityAIFollow {
/*  28 */   private VillageStructureRancherPen rancherPen = null; private VillageStructureType penType;
/*     */   private ItemStack toolRequired;
/*     */   private ItemStack toolUsed;
/*  31 */   private EntityAnimal targetAnimal = null;
/*     */   private boolean active = false;
/*  33 */   private int harvestTime = 0;
/*     */   protected final EntityVillagerTek villager;
/*  35 */   public static long COW_MILK_TIME = 6000L;
/*     */   protected final Predicate<EntityVillagerTek> shouldPred;
/*     */   
/*     */   public EntityAIHarvestAnimal(EntityVillagerTek v, VillageStructureType penType, ItemStack toolRequired, Predicate<EntityVillagerTek> shouldPred) {
/*  39 */     super((EntityVillageNavigator)v);
/*  40 */     this.villager = v;
/*  41 */     this.penType = penType;
/*  42 */     this.toolRequired = toolRequired;
/*  43 */     this.toolUsed = null;
/*  44 */     this.shouldPred = shouldPred;
/*     */   }
/*     */ 
/*     */   
/*     */   protected EntityLivingBase getFollowTarget() {
/*  49 */     return (EntityLivingBase)this.targetAnimal;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  55 */     if (this.villager.isAITick() && this.villager.getVillage() != null && this.villager.isWorkTime() && this.shouldPred.test(this.villager)) {
/*  56 */       List<VillageStructure> structures = this.villager.getVillage().getStructures(this.penType);
/*  57 */       Collections.shuffle(structures);
/*  58 */       for (VillageStructure struct : structures) {
/*  59 */         this.rancherPen = (VillageStructureRancherPen)struct;
/*  60 */         List<EntityAnimal> animalList = this.rancherPen.getEntitiesInside(this.rancherPen.getAnimalClass());
/*  61 */         this.toolUsed = null;
/*     */ 
/*     */         
/*  64 */         if (!animalList.isEmpty()) {
/*  65 */           List<ItemStack> tools = this.villager.getInventory().getItems(p -> (p.func_77973_b() == this.toolRequired.func_77973_b()), 1);
/*  66 */           if (!tools.isEmpty()) {
/*  67 */             this.toolUsed = tools.get(0);
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/*  72 */         this.targetAnimal = null;
/*  73 */         double minDistance = Double.MAX_VALUE;
/*  74 */         for (EntityAnimal animal : animalList) {
/*  75 */           if (isAnimalHarvestable(animal) && !this.rancherPen.isAnimalScheduled(animal, VillageStructureRancherPen.AnimalScheduleType.HARVEST)) {
/*  76 */             double curDist = animal.func_70068_e((Entity)this.villager);
/*  77 */             if (curDist < minDistance) {
/*  78 */               this.targetAnimal = animal;
/*  79 */               minDistance = curDist;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/*  84 */         if (this.targetAnimal != null) {
/*  85 */           if (this.toolUsed != null) {
/*  86 */             return super.func_75250_a();
/*     */           }
/*     */           
/*  89 */           this.villager.setThought(this.rancherPen.getNoHarvestThought());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  96 */     return false;
/*     */   }
/*     */   
/*     */   public void func_75249_e() {
/* 100 */     this.active = true;
/* 101 */     this.villager.equipActionItem(this.toolUsed);
/* 102 */     this.rancherPen.scheduleAnimal(this.targetAnimal, VillageStructureRancherPen.AnimalScheduleType.HARVEST);
/* 103 */     super.func_75249_e();
/*     */   }
/*     */   
/*     */   public boolean func_75253_b() {
/* 107 */     return this.active;
/*     */   }
/*     */ 
/*     */   
/*     */   void updateMovementMode() {
/* 112 */     this.villager.setMovementMode(this.villager.getDefaultMovement());
/*     */   }
/*     */   
/*     */   public void func_75246_d() {
/* 116 */     if (this.harvestTime > 0) {
/* 117 */       this.villager.func_70671_ap().func_75650_a(this.destinationPos.func_177958_n(), this.destinationPos.func_177956_o(), this.destinationPos.func_177952_p(), 30.0F, 30.0F);
/* 118 */       this.harvestTime--;
/*     */       
/* 120 */       if (this.harvestTime == 17) {
/* 121 */         this.villager.unequipActionItem(this.toolUsed);
/*     */       }
/* 123 */       if (this.harvestTime == 10) {
/* 124 */         harvestAnimal();
/*     */       }
/* 126 */       else if (this.harvestTime == 0) {
/* 127 */         this.active = false;
/*     */       } 
/*     */     } else {
/*     */       
/* 131 */       super.func_75246_d();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75252_g() {
/* 137 */     return (this.harvestTime <= 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onArrival() {
/* 142 */     startHarvesting();
/* 143 */     super.onArrival();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onStuck() {
/* 148 */     this.active = false;
/* 149 */     super.onStuck();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onPathFailed(BlockPos pos) {
/* 154 */     this.active = false;
/* 155 */     super.onPathFailed(pos);
/*     */   }
/*     */ 
/*     */   
/*     */   private void startHarvesting() {
/* 160 */     int skillFactor = Math.max(this.villager.getSkillLerp(ProfessionType.RANCHER, 6, 1) - 1, 1);
/* 161 */     this.harvestTime = 34 * skillFactor;
/* 162 */     this.villager.func_70661_as().func_75499_g();
/* 163 */     this.villager.playServerAnimation("villager_take");
/*     */   }
/*     */   
/*     */   private void stopHarvesting() {
/* 167 */     this.villager.stopServerAnimation("villager_take");
/*     */   }
/*     */   
/*     */   private boolean isAnimalHarvestable(EntityAnimal animal) {
/* 171 */     if (animal.func_70089_S() && !animal.func_70631_g_()) {
/* 172 */       if (animal instanceof net.minecraft.entity.passive.EntityCow) {
/* 173 */         return ModEntities.isEntityUsable((Entity)animal, COW_MILK_TIME, this.villager.field_70170_p.func_82737_E());
/*     */       }
/* 175 */       if (animal instanceof EntitySheep) {
/* 176 */         EntitySheep sheep = (EntitySheep)animal;
/* 177 */         return !sheep.func_70892_o();
/*     */       } 
/*     */     } 
/*     */     
/* 181 */     return false;
/*     */   }
/*     */   
/*     */   private void harvestAnimal() {
/* 185 */     if (isAnimalHarvestable(this.targetAnimal)) {
/*     */       
/* 187 */       if (this.targetAnimal instanceof EntitySheep) {
/* 188 */         EntitySheep sheep = (EntitySheep)this.targetAnimal;
/* 189 */         sheep.func_70893_e(true);
/* 190 */         Random rng = this.villager.func_70681_au();
/*     */         
/* 192 */         this.villager.damageItem(this.toolUsed, 1);
/* 193 */         this.villager.tryAddSkill(ProfessionType.RANCHER, 5);
/*     */         
/* 195 */         int i = 1;
/* 196 */         if (rng.nextInt(100) < this.villager.getSkill(ProfessionType.RANCHER) && rng.nextInt(100) < this.villager.getSkill(ProfessionType.RANCHER)) {
/* 197 */           i++;
/*     */         }
/*     */         
/* 200 */         for (int j = 0; j < i; j++) {
/*     */           
/* 202 */           EntityItem entityitem = sheep.func_70099_a(ModItems.makeTaggedItem(new ItemStack(Item.func_150898_a(Blocks.field_150325_L), 1, sheep.func_175509_cj().func_176765_a()), ItemTagType.VILLAGER), 1.0F);
/* 203 */           entityitem.field_70181_x += (rng.nextFloat() * 0.05F);
/* 204 */           entityitem.field_70159_w += ((rng.nextFloat() - rng.nextFloat()) * 0.1F);
/* 205 */           entityitem.field_70179_y += ((rng.nextFloat() - rng.nextFloat()) * 0.1F);
/*     */         } 
/*     */         
/* 208 */         this.villager.func_184185_a(SoundEvents.field_187763_eJ, 1.0F, 1.0F);
/*     */       }
/* 210 */       else if (this.targetAnimal instanceof net.minecraft.entity.passive.EntityCow && 
/* 211 */         ModEntities.isEntityUsable((Entity)this.targetAnimal, COW_MILK_TIME, this.villager.field_70170_p.func_82737_E())) {
/*     */         
/* 213 */         ModEntities.useEntity((Entity)this.targetAnimal, this.villager.field_70170_p.func_82737_E());
/*     */         
/* 215 */         this.villager.tryAddSkill(ProfessionType.RANCHER, 5);
/* 216 */         this.villager.func_184185_a(SoundEvents.field_187564_an, 1.0F, 1.0F);
/*     */         
/* 218 */         ItemStack milkItem = new ItemStack(Items.field_151117_aB);
/* 219 */         if (ModEntities.isTaggedEntity((Entity)this.targetAnimal, EntityTagType.VILLAGER) && ModItems.isTaggedItem(this.toolUsed, ItemTagType.VILLAGER)) {
/* 220 */           ModItems.makeTaggedItem(milkItem, ItemTagType.VILLAGER);
/*     */         }
/* 222 */         ItemStack addedItem = this.villager.getInventory().func_174894_a(milkItem);
/* 223 */         if (addedItem == ItemStack.field_190927_a) {
/* 224 */           this.villager.getInventory().removeItems(p -> ItemStack.func_77989_b(this.toolUsed, p), 1);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 229 */       this.villager.throttledSadness(-3);
/*     */ 
/*     */       
/* 232 */       this.villager.modifyHunger(-3);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 239 */     this.villager.pickupItems(5);
/*     */     
/* 241 */     this.rancherPen.clearAnimalSchedule(this.targetAnimal, VillageStructureRancherPen.AnimalScheduleType.HARVEST);
/* 242 */     this.rancherPen = null;
/*     */     
/* 244 */     this.harvestTime = 0;
/* 245 */     this.active = false;
/* 246 */     this.villager.unequipActionItem(this.toolUsed);
/* 247 */     this.toolUsed = null;
/* 248 */     stopHarvesting();
/* 249 */     super.func_75251_c();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAIHarvestAnimal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */