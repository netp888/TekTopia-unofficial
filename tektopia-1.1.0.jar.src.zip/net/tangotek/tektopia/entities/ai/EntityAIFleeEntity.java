/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import com.google.common.base.Predicate;
/*     */ import com.google.common.base.Predicates;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.EntitySelectors;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.tangotek.tektopia.ModSoundEvents;
/*     */ import net.tangotek.tektopia.VillagerRole;
/*     */ import net.tangotek.tektopia.entities.EntityVillageNavigator;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ import net.tangotek.tektopia.pathing.BasePathingNode;
/*     */ import net.tangotek.tektopia.structures.VillageStructure;
/*     */ import net.tangotek.tektopia.structures.VillageStructureHome;
/*     */ 
/*     */ public class EntityAIFleeEntity
/*     */   extends EntityAIMoveToBlock
/*     */ {
/*     */   private final Predicate<Entity> entityPredicate;
/*     */   private final EntityVillagerTek villager;
/*     */   private final float avoidDistance;
/*     */   private Entity fleeEntity;
/*     */   private BlockPos destPos;
/*     */   
/*     */   public EntityAIFleeEntity(EntityVillagerTek v, Predicate<Entity> inPred, float avoidDistanceIn) {
/*  29 */     super((EntityVillageNavigator)v);
/*  30 */     this.villager = v;
/*  31 */     this.avoidDistance = avoidDistanceIn;
/*  32 */     func_75248_a(1);
/*     */     
/*  34 */     this.entityPredicate = Predicates.and(new Predicate[] { EntitySelectors.field_188444_d, e -> (e.func_70089_S() && this.villager.func_70635_at().func_75522_a(e)), inPred });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  41 */     if (this.villager.isAITick() && this.villager.hasVillage()) {
/*  42 */       List<Entity> fleeEnts = this.villager.field_70170_p.func_175674_a((Entity)this.villager, this.villager.func_174813_aQ().func_72314_b(this.avoidDistance, 8.0D, this.avoidDistance), this.entityPredicate);
/*  43 */       if (!fleeEnts.isEmpty()) {
/*  44 */         this.fleeEntity = fleeEnts.get(0);
/*     */ 
/*     */         
/*  47 */         VillageStructureHome home = this.villager.getHome();
/*  48 */         if (home != null && home.isBlockInside(this.villager.func_180425_c()) && VillageStructure.isWoodDoor(this.villager.field_70170_p, home.getDoor()) && 
/*  49 */           !home.isBlockInside(this.fleeEntity.func_180425_c())) {
/*  50 */           return false;
/*     */         }
/*     */         
/*  53 */         BlockPos fleeBlock = findRandomTargetAwayFrom(this.fleeEntity);
/*  54 */         if (fleeBlock != null) {
/*  55 */           this.destPos = fleeBlock;
/*  56 */           return super.func_75250_a();
/*     */         } 
/*     */       } 
/*     */     } 
/*  60 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockPos findRandomTargetAwayFrom(Entity fleeEntity) {
/*  65 */     Vec3d fleeDelta, villagerPos = this.villager.func_174791_d();
/*  66 */     Vec3d enemyPos = this.fleeEntity.func_174791_d();
/*     */ 
/*     */     
/*  69 */     if (this.villager.getBedPos() != null) {
/*     */       
/*  71 */       if (this.villager.func_174818_b(this.villager.getBedPos()) < 256.0D) {
/*  72 */         return this.villager.getBedPos();
/*     */       }
/*     */       
/*  75 */       fleeDelta = (new Vec3d((Vec3i)this.villager.getBedPos())).func_178788_d(villagerPos);
/*     */     
/*     */     }
/*  78 */     else if (this.villager.hasVillage()) {
/*  79 */       if (this.villager.func_180425_c().func_177951_i((Vec3i)this.villager.getVillage().getOrigin()) < 1600.0D) {
/*  80 */         fleeDelta = villagerPos.func_178788_d(enemyPos);
/*     */       }
/*     */       else {
/*     */         
/*  84 */         fleeDelta = this.villager.func_174791_d().func_178788_d(new Vec3d((Vec3i)this.villager.getVillage().getOrigin()));
/*     */       } 
/*     */     } else {
/*     */       
/*  88 */       fleeDelta = villagerPos.func_178788_d(enemyPos);
/*     */     } 
/*     */ 
/*     */     
/*  92 */     Vec3d fleeDeltaNorm = fleeDelta.func_72432_b();
/*  93 */     Vec3d fleeDir = new Vec3d(fleeDeltaNorm.field_72450_a, 0.0D, fleeDeltaNorm.field_72448_b);
/*     */ 
/*     */     
/*  96 */     if (this.villager.hasVillage() && this.villager.getVillage().getAABB().func_72318_a(villagerPos))
/*     */     {
/*  98 */       if (villagerPos.func_178787_e(fleeDir).func_72436_e(enemyPos) < villagerPos.func_72436_e(enemyPos)) {
/*  99 */         fleeDir = fleeDir.func_178785_b(60.0F);
/* 100 */         if (villagerPos.func_178787_e(fleeDir).func_72436_e(enemyPos) < villagerPos.func_72436_e(enemyPos)) {
/* 101 */           fleeDir = fleeDir.func_178785_b(-120.0F);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 106 */     Vec3d fleePos = this.villager.func_174791_d().func_178787_e(fleeDir.func_186678_a(16.0D));
/* 107 */     BlockPos fleeBlock = new BlockPos(fleePos.field_72450_a, fleePos.field_72448_b, fleePos.field_72449_c);
/*     */     
/* 109 */     for (int i = 0; i < 20; i++) {
/* 110 */       BlockPos testBlock = randomNearbyBlock(fleeBlock, i + 3);
/* 111 */       BasePathingNode baseNode = this.villager.getVillage().getPathingGraph().getNodeYRange(testBlock.func_177958_n(), testBlock.func_177956_o() - 5, testBlock.func_177956_o() + 5, testBlock.func_177952_p());
/* 112 */       if (baseNode != null) {
/* 113 */         return baseNode.getBlockPos();
/*     */       }
/*     */     } 
/*     */     
/* 117 */     return null;
/*     */   }
/*     */   
/*     */   private BlockPos randomNearbyBlock(BlockPos pos, int xz) {
/* 121 */     return pos.func_177982_a(this.villager.func_70681_au().nextInt(xz * 2) - xz, 0, this.villager.func_70681_au().nextInt(xz * 2) - xz);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/* 127 */     if (!(this.fleeEntity instanceof EntityVillagerTek)) {
/*     */       
/* 129 */       if (!this.villager.isRole(VillagerRole.DEFENDER)) {
/* 130 */         this.villager.modifyHappy(-2);
/*     */       }
/* 132 */       if (this.villager.func_70681_au().nextInt(2) == 0) {
/* 133 */         this.villager.playSound(ModSoundEvents.villagerAfraid);
/*     */       }
/*     */     } 
/* 136 */     super.func_75249_e();
/*     */   }
/*     */ 
/*     */   
/*     */   void updateMovementMode() {
/* 141 */     this.villager.setMovementMode(EntityVillagerTek.MovementMode.RUN);
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockPos getDestinationBlock() {
/* 146 */     return this.destPos;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 152 */     this.fleeEntity = null;
/* 153 */     super.func_75251_c();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAIFleeEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */