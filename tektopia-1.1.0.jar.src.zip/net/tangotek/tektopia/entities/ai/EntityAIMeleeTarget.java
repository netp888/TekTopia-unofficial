/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.tangotek.tektopia.ModSoundEvents;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.entities.EntityVillageNavigator;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ import net.tangotek.tektopia.tickjob.TickJob;
/*     */ 
/*     */ 
/*     */ public class EntityAIMeleeTarget
/*     */   extends EntityAIFollow
/*     */ {
/*  18 */   private int attackTick = 0;
/*  19 */   private final int ATTACK_TICK_TIME = 24;
/*  20 */   private int attackTime = 24;
/*     */   
/*     */   private boolean arrived = false;
/*     */   private final double attackRange;
/*     */   private final Function<EntityVillagerTek, ItemStack> weaponFunc;
/*     */   private ItemStack weapon;
/*     */   private Runnable onHit;
/*     */   private final ProfessionType professionType;
/*     */   protected final EntityVillagerTek villager;
/*     */   private final Predicate<EntityVillagerTek> shouldPred;
/*     */   private final EntityVillagerTek.VillagerThought missingThought;
/*     */   
/*     */   public EntityAIMeleeTarget(EntityVillagerTek entityIn, Function<EntityVillagerTek, ItemStack> func, EntityVillagerTek.VillagerThought missingThought, Predicate<EntityVillagerTek> shouldPred, Runnable onHit, ProfessionType pt) {
/*  33 */     super((EntityVillageNavigator)entityIn);
/*  34 */     this.shouldPred = shouldPred;
/*  35 */     this.villager = entityIn;
/*  36 */     this.attackRange = 3.5D;
/*  37 */     this.weaponFunc = func;
/*  38 */     this.onHit = onHit;
/*  39 */     this.professionType = pt;
/*  40 */     this.missingThought = missingThought;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  46 */     if (this.villager.getHunger() < 10) {
/*  47 */       return false;
/*     */     }
/*  49 */     if (!this.shouldPred.test(this.villager)) {
/*  50 */       return false;
/*     */     }
/*  52 */     if (super.func_75250_a()) {
/*  53 */       this.weapon = this.weaponFunc.apply(this.villager);
/*  54 */       if (this.weapon.func_190926_b()) {
/*  55 */         this.villager.setThought(this.missingThought);
/*  56 */         return false;
/*     */       } 
/*     */       
/*  59 */       return true;
/*     */     } 
/*     */     
/*  62 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onArrival() {
/*  67 */     if (!this.arrived) {
/*  68 */       tryAttack();
/*     */     }
/*  70 */     this.arrived = true;
/*  71 */     super.onArrival();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/*  77 */     this.villager.debugOut("Melee Start @" + this.villager.func_180425_c());
/*  78 */     this.villager.equipActionItem(this.weapon);
/*  79 */     super.func_75249_e();
/*     */   }
/*     */   
/*     */   protected boolean inRange() {
/*  83 */     if (getFollowTarget() != null) {
/*  84 */       double moddedAttackRange = this.attackRange * this.villager.getSkillLerp(this.professionType, 100, 125) / 100.0D;
/*     */       
/*  86 */       if (this.villager.func_70638_az() instanceof net.minecraft.entity.item.EntityArmorStand) {
/*  87 */         moddedAttackRange = 1.6D;
/*     */       }
/*  89 */       double distSq = getFollowTarget().func_70068_e((Entity)this.villager);
/*  90 */       return (distSq < moddedAttackRange * moddedAttackRange);
/*     */     } 
/*     */     
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isNearWalkPos() {
/*  98 */     return inRange();
/*     */   }
/*     */   
/*     */   protected void tryAttack() {
/* 102 */     if (this.weapon != null && this.villager.func_70089_S() && this.followTarget.func_70089_S() && inRange()) {
/*     */       
/* 104 */       this.attackTick = this.villager.getSkillLerp(this.professionType, 28, 24);
/* 105 */       this.attackTime = this.attackTick;
/*     */       
/* 107 */       this.navigator.func_70625_a((Entity)getFollowTarget(), 60.0F, 40.0F);
/*     */       
/* 109 */       this.villager.debugOut("Melee Attack Anim Start - " + getFollowTarget().func_145782_y());
/* 110 */       this.villager.playServerAnimation("villager_chop");
/*     */       
/* 112 */       if (this.villager.getHunger() > 2 && this.villager.func_70681_au().nextBoolean()) {
/* 113 */         this.villager.modifyHunger(-1);
/*     */       }
/* 115 */       this.villager.func_70661_as().func_75499_g();
/* 116 */       setArrived();
/* 117 */       this.villager.addJob(new TickJob(16, 0, false, () -> {
/*     */               if (this.weapon != null && getFollowTarget() != null && getFollowTarget().func_70089_S() && this.villager.func_70089_S()) {
/*     */                 this.villager.func_70652_k((Entity)getFollowTarget());
/*     */                 if (!(this.villager.func_70638_az() instanceof net.minecraft.entity.item.EntityArmorStand)) {
/*     */                   this.villager.damageItem(this.weapon, 3);
/*     */                 }
/*     */                 this.onHit.run();
/*     */                 this.villager.playSound(ModSoundEvents.villagerGrunt);
/*     */                 this.villager.throttledSadness(-1);
/*     */               } 
/*     */             }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/* 133 */     if (this.attackTick > 0) {
/* 134 */       this.attackTick--;
/* 135 */       if (this.attackTime - this.attackTick == 20) {
/* 136 */         this.villager.stopServerAnimation("villager_chop");
/*     */       }
/* 138 */     } else if (inRange()) {
/* 139 */       tryAttack();
/*     */     } 
/* 141 */     super.func_75246_d();
/*     */   }
/*     */ 
/*     */   
/*     */   protected EntityLivingBase getFollowTarget() {
/* 146 */     return this.villager.func_70638_az();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean shouldFollow() {
/* 151 */     if (this.attackTick > 0) {
/* 152 */       return false;
/*     */     }
/* 154 */     return super.shouldFollow();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 160 */     this.villager.unequipActionItem(this.weapon);
/* 161 */     this.villager.stopServerAnimation("villager_chop");
/*     */     
/* 163 */     this.villager.debugOut("Melee End");
/* 164 */     this.attackTick = 0;
/* 165 */     this.villager.pickupItems(5);
/* 166 */     this.arrived = false;
/* 167 */     this.weapon = null;
/* 168 */     super.func_75251_c();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/* 173 */     if (this.attackTick > 0) {
/* 174 */       return true;
/*     */     }
/* 176 */     if (this.villager.func_70638_az() == null) {
/* 177 */       return false;
/*     */     }
/* 179 */     return super.func_75253_b();
/*     */   }
/*     */ 
/*     */   
/*     */   void updateMovementMode() {
/* 184 */     if (this.villager.isHostile().test(this.followTarget)) {
/* 185 */       this.villager.setMovementMode(EntityVillagerTek.MovementMode.RUN);
/*     */     } else {
/* 187 */       this.villager.setMovementMode(EntityVillagerTek.MovementMode.WALK);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAIMeleeTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */