/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.pathfinding.Path;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.tangotek.tektopia.VillageManager;
/*     */ import net.tangotek.tektopia.entities.EntityVillageNavigator;
/*     */ import net.tangotek.tektopia.pathing.BasePathingNode;
/*     */ import net.tangotek.tektopia.pathing.PathNavigateVillager2;
/*     */ import net.tangotek.tektopia.structures.VillageStructure;
/*     */ 
/*     */ public abstract class EntityAIMoveToBlock extends EntityAIBase {
/*  16 */   private static int STUCK_TIME = 40;
/*     */   protected EntityVillageNavigator navigator;
/*     */   private BlockPos walkPos;
/*     */   protected BlockPos destinationPos;
/*  20 */   private int pathUpdateTick = 20;
/*     */   private boolean arrived = false;
/*  22 */   private int stuckCheck = STUCK_TIME;
/*  23 */   private Vec3d stuckPos = Vec3d.field_186680_a;
/*     */   private boolean stuck = false;
/*  25 */   private int lastPathIndex = -1;
/*     */   private Vec3d lastNodePos;
/*     */   
/*     */   public EntityAIMoveToBlock(EntityVillageNavigator v) {
/*  29 */     this.navigator = v;
/*  30 */     func_75248_a(1);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract BlockPos getDestinationBlock();
/*     */ 
/*     */   
/*     */   protected void onArrival() {}
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  41 */     if (this.navigator.hasVillage() && this.navigator.func_70661_as() instanceof PathNavigateVillager2 && canNavigate()) {
/*  42 */       this.destinationPos = getDestinationBlock();
/*  43 */       if (this.destinationPos != null) {
/*  44 */         this.stuck = false;
/*  45 */         this.stuckPos = new Vec3d(0.0D, -400.0D, 0.0D);
/*  46 */         this.arrived = false;
/*  47 */         this.pathUpdateTick = 40;
/*  48 */         doMove();
/*  49 */         return !this.stuck;
/*     */       } 
/*     */     } 
/*     */     
/*  53 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isNearWalkPos() {
/*  57 */     return (this.walkPos != null && this.walkPos.func_177951_i((Vec3i)this.navigator.func_180425_c()) <= 1.0D);
/*     */   }
/*     */   
/*     */   protected boolean isNearDestination(double range) {
/*  61 */     return (this.destinationPos.func_177951_i((Vec3i)this.navigator.func_180425_c()) < range * range);
/*     */   }
/*     */   
/*     */   protected boolean canNavigate() {
/*  65 */     return this.navigator.field_70122_E;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/*  74 */     updateMovementMode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/*  85 */     return (!this.arrived && !this.stuck && this.navigator.canNavigate());
/*     */   }
/*     */   
/*     */   protected void updateFacing() {
/*  89 */     if (!this.arrived) {
/*  90 */       if (!this.navigator.func_70661_as().func_75500_f()) {
/*  91 */         Vec3d lookPos = this.navigator.func_70661_as().func_75505_d().func_186310_f();
/*     */         
/*  93 */         this.navigator.faceLocation(lookPos.field_72450_a, lookPos.field_72449_c, 4.0F);
/*     */       }
/*     */     
/*  96 */     } else if (this.destinationPos != null) {
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   abstract void updateMovementMode();
/*     */   
/*     */   public void func_75246_d() {
/* 104 */     this.pathUpdateTick--;
/* 105 */     if (this.pathUpdateTick <= 0 && !this.arrived) {
/* 106 */       this.pathUpdateTick = 40;
/*     */       
/* 108 */       this.navigator.updateMovement(this.arrived);
/*     */     } 
/*     */     
/* 111 */     if (!this.arrived && isNearWalkPos()) {
/* 112 */       this.arrived = true;
/* 113 */       this.navigator.func_70661_as().func_75499_g();
/*     */       
/* 115 */       onArrival();
/*     */     } 
/*     */     
/* 118 */     updateFacing();
/*     */     
/* 120 */     if (!this.arrived) {
/* 121 */       if (this.navigator.func_70661_as().func_75500_f()) {
/* 122 */         doMove();
/*     */       } else {
/* 124 */         int pathIndex = this.navigator.func_70661_as().func_75505_d().func_75873_e();
/* 125 */         if (this.lastPathIndex != pathIndex) {
/* 126 */           this.lastNodePos = this.navigator.func_70661_as().func_75505_d().func_186310_f();
/* 127 */           this.lastPathIndex = pathIndex;
/*     */         } 
/*     */       } 
/*     */       
/* 131 */       this.stuckCheck--;
/* 132 */       if (this.stuckCheck < 0) {
/* 133 */         this.stuckCheck = STUCK_TIME;
/* 134 */         if (!this.navigator.func_70661_as().func_75500_f()) {
/* 135 */           this.stuck = (this.navigator.func_174791_d().func_72436_e(this.stuckPos) < 1.0D);
/* 136 */           this.stuckPos = this.navigator.func_174791_d();
/*     */         } else {
/*     */           
/* 139 */           this.navigator.debugOut("has no path?");
/*     */         } 
/*     */       } 
/*     */       
/* 143 */       if (this.stuck) {
/* 144 */         if (attemptStuckFix() && this.lastPathIndex >= 0) {
/*     */           
/* 146 */           this.navigator.func_70661_as().func_75499_g();
/* 147 */           doMove();
/*     */         } else {
/* 149 */           onStuck();
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean attemptStuckFix() {
/* 156 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onStuck() {
/* 161 */     VillageManager.get(this.navigator.field_70170_p).submitStuck(this.navigator.func_180425_c());
/*     */     
/* 163 */     Path path = this.navigator.func_70661_as().func_75505_d();
/* 164 */     if (path != null)
/*     */     {
/*     */       
/* 167 */       if (this.navigator.hasVillage() && this.navigator.func_70661_as() instanceof PathNavigateVillager2) {
/* 168 */         PathNavigateVillager2 pathNavigateVillager2 = (PathNavigateVillager2)this.navigator.func_70661_as();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 174 */     this.navigator.func_70661_as().func_75499_g();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onPathFailed(BlockPos pos) {
/* 179 */     VillageManager.get(this.navigator.field_70170_p).submitStuck(this.navigator.func_180425_c());
/* 180 */     this.stuck = true;
/*     */   }
/*     */   
/*     */   public BlockPos getWalkPos() {
/* 184 */     return this.walkPos;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockPos findWalkPos() {
/* 189 */     BlockPos pos = this.destinationPos;
/* 190 */     BlockPos diff = this.navigator.func_180425_c().func_177973_b((Vec3i)pos);
/* 191 */     EnumFacing facing = EnumFacing.func_176737_a(diff.func_177958_n(), 0.0F, diff.func_177952_p());
/*     */     
/* 193 */     BlockPos testPos = pos.func_177972_a(facing);
/* 194 */     if (isWalkable(testPos, this.navigator)) {
/* 195 */       return testPos;
/*     */     }
/* 197 */     testPos = pos.func_177972_a(facing).func_177972_a(facing.func_176746_e());
/* 198 */     if (isWalkable(testPos, this.navigator)) {
/* 199 */       return testPos;
/*     */     }
/* 201 */     testPos = pos.func_177972_a(facing).func_177972_a(facing.func_176735_f());
/* 202 */     if (isWalkable(testPos, this.navigator)) {
/* 203 */       return testPos;
/*     */     }
/* 205 */     testPos = pos.func_177972_a(facing.func_176746_e());
/* 206 */     if (isWalkable(testPos, this.navigator)) {
/* 207 */       return testPos;
/*     */     }
/* 209 */     testPos = pos.func_177972_a(facing.func_176735_f());
/* 210 */     if (isWalkable(testPos, this.navigator)) {
/* 211 */       return testPos;
/*     */     }
/* 213 */     testPos = pos.func_177972_a(facing.func_176734_d());
/* 214 */     if (isWalkable(testPos, this.navigator)) {
/* 215 */       return testPos;
/*     */     }
/* 217 */     testPos = pos.func_177972_a(facing.func_176734_d()).func_177972_a(facing.func_176746_e());
/* 218 */     if (isWalkable(testPos, this.navigator)) {
/* 219 */       return testPos;
/*     */     }
/* 221 */     testPos = pos.func_177972_a(facing.func_176734_d()).func_177972_a(facing.func_176735_f());
/* 222 */     if (isWalkable(testPos, this.navigator)) {
/* 223 */       return testPos;
/*     */     }
/*     */     
/* 226 */     if (isWalkable(pos, this.navigator)) {
/* 227 */       return pos;
/*     */     }
/* 229 */     return null;
/*     */   }
/*     */   
/*     */   protected boolean isWalkable(BlockPos pos, EntityVillageNavigator nav) {
/* 233 */     if (nav.getVillage() != null) {
/* 234 */       BasePathingNode baseNode = nav.getVillage().getPathingGraph().getBaseNode(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
/* 235 */       if (baseNode != null) {
/* 236 */         if (VillageStructure.isWoodDoor(nav.field_70170_p, pos) || VillageStructure.isGate(nav.field_70170_p, pos)) {
/* 237 */           return false;
/*     */         }
/* 239 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 243 */     return false;
/*     */   }
/*     */   
/*     */   protected void doMove() {
/* 247 */     this.arrived = false;
/* 248 */     this.stuckCheck = STUCK_TIME;
/* 249 */     this.walkPos = findWalkPos();
/* 250 */     if (this.walkPos == null) {
/* 251 */       this.stuck = true;
/* 252 */     } else if (!isNearWalkPos() && canNavigate()) {
/* 253 */       boolean pathFound = this.navigator.func_70661_as().func_75492_a(this.walkPos.func_177958_n(), this.walkPos.func_177956_o(), this.walkPos.func_177952_p(), this.navigator.func_70689_ay());
/* 254 */       if (pathFound) {
/*     */         
/* 256 */         this.navigator.func_70671_ap().func_75650_a(this.walkPos.func_177958_n(), this.walkPos.func_177956_o(), this.walkPos.func_177952_p(), 50.0F, this.navigator.func_70646_bf());
/*     */       } else {
/* 258 */         onPathFailed(this.walkPos);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   protected boolean hasArrived() {
/* 263 */     return this.arrived;
/*     */   }
/*     */   protected void setArrived() {
/* 266 */     this.arrived = true;
/*     */   }
/*     */   public void func_75251_c() {
/* 269 */     super.func_75251_c();
/* 270 */     this.arrived = false;
/* 271 */     this.stuckCheck = STUCK_TIME;
/* 272 */     this.navigator.resetMovement();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAIMoveToBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */