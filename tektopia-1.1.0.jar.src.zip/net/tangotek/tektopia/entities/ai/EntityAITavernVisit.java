/*    */ package net.tangotek.tektopia.entities.ai;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import net.tangotek.tektopia.ModSoundEvents;
/*    */ import net.tangotek.tektopia.entities.EntityVillageNavigator;
/*    */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityAITavernVisit
/*    */   extends EntityAIWanderStructure
/*    */ {
/*    */   public EntityAITavernVisit(EntityVillagerTek v, Predicate<EntityVillagerTek> shouldPred) {
/* 14 */     super(v, EntityVillagerTek.findLocalTavern(), shouldPred, 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean func_75250_a() {
/* 19 */     if (super.func_75250_a() && this.villager.isAIFilterEnabled("visit_tavern")) {
/* 20 */       return true;
/*    */     }
/*    */     
/* 23 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75253_b() {
/* 29 */     if (this.villager.isWorkTime() || this.villager.shouldSleep() || this.villager.getHappy() >= this.villager.getMaxHappy()) {
/* 30 */       return false;
/*    */     }
/*    */     
/* 33 */     return super.func_75253_b();
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_75246_d() {
/* 38 */     super.func_75246_d();
/*    */     
/* 40 */     if (hasArrived())
/*    */     {
/* 42 */       if (this.villager.isSitting()) {
/* 43 */         if (this.villager.func_70681_au().nextInt(300) == 0) {
/* 44 */           this.villager.modifyHappy(1);
/*    */           
/* 46 */           if (this.villager.field_70170_p.func_72872_a(EntityVillageNavigator.class, this.villager.func_174813_aQ().func_186662_g(8.0D)).size() > 1) {
/* 47 */             this.villager.func_184185_a(ModSoundEvents.villagerSocialize, 0.4F + this.villager.func_70681_au().nextFloat() * 0.7F, this.villager.func_70681_au().nextFloat() * 0.4F + 0.8F);
/*    */           }
/* 49 */           if (this.villager.func_70681_au().nextInt(5) == 0) {
/* 50 */             this.villager.cheerBeer(2);
/*    */           }
/*    */         }
/*    */       
/* 54 */       } else if (this.villager.func_70681_au().nextInt(400) == 0) {
/* 55 */         this.villager.modifyHappy(1);
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAITavernVisit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */