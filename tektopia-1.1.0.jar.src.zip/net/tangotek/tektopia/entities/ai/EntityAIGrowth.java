/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.IGrowable;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.tangotek.tektopia.ModSoundEvents;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.entities.EntityDruid;
/*     */ import net.tangotek.tektopia.entities.EntityVillageNavigator;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ 
/*     */ public class EntityAIGrowth
/*     */   extends EntityAIMoveToBlock
/*     */ {
/*     */   private boolean arrived = false;
/*  20 */   private int castTime = 0;
/*  21 */   private int castIterations = 0; private EntityDruid druid; private final double range;
/*     */   private GrowthType growthType;
/*  23 */   private final int CAST_TIME = 90;
/*     */   private BlockPos growthPos;
/*     */   
/*  26 */   private enum GrowthType { FARM,
/*  27 */     SAPLING; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityAIGrowth(EntityVillagerTek entityIn, double range) {
/*  34 */     super((EntityVillageNavigator)entityIn);
/*  35 */     this.druid = (EntityDruid)entityIn;
/*  36 */     this.range = range;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  41 */     this.growthPos = null;
/*  42 */     if (this.druid.isAITick() && this.druid.func_70681_au().nextInt(10) == 0 && this.druid.hasVillage() && this.druid.isWorkTime() && this.druid.isGrowTime()) {
/*  43 */       boolean trySapling = this.druid.func_70681_au().nextBoolean();
/*  44 */       if (trySapling && this.druid.isAIFilterEnabled("cast_growth_trees")) {
/*     */         
/*  46 */         this.growthType = GrowthType.SAPLING;
/*  47 */         this.growthPos = this.druid.getVillage().requestBlock(Blocks.field_150345_g);
/*     */       }
/*  49 */       else if (this.druid.isAIFilterEnabled("cast_growth_crops")) {
/*     */         
/*  51 */         this.growthType = GrowthType.FARM;
/*  52 */         BlockPos farmPos = this.druid.getVillage().requestFarmland(bp -> canBlockGrow(bp));
/*  53 */         if (farmPos != null) {
/*  54 */           this.growthPos = farmPos.func_177984_a();
/*     */         }
/*     */       } 
/*     */       
/*  58 */       if (this.growthPos != null) {
/*  59 */         return super.func_75250_a();
/*     */       }
/*     */     } 
/*     */     
/*  63 */     return false;
/*     */   }
/*     */   
/*     */   private boolean canBlockGrow(BlockPos bp) {
/*  67 */     BlockPos cropPos = bp.func_177984_a();
/*  68 */     IBlockState cropState = this.druid.field_70170_p.func_180495_p(cropPos);
/*  69 */     if (cropState.func_177230_c() instanceof IGrowable) {
/*  70 */       IGrowable growable = (IGrowable)cropState.func_177230_c();
/*  71 */       if (growable.func_176473_a(this.druid.field_70170_p, cropPos, cropState, false)) {
/*  72 */         return true;
/*     */       }
/*     */     } 
/*  75 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/*  80 */     super.func_75249_e();
/*  81 */     this.castIterations = MathHelper.func_76125_a(this.druid.getSkill(ProfessionType.DRUID) / 20, 1, 5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockPos getDestinationBlock() {
/*  86 */     return this.growthPos;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onArrival() {
/*  91 */     if (!this.arrived) {
/*  92 */       tryCast();
/*     */     }
/*  94 */     this.arrived = true;
/*  95 */     super.onArrival();
/*     */   }
/*     */   
/*     */   protected boolean inRange() {
/*  99 */     return (this.growthPos.func_177951_i((Vec3i)this.druid.func_180425_c()) < this.range * this.range);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isNearWalkPos() {
/* 104 */     return inRange();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75252_g() {
/* 110 */     return (this.castTime <= 0);
/*     */   }
/*     */   
/*     */   protected void tryCast() {
/* 114 */     if (this.druid.func_70089_S() && inRange()) {
/* 115 */       this.castTime = 90;
/* 116 */       this.druid.playServerAnimation("villager_cast_grow");
/* 117 */       this.druid.modifyHunger(-2);
/* 118 */       this.druid.func_70661_as().func_75499_g();
/* 119 */       this.druid.setSpellBlock(this.growthPos);
/* 120 */       setArrived();
/*     */       
/* 122 */       this.druid.playSound(ModSoundEvents.healingSource);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/* 129 */     this.castTime--;
/* 130 */     if (this.castTime == 48) {
/* 131 */       this.druid.playSound(ModSoundEvents.villagerEnchant);
/* 132 */       this.druid.setSpellBlock(this.growthPos);
/*     */       
/* 134 */       if (this.growthType == GrowthType.SAPLING) {
/* 135 */         int growthCount = this.druid.getSkillLerp(ProfessionType.DRUID, 6, 20);
/* 136 */         for (int i = 0; i < growthCount; i++) {
/* 137 */           growBlock(this.growthPos);
/*     */         }
/*     */       }
/* 140 */       else if (this.growthType == GrowthType.FARM) {
/* 141 */         int range = this.druid.getGrowthRange();
/* 142 */         for (int x = -range; x <= range; x++) {
/* 143 */           for (int z = -range; z <= range; z++) {
/* 144 */             BlockPos localPos = this.growthPos.func_177965_g(x).func_177964_d(z);
/* 145 */             growBlock(localPos);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 150 */       if (this.castIterations == 0) {
/* 151 */         this.druid.tryAddSkill(ProfessionType.DRUID, 12);
/*     */       }
/*     */     } 
/* 154 */     if (this.castTime >= 0) {
/* 155 */       this.druid.faceLocation(this.growthPos.func_177958_n(), this.growthPos.func_177952_p(), 30.0F);
/*     */     }
/* 157 */     if (this.castTime <= 0 && this.castIterations > 0) {
/* 158 */       this.castIterations--;
/* 159 */       this.druid.stopServerAnimation("villager_cast_grow");
/* 160 */       this.druid.setSpellBlock(null);
/* 161 */       tryCast();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 166 */     super.func_75246_d();
/*     */   }
/*     */   
/*     */   private void growBlock(BlockPos pos) {
/* 170 */     if (this.druid.hasVillage()) {
/* 171 */       IBlockState growthState = this.druid.getVillage().getWorld().func_180495_p(pos);
/* 172 */       Block growthBlock = growthState.func_177230_c();
/* 173 */       if (growthBlock instanceof IGrowable) {
/* 174 */         IGrowable growable = (IGrowable)growthBlock;
/* 175 */         if (growable.func_176473_a(this.druid.field_70170_p, pos, growthState, false) && 
/* 176 */           growable.func_180670_a(this.druid.field_70170_p, this.druid.func_70681_au(), pos, growthState)) {
/* 177 */           growable.func_176474_b(this.druid.field_70170_p, this.druid.func_70681_au(), pos, growthState);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 186 */     if (this.druid.hasVillage()) {
/* 187 */       this.druid.getVillage().releaseBlockClaim(Blocks.field_150345_g, this.growthPos);
/*     */     }
/* 189 */     this.druid.setSpellBlock(null);
/* 190 */     this.druid.stopServerAnimation("villager_cast_grow");
/* 191 */     this.arrived = false;
/* 192 */     this.castTime = 0;
/* 193 */     super.func_75251_c();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/* 198 */     if (this.castTime > 0) {
/* 199 */       return true;
/*     */     }
/* 201 */     return super.func_75253_b();
/*     */   }
/*     */ 
/*     */   
/*     */   void updateMovementMode() {
/* 206 */     this.druid.setMovementMode(this.druid.getDefaultMovement());
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAIGrowth.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */