/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import com.google.common.base.Predicate;
/*     */ import com.google.common.base.Predicates;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.EntitySelectors;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.tangotek.tektopia.ModSoundEvents;
/*     */ import net.tangotek.tektopia.entities.EntityDeathCloud;
/*     */ import net.tangotek.tektopia.entities.EntityNecromancer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityAIDeathCloud
/*     */   extends EntityAIBase
/*     */ {
/*     */   private EntityNecromancer necro;
/*     */   private EntityPlayer targetPlayer;
/*  25 */   private int cooldownTick = 0;
/*     */   private int castTime;
/*     */   private BlockPos targetPos;
/*     */   private final Predicate<Entity> entityPredicate;
/*     */   
/*     */   public EntityAIDeathCloud(EntityNecromancer n) {
/*  31 */     this.necro = n;
/*  32 */     func_75248_a(1);
/*  33 */     this.entityPredicate = Predicates.and(EntitySelectors.field_188444_d, e -> (e.func_70089_S() && this.necro.func_70635_at().func_75522_a(e)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  38 */     if (this.necro.isAITick() && this.necro.field_70173_aa > this.cooldownTick && !this.necro.hasVillagerDied()) {
/*  39 */       this.targetPlayer = this.necro.field_70170_p.func_190525_a(this.necro.field_70165_t, this.necro.field_70163_u, this.necro.field_70161_v, 16.0D, this.entityPredicate);
/*  40 */       if (this.targetPlayer != null) {
/*  41 */         this.targetPos = this.targetPlayer.func_180425_c();
/*  42 */         if (!this.targetPlayer.field_70122_E && 
/*  43 */           this.necro.field_70170_p.func_180495_p(this.targetPos.func_177977_b()).func_177230_c().equals(Blocks.field_150350_a)) {
/*  44 */           this.targetPos = this.targetPos.func_177977_b();
/*     */         }
/*  46 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/*  50 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/*  56 */     startCast();
/*  57 */     super.func_75249_e();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/*  63 */     return (this.castTime > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75252_g() {
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/*  75 */     if (this.castTime > 0) {
/*  76 */       this.castTime--;
/*  77 */       if (this.castTime >= 37) {
/*     */         
/*  79 */         if (this.castTime == 37) {
/*  80 */           createCloud();
/*     */         }
/*  82 */         else if (this.castTime == 33) {
/*  83 */           this.necro.func_184185_a(ModSoundEvents.deathCircle, this.necro.field_70170_p.field_73012_v.nextFloat() * 0.4F + 1.2F, this.necro.field_70170_p.field_73012_v.nextFloat() * 0.4F + 0.8F);
/*     */         } 
/*     */         
/*  86 */         if (this.castTime > 70) {
/*  87 */           this.necro.func_70625_a((Entity)this.targetPlayer, 30.0F, 30.0F);
/*     */         }
/*     */       } 
/*     */       
/*  91 */       if (this.castTime == 0) {
/*  92 */         this.necro.stopServerAnimation("necro_cast_forward");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  97 */     super.func_75246_d();
/*     */   }
/*     */ 
/*     */   
/*     */   private void createCloud() {
/* 102 */     EntityDeathCloud cloud = new EntityDeathCloud(this.necro.field_70170_p, this.targetPos.func_177958_n(), this.targetPos.func_177956_o(), this.targetPos.func_177952_p());
/* 103 */     cloud.func_184483_a(3.0F);
/* 104 */     cloud.func_184485_d(10);
/* 105 */     cloud.func_184486_b(40 + this.necro.getLevel() * 30);
/* 106 */     cloud.func_184487_c(0.03F);
/* 107 */     this.necro.field_70170_p.func_72838_d((Entity)cloud);
/*     */     
/* 109 */     this.necro.playSound(ModSoundEvents.deathSummonEnd);
/*     */   }
/*     */ 
/*     */   
/*     */   private void startCast() {
/* 114 */     this.cooldownTick = this.necro.field_70173_aa + this.necro.getLevelCooldown(this.necro.func_70681_au().nextInt(160) + 160);
/* 115 */     this.castTime = 80;
/* 116 */     this.necro.func_70661_as().func_75499_g();
/* 117 */     this.necro.playServerAnimation("necro_cast_forward");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void stopCast() {
/* 123 */     this.necro.stopServerAnimation("necro_cast_forward");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 129 */     stopCast();
/* 130 */     this.castTime = 0;
/* 131 */     super.func_75251_c();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAIDeathCloud.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */