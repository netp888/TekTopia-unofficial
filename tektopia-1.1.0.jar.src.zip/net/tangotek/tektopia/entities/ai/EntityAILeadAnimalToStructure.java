/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.tangotek.tektopia.EntityTagType;
/*     */ import net.tangotek.tektopia.ModEntities;
/*     */ import net.tangotek.tektopia.entities.EntityVillageNavigator;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ import net.tangotek.tektopia.structures.VillageStructure;
/*     */ import net.tangotek.tektopia.structures.VillageStructureType;
/*     */ 
/*     */ public class EntityAILeadAnimalToStructure
/*     */   extends EntityAIMoveToBlock {
/*     */   private final VillageStructureType structureType;
/*     */   private VillageStructure destinationStructure;
/*     */   protected final EntityVillagerTek villager;
/*     */   private boolean active = false;
/*  20 */   private int pathTick = 0;
/*     */   private final EntityTagType entTagType;
/*     */   
/*     */   public EntityAILeadAnimalToStructure(EntityVillagerTek v, VillageStructureType structureType, EntityTagType tagType) {
/*  24 */     super((EntityVillageNavigator)v);
/*  25 */     this.villager = v;
/*  26 */     this.structureType = structureType;
/*  27 */     this.destinationStructure = null;
/*  28 */     this.entTagType = tagType;
/*     */   }
/*     */   
/*     */   protected VillageStructure getDestinationStructure() {
/*  32 */     return this.villager.getVillage().getNearestStructure(this.structureType, this.villager.func_180425_c());
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockPos getDestinationBlock() {
/*  37 */     this.destinationPos = null;
/*  38 */     if (this.villager.getVillage() != null && this.villager.getLeadAnimal() != null && this.villager.isWorkTime()) {
/*  39 */       this.destinationStructure = getDestinationStructure();
/*  40 */       if (this.destinationStructure != null) {
/*  41 */         this.destinationPos = this.destinationStructure.getSafeSpot();
/*     */       }
/*     */     } 
/*     */     
/*  45 */     return this.destinationPos;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  50 */     if (this.villager.isAITick()) {
/*  51 */       return super.func_75250_a();
/*     */     }
/*  53 */     return false;
/*     */   }
/*     */   
/*     */   public void func_75249_e() {
/*  57 */     this.active = true;
/*  58 */     this.pathTick = 30;
/*     */     
/*  60 */     super.func_75249_e();
/*     */   }
/*     */   
/*     */   public boolean func_75253_b() {
/*  64 */     return this.active;
/*     */   }
/*     */ 
/*     */   
/*     */   void updateMovementMode() {
/*  69 */     this.villager.setMovementMode(this.villager.getDefaultMovement());
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/*  74 */     if (this.villager.getLeadAnimal() != null) {
/*  75 */       if (this.villager.getLeadAnimal().func_70068_e((Entity)this.villager) > 40.0D) {
/*  76 */         teleportAnimal(this.villager.func_180425_c());
/*     */       }
/*     */       
/*  79 */       if (!this.villager.getLeadAnimal().func_70089_S()) {
/*  80 */         this.active = false;
/*  81 */       } else if (this.villager.getLeadAnimal().func_110166_bE() != this.villager) {
/*  82 */         this.active = false;
/*     */       } 
/*     */     } 
/*  85 */     this.pathTick--;
/*  86 */     if (this.pathTick <= 0) {
/*  87 */       updateAnimalPath();
/*  88 */       if (this.villager.func_70681_au().nextInt(8) == 0) {
/*  89 */         this.villager.modifyHunger(-1);
/*     */       }
/*  91 */       this.pathTick = 30;
/*     */     } 
/*     */     
/*  94 */     super.func_75246_d();
/*     */   }
/*     */   
/*     */   private void updateAnimalPath() {
/*  98 */     this.villager.getLeadAnimal().func_70690_d(new PotionEffect(MobEffects.field_76424_c, 40));
/*  99 */     this.villager.getLeadAnimal().func_70661_as().func_75497_a((Entity)this.villager, this.villager.getLeadAnimal().func_70689_ay() * 1.2D);
/*     */   }
/*     */   
/*     */   private void teleportAnimal(BlockPos pos) {
/* 103 */     this.villager.getLeadAnimal().func_70634_a(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onArrival() {
/* 108 */     this.active = false;
/* 109 */     super.onArrival();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onStuck() {
/* 114 */     this.active = false;
/* 115 */     super.onStuck();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onPathFailed(BlockPos pos) {
/* 120 */     this.active = false;
/* 121 */     super.onPathFailed(pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 126 */     if (this.villager.getLeadAnimal() != null) {
/* 127 */       if (!this.destinationStructure.isBlockInside(this.villager.getLeadAnimal().func_180425_c())) {
/* 128 */         teleportAnimal(this.destinationStructure.getSafeSpot());
/*     */       }
/*     */ 
/*     */       
/* 132 */       if (this.entTagType != null) {
/* 133 */         ModEntities.makeTaggedEntity((Entity)this.villager.getLeadAnimal(), this.entTagType);
/*     */       }
/* 135 */       this.villager.getLeadAnimal().func_110160_i(true, false);
/* 136 */       this.villager.setLeadAnimal(null);
/*     */     } 
/*     */     
/* 139 */     this.active = false;
/* 140 */     this.destinationStructure = null;
/* 141 */     super.func_75251_c();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAILeadAnimalToStructure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */