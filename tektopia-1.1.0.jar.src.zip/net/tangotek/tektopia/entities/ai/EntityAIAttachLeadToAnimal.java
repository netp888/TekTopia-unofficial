/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.passive.EntityAnimal;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.pathfinding.PathNavigateGround;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.tangotek.tektopia.entities.EntityVillageNavigator;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ 
/*     */ public abstract class EntityAIAttachLeadToAnimal
/*     */   extends EntityAIFollow {
/*  15 */   protected EntityAnimal targetAnimal = null;
/*     */   private boolean active = false;
/*  17 */   private ItemStack leadItem = new ItemStack(Items.field_151058_ca);
/*  18 */   private int leashTime = 0;
/*     */   private Predicate<EntityVillagerTek> shouldPred;
/*     */   protected final EntityVillagerTek villager;
/*     */   
/*     */   public EntityAIAttachLeadToAnimal(EntityVillagerTek v, Predicate<EntityVillagerTek> shouldPred) {
/*  23 */     super((EntityVillageNavigator)v);
/*  24 */     this.villager = v;
/*  25 */     this.shouldPred = shouldPred;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  30 */     if (this.villager.isAITick() && this.villager.hasVillage() && this.shouldPred != null && this.shouldPred.test(this.villager)) {
/*  31 */       return super.func_75250_a();
/*     */     }
/*     */     
/*  34 */     return false;
/*     */   }
/*     */   
/*     */   public void func_75249_e() {
/*  38 */     this.active = true;
/*  39 */     this.villager.equipActionItem(this.leadItem);
/*  40 */     super.func_75249_e();
/*     */   }
/*     */   
/*     */   public boolean func_75253_b() {
/*  44 */     return (this.targetAnimal != null && this.active);
/*     */   }
/*     */   
/*     */   public void func_75246_d() {
/*  48 */     if (this.leashTime > 0) {
/*  49 */       this.villager.func_70671_ap().func_75650_a(this.destinationPos.func_177958_n(), this.destinationPos.func_177956_o(), this.destinationPos.func_177952_p(), 30.0F, 30.0F);
/*  50 */       this.leashTime--;
/*  51 */       if (this.leashTime == 0) {
/*  52 */         attachLeash();
/*  53 */         this.active = false;
/*     */       } 
/*     */     } else {
/*     */       
/*  57 */       super.func_75246_d();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75252_g() {
/*  63 */     return (this.leashTime <= 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onArrival() {
/*  68 */     if (this.targetAnimal.func_110166_bE() instanceof net.tangotek.tektopia.entities.EntityMerchant) {
/*  69 */       this.targetAnimal.func_110160_i(true, false);
/*     */     }
/*  71 */     if (this.targetAnimal.func_110166_bE() != null) {
/*  72 */       this.active = false;
/*     */     } else {
/*  74 */       startLeash();
/*     */     } 
/*  76 */     super.onArrival();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onStuck() {
/*  81 */     this.active = false;
/*  82 */     super.onStuck();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onPathFailed(BlockPos pos) {
/*  87 */     this.active = false;
/*  88 */     super.onPathFailed(pos);
/*     */   }
/*     */   
/*     */   protected void attachLeash() {
/*  92 */     this.targetAnimal.func_110162_b((Entity)this.villager, true);
/*  93 */     this.villager.setLeadAnimal(this.targetAnimal);
/*     */     
/*  95 */     this.villager.throttledSadness(-3);
/*     */ 
/*     */     
/*  98 */     if (this.targetAnimal.func_70661_as() instanceof PathNavigateGround) {
/*  99 */       PathNavigateGround navGround = (PathNavigateGround)this.targetAnimal.func_70661_as();
/* 100 */       navGround.func_189566_q().func_186317_a(true);
/* 101 */       navGround.func_189566_q().func_186321_b(true);
/*     */     } 
/* 103 */     this.active = false;
/*     */   }
/*     */   
/*     */   private void startLeash() {
/* 107 */     this.villager.debugOut("Attaching lead to animal [ " + this.targetAnimal.func_174791_d() + "]");
/* 108 */     this.leashTime = 36;
/* 109 */     this.villager.func_70661_as().func_75499_g();
/* 110 */     this.villager.playServerAnimation("villager_take");
/*     */   }
/*     */   
/*     */   private void stopLeash() {
/* 114 */     this.villager.stopServerAnimation("villager_take");
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 119 */     this.leashTime = 0;
/* 120 */     this.active = false;
/* 121 */     this.targetAnimal = null;
/* 122 */     this.villager.unequipActionItem(this.leadItem);
/* 123 */     stopLeash();
/* 124 */     super.func_75251_c();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAIAttachLeadToAnimal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */