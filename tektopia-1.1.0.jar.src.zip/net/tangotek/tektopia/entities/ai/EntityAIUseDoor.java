/*     */ package net.tangotek.tektopia.entities.ai;
/*     */ 
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockDoor;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.pathfinding.Path;
/*     */ import net.minecraft.pathfinding.PathPoint;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ import net.tangotek.tektopia.pathing.PathNavigateVillager2;
/*     */ 
/*     */ public class EntityAIUseDoor
/*     */   extends EntityAIBase
/*     */ {
/*     */   boolean closeDoor;
/*     */   int closeDoorTimer;
/*     */   protected EntityLiving entity;
/*  23 */   protected BlockPos doorPosition = BlockPos.field_177992_a;
/*     */   
/*     */   protected BlockDoor doorBlock;
/*     */ 
/*     */   
/*     */   public EntityAIUseDoor(EntityLiving entitylivingIn, boolean shouldClose) {
/*  29 */     this.entity = entitylivingIn;
/*  30 */     this.closeDoor = shouldClose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  38 */     if (!this.entity.field_70123_F)
/*     */     {
/*  40 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  44 */     PathNavigateVillager2 pathNavigate = (PathNavigateVillager2)this.entity.func_70661_as();
/*  45 */     Path path = pathNavigate.func_75505_d();
/*     */     
/*  47 */     if (path != null && !path.func_75879_b() && pathNavigate.getEnterDoors()) {
/*     */       
/*  49 */       for (int i = 0; i < Math.min(path.func_75873_e() + 2, path.func_75874_d()); i++) {
/*     */         
/*  51 */         PathPoint pathpoint = path.func_75877_a(i);
/*  52 */         this.doorPosition = new BlockPos(pathpoint.field_75839_a, pathpoint.field_75837_b + 1, pathpoint.field_75838_c);
/*     */         
/*  54 */         if (this.entity.func_70092_e(this.doorPosition.func_177958_n(), this.entity.field_70163_u, this.doorPosition.func_177952_p()) <= 2.25D) {
/*     */           
/*  56 */           this.doorBlock = getBlockDoor(this.doorPosition);
/*     */           
/*  58 */           if (this.doorBlock != null)
/*     */           {
/*  60 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/*  65 */       this.doorPosition = (new BlockPos((Entity)this.entity)).func_177984_a();
/*  66 */       this.doorBlock = getBlockDoor(this.doorPosition);
/*  67 */       return (this.doorBlock != null);
/*     */     } 
/*     */ 
/*     */     
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BlockDoor getBlockDoor(BlockPos pos) {
/*  79 */     IBlockState iblockstate = this.entity.field_70170_p.func_180495_p(pos);
/*  80 */     Block block = iblockstate.func_177230_c();
/*  81 */     return (block instanceof BlockDoor && iblockstate.func_185904_a() == Material.field_151575_d) ? (BlockDoor)block : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/*  90 */     return (this.closeDoor && this.closeDoorTimer >= 0);
/*     */   }
/*     */   
/*     */   private boolean isDoorClear() {
/*  94 */     return this.entity.field_70170_p.func_72872_a(EntityVillagerTek.class, new AxisAlignedBB(this.doorPosition)).isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/* 102 */     this.closeDoorTimer = 25;
/* 103 */     openDoor(true);
/*     */   }
/*     */   
/*     */   private void openDoor(boolean open) {
/* 107 */     this.doorBlock.func_176512_a(this.entity.field_70170_p, this.doorPosition, open);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 115 */     if (this.closeDoor)
/*     */     {
/* 117 */       openDoor(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/* 126 */     this.closeDoorTimer--;
/* 127 */     if (this.closeDoorTimer == 0 && 
/* 128 */       !isDoorClear()) {
/* 129 */       openDoor(true);
/* 130 */       this.closeDoorTimer = 25;
/*     */     } 
/*     */ 
/*     */     
/* 134 */     super.func_75246_d();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\ai\EntityAIUseDoor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */