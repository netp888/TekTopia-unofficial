/*     */ package net.tangotek.tektopia.entities;
/*     */ import com.google.common.base.Optional;
/*     */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.SoundCategory;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import net.tangotek.tektopia.ModSoundEvents;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.TekVillager;
/*     */ import net.tangotek.tektopia.Village;
/*     */ import net.tangotek.tektopia.VillagerRole;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAIEarthReform;
/*     */ 
/*     */ public class EntityDruid extends EntityVillagerTek {
/*  24 */   protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityDruid.class);
/*     */   
/*  26 */   private static final DataParameter<Optional<BlockPos>> SPELL_EARTH_REFORM = EntityDataManager.func_187226_a(EntityDruid.class, DataSerializers.field_187201_k);
/*  27 */   protected static final DataParameter<Optional<BlockPos>> SPELL_BLOCK = EntityDataManager.func_187226_a(EntityDruid.class, DataSerializers.field_187201_k);
/*     */   
/*  29 */   private static final DataParameter<Boolean> CAST_EARTH_REFORM = EntityDataManager.func_187226_a(EntityDruid.class, DataSerializers.field_187198_h);
/*  30 */   private static final DataParameter<Boolean> CAST_GROWTH_CROPS = EntityDataManager.func_187226_a(EntityDruid.class, DataSerializers.field_187198_h);
/*  31 */   private static final DataParameter<Boolean> CAST_GROWTH_TREES = EntityDataManager.func_187226_a(EntityDruid.class, DataSerializers.field_187198_h);
/*     */   
/*  33 */   private static final int[] blockStateIds = new int[] {
/*  34 */       Block.func_176210_f(Blocks.field_150346_d.func_176223_P()), 
/*  35 */       Block.func_176210_f(Blocks.field_150346_d.func_176223_P()), 
/*  36 */       Block.func_176210_f(Blocks.field_150348_b.func_176223_P()), 
/*  37 */       Block.func_176210_f(Blocks.field_150347_e.func_176223_P())
/*     */     };
/*     */   
/*  40 */   private int earthReformTicks = 0;
/*  41 */   private int growthTicks = 0;
/*     */   private BlockPos clientSpellBlock;
/*     */   private boolean growthFirst = true;
/*     */   
/*     */   static {
/*  46 */     animHandler.addAnim("tektopia", "villager_cast_forward", "druid_m", false);
/*  47 */     animHandler.addAnim("tektopia", "villager_cast_grow", "druid_m", false);
/*     */     
/*  49 */     EntityVillagerTek.setupAnimations(animHandler, "druid_m");
/*     */   }
/*     */   
/*     */   public EntityDruid(World worldIn) {
/*  53 */     super(worldIn, ProfessionType.DRUID, VillagerRole.VILLAGER.value);
/*     */     
/*  55 */     Runnable runner = () -> this.field_70170_p.func_184134_a(this.field_70165_t, this.field_70163_u, this.field_70161_v, ModSoundEvents.earthBlast, SoundCategory.NEUTRAL, 1.0F, this.field_70146_Z.nextFloat() * 0.2F + 0.9F, false);
/*     */     
/*  57 */     if (this.field_70170_p.field_72995_K)
/*  58 */       addAnimationTrigger("tektopia:villager_cast_forward", 64, runner); 
/*     */   }
/*     */   
/*     */   public AnimationHandler getAnimationHandler() {
/*  62 */     return animHandler;
/*     */   }
/*     */   
/*     */   protected void func_184651_r() {
/*  66 */     super.func_184651_r();
/*     */     
/*  68 */     this.growthFirst = func_70681_au().nextBoolean();
/*  69 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIEarthReform(this));
/*  70 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIGrowth(this, 6.0D));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_70088_a() {
/*  75 */     super.func_70088_a();
/*  76 */     this.field_70180_af.func_187214_a(SPELL_EARTH_REFORM, Optional.absent());
/*  77 */     this.field_70180_af.func_187214_a(SPELL_BLOCK, Optional.absent());
/*     */     
/*  79 */     registerAIFilter("cast_earth_reform", CAST_EARTH_REFORM);
/*  80 */     registerAIFilter("cast_growth_crops", CAST_GROWTH_CROPS);
/*  81 */     registerAIFilter("cast_growth_trees", CAST_GROWTH_TREES);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void randomizeGoals() {
/*  86 */     super.randomizeGoals();
/*  87 */     this.growthFirst = func_70681_au().nextBoolean();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addVillagerPosition() {}
/*     */ 
/*     */   
/*     */   public BlockPos getSpellBlock() {
/*  95 */     return (BlockPos)((Optional)this.field_70180_af.func_187225_a(SPELL_BLOCK)).orNull();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSpellBlock(BlockPos castingPos) {
/* 100 */     if (castingPos == null) {
/* 101 */       this.field_70180_af.func_187227_b(SPELL_BLOCK, Optional.absent());
/*     */     } else {
/* 103 */       this.field_70180_af.func_187227_b(SPELL_BLOCK, Optional.of(castingPos));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setCastingEarthReform(BlockPos pos) {
/* 108 */     func_184212_Q().func_187227_b(SPELL_EARTH_REFORM, Optional.fromNullable(pos));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BlockPos getCastingEarthReform() {
/* 114 */     return (BlockPos)((Optional)func_184212_Q().func_187225_a(SPELL_EARTH_REFORM)).orNull();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70636_d() {
/* 120 */     super.func_70636_d();
/*     */     
/* 122 */     if (this.field_70170_p.field_72995_K && !isSleeping()) {
/* 123 */       this.clientSpellBlock = getSpellBlock();
/* 124 */       if (this.clientSpellBlock != null) {
/* 125 */         this.growthTicks++;
/* 126 */         int range = getGrowthRange();
/*     */         
/* 128 */         spawnRadialParticle(func_174791_d(), range, (this.growthTicks * 3), 4, EnumParticleTypes.TOTEM);
/*     */         
/* 130 */         int particles = (this.growthTicks > 40) ? 7 : 1;
/* 131 */         for (int i = 0; i < particles; i++) {
/* 132 */           this.field_70170_p.func_175688_a(EnumParticleTypes.TOTEM, this.clientSpellBlock
/* 133 */               .func_177958_n() + 0.5D + func_70681_au().nextGaussian() * range, this.clientSpellBlock
/* 134 */               .func_177956_o() + 0.5D, this.clientSpellBlock
/* 135 */               .func_177952_p() + 0.5D + func_70681_au().nextGaussian() * range, 
/* 136 */               func_70681_au().nextGaussian() * 0.1D, this.field_70146_Z.nextFloat(), func_70681_au().nextGaussian() * 0.1D, new int[0]);
/*     */         }
/*     */       } else {
/*     */         
/* 140 */         this.growthTicks = 0;
/*     */       } 
/*     */       
/* 143 */       BlockPos earthPos = getCastingEarthReform();
/* 144 */       if (earthPos != null) {
/* 145 */         this.earthReformTicks++;
/* 146 */         if (this.earthReformTicks < 44) {
/* 147 */           int count = this.earthReformTicks / 3 + 1;
/* 148 */           for (int i = 0; i < count; i++) {
/* 149 */             double dx = func_70681_au().nextGaussian();
/* 150 */             double dz = func_70681_au().nextGaussian();
/* 151 */             double dy = func_70681_au().nextGaussian();
/* 152 */             if (i > 0) {
/* 153 */               this.field_70170_p.func_175688_a(EnumParticleTypes.BLOCK_DUST, this.field_70165_t + dx, this.field_70163_u + dy, this.field_70161_v + dz, 0.0D, func_70681_au().nextFloat() * 0.5D, 0.0D, new int[] { blockStateIds[func_70681_au().nextInt(blockStateIds.length)] });
/*     */             } else {
/* 155 */               this.field_70170_p.func_175688_a(EnumParticleTypes.TOTEM, this.field_70165_t + dx, this.field_70163_u + dy, this.field_70161_v + dz, 0.0D, func_70681_au().nextFloat() * 0.5D, 0.0D, new int[] { blockStateIds[func_70681_au().nextInt(blockStateIds.length)] });
/*     */             } 
/*     */           } 
/* 158 */         } else if (this.earthReformTicks < 55) {
/* 159 */           Vec3d vec = new Vec3d(earthPos.func_177958_n(), earthPos.func_177956_o(), earthPos.func_177952_p());
/* 160 */           vec = vec.func_178788_d(func_174791_d()).func_72432_b().func_186678_a(0.8D);
/*     */           
/* 162 */           for (int i = 0; i < 3; i++) {
/* 163 */             double dx = func_70681_au().nextGaussian() * 0.1D;
/* 164 */             double dy = func_70681_au().nextGaussian() * 0.1D;
/* 165 */             double dz = func_70681_au().nextGaussian() * 0.1D;
/* 166 */             this.field_70170_p.func_175688_a(EnumParticleTypes.TOTEM, this.field_70165_t + dx + vec.field_72450_a, this.field_70163_u + 1.3D + dy, this.field_70161_v + dz + vec.field_72449_c, vec.field_72450_a * 4.0D, 0.0D, vec.field_72449_c * 4.0D, new int[0]);
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 171 */         this.earthReformTicks = 0;
/*     */         
/* 173 */         if (func_70681_au().nextInt(10) == 0) {
/* 174 */           double dx = func_70681_au().nextGaussian() * 0.3D;
/* 175 */           double dz = func_70681_au().nextGaussian() * 0.3D;
/* 176 */           double dy = func_70681_au().nextFloat() * 0.5D;
/* 177 */           this.field_70170_p.func_175688_a(EnumParticleTypes.TOTEM, this.field_70165_t + dx, this.field_70163_u + dy + 0.2D, this.field_70161_v + dz, 0.0D, func_70681_au().nextFloat() * 0.25D, 0.0D, new int[] { blockStateIds[func_70681_au().nextInt(blockStateIds.length)] });
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void spawnRadialParticle(Vec3d pos, double radius, float angle, int count, EnumParticleTypes type) {
/* 186 */     for (int i = 0; i < count; i++) {
/* 187 */       this.field_70170_p.func_175688_a(type, pos.field_72450_a + 
/* 188 */           MathHelper.func_76134_b(angle + i) * radius, pos.field_72448_b + 0.5D, pos.field_72449_c + 
/*     */           
/* 190 */           MathHelper.func_76126_a(angle + i) * radius, 0.0D, this.field_70146_Z
/* 191 */           .nextFloat() * 0.2D, 0.0D, new int[0]);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getGrowthRange() {
/* 196 */     int range = MathHelper.func_76125_a(func_70681_au().nextInt(getSkill(ProfessionType.DRUID)) / 30, 0, 2);
/* 197 */     return range;
/*     */   }
/*     */   
/*     */   public boolean isGrowTime() {
/* 201 */     if (!isAIFilterEnabled("cast_earth_reform")) {
/* 202 */       return Village.isTimeOfDay(this.field_70170_p, 0L, 13000L);
/*     */     }
/* 204 */     if (this.growthFirst) {
/* 205 */       return Village.isTimeOfDay(this.field_70170_p, 0L, 6000L);
/*     */     }
/* 207 */     return Village.isTimeOfDay(this.field_70170_p, 6000L, 13000L);
/*     */   }
/*     */   
/*     */   public boolean isEarthReformTime() {
/* 211 */     if (!isAIFilterEnabled("cast_growth_trees") && !isAIFilterEnabled("cast_growth_crops")) {
/* 212 */       return Village.isTimeOfDay(this.field_70170_p, 0L, 13000L);
/*     */     }
/* 214 */     if (this.growthFirst) {
/* 215 */       return Village.isTimeOfDay(this.field_70170_p, 6000L, 13000L);
/*     */     }
/* 217 */     return Village.isTimeOfDay(this.field_70170_p, 0L, 6000L);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityDruid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */