/*     */ package net.tangotek.tektopia.entities;
/*     */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.IEntityLivingData;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemTool;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.SoundEvent;
/*     */ import net.minecraft.world.DifficultyInstance;
/*     */ import net.minecraft.world.World;
/*     */ import net.tangotek.tektopia.EntityTagType;
/*     */ import net.tangotek.tektopia.ItemTagType;
/*     */ import net.tangotek.tektopia.ModItems;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.TekVillager;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAIAttachLeadToButcherAnimal;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAICraftItems;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAILeadAnimalToStructure;
/*     */ import net.tangotek.tektopia.entities.crafting.Recipe;
/*     */ import net.tangotek.tektopia.structures.VillageStructureType;
/*     */ 
/*     */ public class EntityButcher extends EntityVillagerTek {
/*  39 */   protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityButcher.class);
/*  40 */   private static final DataParameter<Boolean> RETRIEVE_CHICKENS = EntityDataManager.func_187226_a(EntityButcher.class, DataSerializers.field_187198_h);
/*  41 */   private static final DataParameter<Boolean> RETRIEVE_COWS = EntityDataManager.func_187226_a(EntityButcher.class, DataSerializers.field_187198_h);
/*  42 */   private static final DataParameter<Boolean> RETRIEVE_PIGS = EntityDataManager.func_187226_a(EntityButcher.class, DataSerializers.field_187198_h);
/*  43 */   private static final DataParameter<Boolean> RETRIEVE_SHEEP = EntityDataManager.func_187226_a(EntityButcher.class, DataSerializers.field_187198_h);
/*  44 */   private static final DataParameter<Boolean> BUTCHER_ANIMALS = EntityDataManager.func_187226_a(EntityButcher.class, DataSerializers.field_187198_h);
/*  45 */   private static List<Recipe> craftSet = buildCraftSet();
/*     */   
/*     */   static {
/*  48 */     animHandler.addAnim("tektopia", "villager_take", "butcher_m", false);
/*  49 */     animHandler.addAnim("tektopia", "villager_chop", "butcher_m", false);
/*  50 */     animHandler.addAnim("tektopia", "villager_craft", "butcher_m", false);
/*  51 */     EntityVillagerTek.setupAnimations(animHandler, "butcher_m");
/*     */   }
/*     */   
/*  54 */   private static final Map<String, DataParameter<Boolean>> RECIPE_PARAMS = new HashMap<>();
/*     */   static {
/*  56 */     craftSet.forEach(r -> (DataParameter)RECIPE_PARAMS.put(r.getAiFilter(), EntityDataManager.func_187226_a(EntityButcher.class, DataSerializers.field_187198_h)));
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityButcher(World worldIn) {
/*  61 */     super(worldIn, ProfessionType.BUTCHER, VillagerRole.VILLAGER.value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AnimationHandler getAnimationHandler() {
/*  67 */     return animHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_110147_ax() {
/*  72 */     super.func_110147_ax();
/*  73 */     func_110140_aT().func_111150_b(SharedMonsterAttributes.field_111264_e).func_111128_a(5.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_70088_a() {
/*  78 */     super.func_70088_a();
/*  79 */     craftSet.forEach(r -> registerAIFilter(r.getAiFilter(), RECIPE_PARAMS.get(r.getAiFilter())));
/*  80 */     registerAIFilter("retrieve_chickens", RETRIEVE_CHICKENS);
/*  81 */     registerAIFilter("retrieve_cows", RETRIEVE_COWS);
/*  82 */     registerAIFilter("retrieve_pigs", RETRIEVE_PIGS);
/*  83 */     registerAIFilter("retrieve_sheep", RETRIEVE_SHEEP);
/*  84 */     registerAIFilter("butcher_animals", BUTCHER_ANIMALS);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_184651_r() {
/*  89 */     super.func_184651_r();
/*     */     
/*  91 */     getDesireSet().addItemDesire((ItemDesire)new UpgradeItemDesire("Axe", getBestAxe(), 1, 1, 1, p -> p.isWorkTime()));
/*  92 */     craftSet.forEach(r -> getDesireSet().addRecipeDesire(r));
/*     */     
/*  94 */     Runnable onHit = () -> {
/*     */         tryAddSkill(ProfessionType.BUTCHER, 8);
/*     */         
/*     */         modifyHunger(-5);
/*     */       };
/*  99 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIMeleeTarget(this, p -> getWeapon(this), EntityVillagerTek.VillagerThought.AXE, p -> (p.isWorkTime() && p.isAIFilterEnabled("butcher_animals")), onHit, ProfessionType.BUTCHER));
/* 100 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAILeadAnimalToStructure(this, VillageStructureType.BUTCHER, EntityTagType.BUTCHERED));
/* 101 */     this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAIAttachLeadToButcherAnimal(this, p -> p.isWorkTime()));
/* 102 */     this; this.field_70714_bg.func_75776_a(50, (EntityAIBase)new EntityAICraftItems(this, craftSet, "villager_craft", null, 80, VillageStructureType.BUTCHER, Blocks.field_150462_ai, p -> p.isWorkTime()));
/*     */     
/* 104 */     this.field_70715_bh.func_75776_a(1, (EntityAIBase)new EntityAIKillInStructure(this, VillageStructureType.BUTCHER, EntityAnimal.class, isTarget(), p -> p.isWorkTime()));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public IEntityLivingData func_180482_a(DifficultyInstance difficulty, @Nullable IEntityLivingData livingdata) {
/* 110 */     getInventory().func_174894_a(ModItems.makeTaggedItem(new ItemStack(Items.field_151053_p), ItemTagType.VILLAGER));
/*     */     
/* 112 */     return super.func_180482_a(difficulty, livingdata);
/*     */   }
/*     */   
/*     */   public static Predicate<EntityLivingBase> isTarget() {
/* 116 */     return p -> (p instanceof net.minecraft.entity.passive.EntitySheep || p instanceof net.minecraft.entity.passive.EntityCow || p instanceof net.minecraft.entity.passive.EntityChicken || p instanceof net.minecraft.entity.passive.EntityPig);
/*     */   }
/*     */   
/*     */   public static Function<ItemStack, Integer> getBestAxe() {
/* 120 */     return p -> {
/*     */         if (p.func_77973_b() instanceof net.minecraft.item.ItemAxe) {
/*     */           int score = p.func_77958_k() * 10;
/*     */           if (ModItems.isTaggedItem(p, ItemTagType.VILLAGER)) {
/*     */             score++;
/*     */           }
/*     */           return Integer.valueOf(score);
/*     */         } 
/*     */         return Integer.valueOf(-1);
/*     */       };
/*     */   }
/*     */   
/*     */   private static List<Recipe> buildCraftSet() {
/* 133 */     List<Recipe> recipes = new ArrayList<>();
/*     */ 
/*     */     
/* 136 */     List<ItemStack> ingredients = new ArrayList<>();
/* 137 */     ingredients.add(new ItemStack(Item.func_150898_a(Blocks.field_150364_r), 1, 99));
/* 138 */     Recipe recipe = new Recipe(ProfessionType.BUTCHER, "craft_wooden_axe", 3, new ItemStack(Items.field_151053_p, 1), ingredients, 1, 1, v -> Integer.valueOf(12 - v.getSkillLerp(ProfessionType.BUTCHER, 1, 10)), 1, p -> getWeapon(p).func_190926_b())
/*     */       {
/*     */         public ItemStack craft(EntityVillagerTek villager) {
/* 141 */           ItemStack result = super.craft(villager);
/* 142 */           villager.modifyHappy(-5);
/* 143 */           return result;
/*     */         }
/*     */       };
/* 146 */     recipes.add(recipe);
/*     */ 
/*     */     
/* 149 */     ingredients = new ArrayList<>();
/* 150 */     ingredients.add(new ItemStack(Items.field_151116_aA, 8));
/* 151 */     recipe = new Recipe(ProfessionType.BUTCHER, "craft_leather_chestplate", 2, new ItemStack((Item)Items.field_151027_R, 1), ingredients, 1, 1, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.BUTCHER, 8, 4)), 1);
/* 152 */     recipes.add(recipe);
/*     */ 
/*     */     
/* 155 */     ingredients = new ArrayList<>();
/* 156 */     ingredients.add(new ItemStack(Items.field_151116_aA, 7));
/* 157 */     recipe = new Recipe(ProfessionType.BUTCHER, "craft_leather_leggings", 2, new ItemStack((Item)Items.field_151026_S, 1), ingredients, 1, 1, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.BUTCHER, 7, 3)), 1);
/* 158 */     recipes.add(recipe);
/*     */ 
/*     */     
/* 161 */     ingredients = new ArrayList<>();
/* 162 */     ingredients.add(new ItemStack(Items.field_151116_aA, 4));
/* 163 */     recipe = new Recipe(ProfessionType.BUTCHER, "craft_leather_boots", 3, new ItemStack((Item)Items.field_151021_T, 1), ingredients, 1, 1, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.BUTCHER, 4, 2)), 1);
/* 164 */     recipes.add(recipe);
/*     */ 
/*     */     
/* 167 */     ingredients = new ArrayList<>();
/* 168 */     ingredients.add(new ItemStack(Items.field_151116_aA, 5));
/* 169 */     recipe = new Recipe(ProfessionType.BUTCHER, "craft_leather_helmet", 3, new ItemStack((Item)Items.field_151024_Q, 1), ingredients, 1, 1, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.BUTCHER, 5, 3)), 1);
/* 170 */     recipes.add(recipe);
/*     */ 
/*     */     
/* 173 */     return recipes;
/*     */   }
/*     */   
/*     */   private static int getToolBonusValue(ItemTool tool) {
/* 177 */     if (tool != null) {
/* 178 */       if (tool.func_77861_e().equals("STONE"))
/* 179 */         return 10; 
/* 180 */       if (tool.func_77861_e().equals("IRON"))
/* 181 */         return 30; 
/* 182 */       if (tool.func_77861_e().equals("DIAMOND")) {
/* 183 */         return 45;
/*     */       }
/*     */     } 
/*     */     
/* 187 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70074_a(EntityLivingBase entityLivingIn) {
/* 193 */     int bonusMeat = 0;
/* 194 */     int extraChance = getSkill(ProfessionType.BUTCHER);
/* 195 */     ItemStack tool = getWeapon(this);
/* 196 */     if (!tool.func_190926_b()) {
/* 197 */       extraChance += getToolBonusValue((ItemTool)tool.func_77973_b());
/*     */     }
/* 199 */     if (func_70681_au().nextInt(100) < extraChance) {
/* 200 */       bonusMeat++;
/*     */     }
/* 202 */     if (func_70681_au().nextInt(100) < extraChance) {
/* 203 */       bonusMeat++;
/*     */     }
/*     */     
/* 206 */     Item meat = null;
/* 207 */     SoundEvent soundEvent = null;
/* 208 */     if (entityLivingIn instanceof net.minecraft.entity.passive.EntityCow) {
/* 209 */       meat = Items.field_151082_bd;
/* 210 */       soundEvent = SoundEvents.field_187560_al;
/*     */     }
/* 212 */     else if (entityLivingIn instanceof net.minecraft.entity.passive.EntityPig) {
/* 213 */       meat = Items.field_151147_al;
/* 214 */       soundEvent = SoundEvents.field_187700_dM;
/*     */     }
/* 216 */     else if (entityLivingIn instanceof net.minecraft.entity.passive.EntitySheep) {
/* 217 */       meat = Items.field_179561_bm;
/* 218 */       soundEvent = SoundEvents.field_187759_eH;
/*     */     }
/* 220 */     else if (entityLivingIn instanceof net.minecraft.entity.passive.EntityChicken) {
/* 221 */       meat = Items.field_151076_bf;
/* 222 */       soundEvent = SoundEvents.field_187663_X;
/*     */     } 
/*     */     
/* 225 */     if (soundEvent != null) {
/* 226 */       func_184185_a(soundEvent, 2.0F, func_70647_i());
/*     */     }
/*     */     
/* 229 */     if (bonusMeat > 0 && this.field_70170_p.func_82736_K().func_82766_b("doMobLoot")) {
/* 230 */       ItemStack meatStack = new ItemStack(meat, bonusMeat);
/* 231 */       if (ModEntities.isTaggedEntity((Entity)entityLivingIn, EntityTagType.VILLAGER)) {
/* 232 */         ModItems.makeTaggedItem(meatStack, ItemTagType.VILLAGER);
/*     */       }
/* 234 */       entityLivingIn.func_70099_a(meatStack, bonusMeat);
/*     */     } 
/*     */     
/* 237 */     super.func_70074_a(entityLivingIn);
/*     */   }
/*     */   
/*     */   public static ItemStack getWeapon(EntityVillagerTek villager) {
/* 241 */     List<ItemStack> weaponList = villager.getInventory().getItems(getBestAxe(), 1);
/* 242 */     if (!weaponList.isEmpty()) {
/* 243 */       return weaponList.get(0);
/*     */     }
/* 245 */     return ItemStack.field_190927_a;
/*     */   }
/*     */   
/*     */   public Predicate<ItemStack> isMeat() {
/* 249 */     return p -> (p.func_77973_b() == Items.field_151082_bd || p.func_77973_b() == Items.field_151147_al || p.func_77973_b() == Items.field_179561_bm || p.func_77973_b() == Items.field_151076_bf);
/*     */   }
/*     */   
/*     */   public Predicate<ItemStack> isAnimalProduct() {
/* 253 */     return p -> (p.func_77973_b() == Items.field_151008_G || p.func_77973_b() == Item.func_150898_a(Blocks.field_150325_L) || p.func_77973_b() == Items.field_151110_aK || p.func_77973_b() == Items.field_151116_aA);
/*     */   }
/*     */   
/*     */   public Predicate<ItemStack> isHarvestItem() {
/* 257 */     return p -> (isMeat().test(p) || isAnimalProduct().test(p));
/*     */   }
/*     */   
/*     */   public boolean func_70652_k(Entity entityIn) {
/* 261 */     float damage = (float)func_110148_a(SharedMonsterAttributes.field_111264_e).func_111126_e();
/* 262 */     boolean flag = entityIn.func_70097_a(DamageSource.func_76358_a((EntityLivingBase)this), damage);
/* 263 */     return flag;
/*     */   }
/*     */   
/*     */   protected boolean canVillagerPickupItem(ItemStack itemIn) {
/* 267 */     return (isHarvestItem().test(itemIn) || super.canVillagerPickupItem(itemIn));
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityButcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */