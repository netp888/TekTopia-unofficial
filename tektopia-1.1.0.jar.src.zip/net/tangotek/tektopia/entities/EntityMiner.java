/*     */ package net.tangotek.tektopia.entities;
/*     */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.IEntityLivingData;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.item.EnumDyeColor;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.util.SoundCategory;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.DifficultyInstance;
/*     */ import net.minecraft.world.World;
/*     */ import net.tangotek.tektopia.ItemTagType;
/*     */ import net.tangotek.tektopia.ModItems;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAICraftItems;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAIMining;
/*     */ import net.tangotek.tektopia.entities.crafting.Recipe;
/*     */ import net.tangotek.tektopia.storage.ItemDesire;
/*     */ import net.tangotek.tektopia.structures.VillageStructure;
/*     */ import net.tangotek.tektopia.structures.VillageStructureType;
/*     */ 
/*     */ public class EntityMiner extends EntityVillagerTek {
/*  37 */   protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityMiner.class);
/*     */   
/*  39 */   private static final DataParameter<Boolean> SMELT_CHARCOAL = EntityDataManager.func_187226_a(EntityMiner.class, DataSerializers.field_187198_h);
/*  40 */   private static final DataParameter<Boolean> MINING = EntityDataManager.func_187226_a(EntityMiner.class, DataSerializers.field_187198_h);
/*     */   
/*  42 */   private static List<Recipe> craftSet = buildCraftSet();
/*     */   
/*     */   private boolean isUnderground = false;
/*     */   
/*     */   static {
/*  47 */     animHandler.addAnim("tektopia", "villager_chop", "miner_m", true);
/*  48 */     animHandler.addAnim("tektopia", "villager_craft", "miner_m", true);
/*  49 */     EntityVillagerTek.setupAnimations(animHandler, "miner_m");
/*     */   }
/*     */   
/*  52 */   private static final Map<String, DataParameter<Boolean>> RECIPE_PARAMS = new HashMap<>();
/*     */   static {
/*  54 */     craftSet.forEach(r -> (DataParameter)RECIPE_PARAMS.put(r.getAiFilter(), EntityDataManager.func_187226_a(EntityMiner.class, DataSerializers.field_187198_h)));
/*     */   }
/*     */   
/*     */   public EntityMiner(World worldIn) {
/*  58 */     super(worldIn, ProfessionType.MINER, VillagerRole.VILLAGER.value);
/*  59 */     addAnimationTrigger("tektopia:villager_chop", 47, new Runnable()
/*     */         {
/*     */           public void run() {
/*  62 */             EntityMiner.this.field_70170_p.func_184134_a(EntityMiner.this.field_70165_t, EntityMiner.this.field_70163_u, EntityMiner.this.field_70161_v, SoundEvents.field_187843_fX, SoundCategory.BLOCKS, 1.0F, EntityMiner.this.field_70146_Z.nextFloat() * 0.4F + 0.8F, false);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public AnimationHandler getAnimationHandler() {
/*  68 */     return animHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setupServerJobs() {
/*  73 */     super.setupServerJobs();
/*  74 */     addJob(new TickJob(20, 20, true, () -> updateUnderground()));
/*     */   }
/*     */   
/*     */   protected void func_70088_a() {
/*  78 */     super.func_70088_a();
/*  79 */     craftSet.forEach(r -> registerAIFilter(r.getAiFilter(), RECIPE_PARAMS.get(r.getAiFilter())));
/*  80 */     registerAIFilter("smelt_charcoal", SMELT_CHARCOAL);
/*  81 */     registerAIFilter("mining", MINING);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_184651_r() {
/*  86 */     super.func_184651_r();
/*     */     
/*  88 */     VillageStructureType[] smeltBuildings = { VillageStructureType.BLACKSMITH, VillageStructureType.STORAGE };
/*     */     
/*  90 */     Predicate<ItemStack> isLapis = p -> (p.func_77973_b() == Items.field_151100_aR && p.func_77960_j() == EnumDyeColor.BLUE.func_176767_b());
/*     */     
/*  92 */     getDesireSet().addItemDesire(new ItemDesire(Blocks.field_150478_aa, 10, 20, 30, null));
/*  93 */     getDesireSet().addItemDesire(new ItemDesire(Blocks.field_150364_r, 0, 3, 10, p -> (!hasTorches(p, 10) && p.isAIFilterEnabled("smelt_charcoal"))));
/*  94 */     getDesireSet().addItemDesire((ItemDesire)new UpgradeItemDesire("Pick", getBestPick(this), 1, 1, 1, p -> p.isWorkTime()));
/*  95 */     getDesireSet().addItemDesire(new ItemDesire(Items.field_151045_i, 0, 0, 5, null));
/*  96 */     getDesireSet().addItemDesire(new ItemDesire(Blocks.field_150366_p, 0, 0, 8, null));
/*  97 */     getDesireSet().addItemDesire(new ItemDesire(Blocks.field_150352_o, 0, 0, 8, null));
/*  98 */     getDesireSet().addItemDesire(new ItemDesire(Items.field_151137_ax, 0, 0, 16, null));
/*  99 */     getDesireSet().addItemDesire(new ItemDesire("Lapis", isLapis, 0, 0, 16, null));
/* 100 */     craftSet.forEach(r -> getDesireSet().addRecipeDesire(r));
/*     */     
/* 102 */     this; addTask(50, (EntityAIBase)new EntityAICraftItems(this, craftSet, "villager_craft", null, 80, VillageStructureType.STORAGE, Blocks.field_150462_ai, p -> p.isWorkTime()));
/* 103 */     addTask(50, (EntityAIBase)new EntityAIEmptyFurnace(this, smeltBuildings, isSmeltProduct(), p -> !hasCoal(p, 8)));
/* 104 */     addTask(50, (EntityAIBase)new EntityAISmelting(this, smeltBuildings, p -> (!hasTorches(p, 10) && !hasCoal(p, 8) && p.isAIFilterEnabled("smelt_charcoal")), bestSmeltable(), () -> tryAddSkill(ProfessionType.MINER, 7)));
/* 105 */     addTask(50, (EntityAIBase)new EntityAIMining(this, p -> p.isWorkTime()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDeliveryTime() {
/* 111 */     return (Village.isTimeOfDay(this.field_70170_p, (WORK_START_TIME - 2000), WORK_END_TIME, this.sleepOffset) && !this.field_70170_p.func_72896_J());
/*     */   }
/*     */   
/*     */   private static List<Recipe> buildCraftSet() {
/* 115 */     List<Recipe> recipes = new ArrayList<>();
/*     */ 
/*     */     
/* 118 */     List<ItemStack> ingredients = new ArrayList<>();
/* 119 */     ingredients.add(new ItemStack(Item.func_150898_a(Blocks.field_150364_r), 1, 99));
/* 120 */     Recipe recipe = new Recipe(ProfessionType.MINER, "craft_wooden_pickaxe", 3, new ItemStack(Items.field_151039_o, 1), ingredients, 1, 1, v -> Integer.valueOf(v.getSkillLerp(ProfessionType.MINER, 11, 2)), 1, v -> !hasPick(v))
/*     */       {
/*     */         public ItemStack craft(EntityVillagerTek villager) {
/* 123 */           ItemStack result = super.craft(villager);
/* 124 */           villager.modifyHappy(-5);
/* 125 */           return result;
/*     */         }
/*     */       };
/* 128 */     recipes.add(recipe);
/*     */ 
/*     */ 
/*     */     
/* 132 */     ingredients = new ArrayList<>();
/* 133 */     ingredients.add(new ItemStack(Item.func_150898_a(Blocks.field_150364_r), 1, 99));
/* 134 */     ingredients.add(new ItemStack(Items.field_151044_h, 8));
/* 135 */     recipe = new Recipe(ProfessionType.MINER, "craft_charcoal_torch", 7, new ItemStack(Item.func_150898_a(Blocks.field_150478_aa), 32), ingredients, 1, 1, v -> Integer.valueOf(8 - v.getSkillLerp(ProfessionType.MINER, 1, 6)), 64, v -> !hasTorches(v, 10));
/* 136 */     recipes.add(recipe);
/*     */ 
/*     */ 
/*     */     
/* 140 */     ingredients = new ArrayList<>();
/* 141 */     ingredients.add(new ItemStack(Item.func_150898_a(Blocks.field_150364_r), 1, 99));
/* 142 */     ingredients.add(new ItemStack(Items.field_151044_h, 8, 1));
/* 143 */     recipe = new Recipe(ProfessionType.MINER, "craft_coal_torch", 7, new ItemStack(Item.func_150898_a(Blocks.field_150478_aa), 32), ingredients, 1, 1, v -> Integer.valueOf(8 - v.getSkillLerp(ProfessionType.MINER, 1, 6)), 64, v -> !hasTorches(v, 10));
/* 144 */     recipes.add(recipe);
/*     */     
/* 146 */     return recipes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public IEntityLivingData func_180482_a(DifficultyInstance difficulty, @Nullable IEntityLivingData livingdata) {
/* 153 */     getInventory().func_174894_a(ModItems.createTaggedItem(Items.field_151039_o, ItemTagType.VILLAGER));
/* 154 */     getInventory().func_174894_a(ModItems.createTaggedItem(Item.func_150898_a(Blocks.field_150478_aa), 16, ItemTagType.VILLAGER));
/* 155 */     return super.func_180482_a(difficulty, livingdata);
/*     */   }
/*     */   
/*     */   protected void updateUnderground() {
/* 159 */     BlockPos pos = func_180425_c();
/* 160 */     this.isUnderground = (pos.func_177956_o() < 62 && !this.field_70170_p.func_175678_i(pos));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_82167_n(Entity entityIn) {
/* 166 */     if (entityIn instanceof EntityVillagerTek && 
/* 167 */       hasVillage()) {
/* 168 */       VillageStructure struct = getVillage().getStructure(func_180425_c());
/* 169 */       if (struct != null && struct.type == VillageStructureType.MINESHAFT) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 174 */     super.func_82167_n(entityIn);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addVillagerPosition() {}
/*     */ 
/*     */   
/*     */   protected boolean canVillagerPickupItem(ItemStack itemIn) {
/* 182 */     return isHarvestItem().test(itemIn);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static boolean hasTorches(EntityVillagerTek villager, int req) {
/* 187 */     int count = villager.getInventory().getItemCount(isTorch());
/* 188 */     return (count >= req);
/*     */   }
/*     */   
/*     */   protected static boolean hasCoal(EntityVillagerTek villager, int req) {
/* 192 */     int count = villager.getInventory().getItemCount(isCoal());
/* 193 */     return (count >= req);
/*     */   }
/*     */   
/*     */   protected static boolean hasPick(EntityVillagerTek villager) {
/* 197 */     List<ItemStack> weaponList = villager.getInventory().getItems(getBestPick(villager), 1);
/* 198 */     return !weaponList.isEmpty();
/*     */   }
/*     */   
/* 201 */   public static Predicate<ItemStack> isCoal() { return p -> (p.func_77973_b() == Items.field_151044_h); } public static Predicate<ItemStack> isTorch() {
/* 202 */     return p -> (p.func_77973_b() == Item.func_150898_a(Blocks.field_150478_aa));
/*     */   }
/*     */   public static Function<ItemStack, Integer> getBestPick(EntityVillagerTek villager) {
/* 205 */     return p -> (p.func_77973_b() instanceof net.minecraft.item.ItemPickaxe) ? Integer.valueOf(50 - EntityAIMining.getSwingCount(villager, p)) : Integer.valueOf(-1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float func_70689_ay() {
/* 216 */     float speed = super.func_70689_ay();
/*     */     
/* 218 */     if (this.isUnderground) {
/* 219 */       speed *= getSkillLerp(ProfessionType.MINER, 100, 140) / 100.0F;
/*     */     }
/* 221 */     return speed;
/*     */   }
/*     */   
/*     */   public Predicate<ItemStack> isHarvestItem() {
/* 225 */     return p -> (p.func_77973_b() == Item.func_150898_a(Blocks.field_150366_p) || p.func_77973_b() == Items.field_151044_h || p.func_77973_b() == Items.field_151100_aR || p.func_77973_b() == Items.field_151045_i || p.func_77973_b() == Items.field_151137_ax || p.func_77973_b() == Item.func_150898_a(Blocks.field_150352_o) || p.func_77973_b() == Items.field_151166_bC || super.isHarvestItem().test(p));
/*     */   }
/*     */   
/*     */   private static Predicate<ItemStack> isSmeltProduct() {
/* 229 */     return p -> (p.func_77973_b() == Items.field_151044_h);
/*     */   }
/*     */   
/*     */   private static Function<ItemStack, Integer> bestSmeltable() {
/* 233 */     return p -> Integer.valueOf((p.func_77973_b() == Item.func_150898_a(Blocks.field_150364_r)) ? 1 : 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityMiner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */