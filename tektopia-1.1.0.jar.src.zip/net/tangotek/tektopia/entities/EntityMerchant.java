/*     */ package net.tangotek.tektopia.entities;
/*     */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.ListIterator;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.IEntityLivingData;
/*     */ import net.minecraft.entity.IMerchant;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.passive.EntityAnimal;
/*     */ import net.minecraft.entity.passive.EntityChicken;
/*     */ import net.minecraft.entity.passive.EntityCow;
/*     */ import net.minecraft.entity.passive.EntityPig;
/*     */ import net.minecraft.entity.passive.EntitySheep;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.nbt.NBTTagString;
/*     */ import net.minecraft.pathfinding.PathNavigate;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentTranslation;
/*     */ import net.minecraft.village.MerchantRecipe;
/*     */ import net.minecraft.village.MerchantRecipeList;
/*     */ import net.minecraft.world.World;
/*     */ import net.tangotek.tektopia.Village;
/*     */ import net.tangotek.tektopia.VillagerRole;
/*     */ import net.tangotek.tektopia.caps.IVillageData;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAIGenericMove;
/*     */ import net.tangotek.tektopia.entities.ai.EntityAIVisitMerchantStall;
/*     */ import net.tangotek.tektopia.structures.VillageStructure;
/*     */ import net.tangotek.tektopia.tickjob.TickJob;
/*     */ 
/*     */ public class EntityMerchant extends EntityVillagerTek implements IMerchant {
/*  39 */   protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityMerchant.class);
/*     */   private BlockPos firstCheck;
/*  41 */   private int stallLevel = 0;
/*     */   
/*     */   @Nullable
/*     */   private EntityPlayer buyingPlayer;
/*     */   
/*     */   @Nullable
/*     */   private MerchantRecipeList merchantList;
/*     */   
/*  49 */   private List<EntityAnimal> animalDeliveries = new ArrayList<>();
/*     */   
/*     */   static {
/*  52 */     EntityVillagerTek.setupAnimations(animHandler, "merchant_m");
/*     */   }
/*     */   
/*     */   public EntityMerchant(World worldIn) {
/*  56 */     super(worldIn, (ProfessionType)null, VillagerRole.VENDOR.value | VillagerRole.VISITOR.value);
/*  57 */     this.sleepOffset = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setupServerJobs() {
/*  62 */     super.setupServerJobs();
/*  63 */     addJob(new TickJob(50, 50, true, () -> releashAnimals()));
/*  64 */     addJob(new TickJob(100, 0, false, () -> prepStuck()));
/*  65 */     addJob(new TickJob(400, 0, false, () -> checkStuck()));
/*     */ 
/*     */     
/*  68 */     addJob(new TickJob(50, 0, true, () -> { if (isSleepingTime())
/*  69 */               func_70106_y();  })); addJob(new TickJob(300, 100, true, () -> {
/*     */             if (!hasVillage() || !getVillage().isValid()) {
/*     */               debugOut("Killing Self.  No village");
/*     */               func_70106_y();
/*     */             } 
/*     */           }));
/*     */   }
/*     */   
/*     */   private void prepStuck() {
/*  78 */     this.firstCheck = func_190671_u_();
/*     */   }
/*     */   
/*     */   private void checkStuck() {
/*  82 */     if (this.firstCheck.func_177951_i((Vec3i)func_190671_u_()) < 20.0D) {
/*  83 */       debugOut("Merchant failed to find a way to the village.");
/*  84 */       func_70106_y();
/*     */     } 
/*     */   }
/*     */   
/*     */   public AnimationHandler getAnimationHandler() {
/*  89 */     return animHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_184651_r() {
/*  94 */     super.func_184651_r();
/*     */ 
/*     */     
/*  97 */     addTask(50, (EntityAIBase)new EntityAIGenericMove(this, p -> (p.hasVillage() && Village.isNightTime(this.field_70170_p)), v -> this.village.getEdgeNode(), EntityVillagerTek.MovementMode.WALK, null, () -> {
/*     */             debugOut("Killing Self.  Left the village");
/*     */             
/*     */             func_70106_y();
/*     */           }));
/* 102 */     addTask(50, (EntityAIBase)new EntityAIVisitMerchantStall(this, p -> hasVillage(), 3, 60));
/*     */     
/* 104 */     addTask(50, (EntityAIBase)new EntityAIGenericMove(this, p -> (!Village.isNightTime(this.field_70170_p) && p.hasVillage() && !isTrading()), v -> this.animalDeliveries.isEmpty() ? this.village.getLastVillagerPos() : getDeliveryPos(), EntityVillagerTek.MovementMode.WALK, null, () -> this.animalDeliveries.clear()));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initEntityAIBase() {}
/*     */ 
/*     */   
/*     */   public boolean canNavigate() {
/* 112 */     if (isTrading()) {
/* 113 */       return false;
/*     */     }
/* 115 */     return super.canNavigate();
/*     */   }
/*     */ 
/*     */   
/*     */   protected PathNavigate func_175447_b(World worldIn) {
/* 120 */     PathNavigate nav = super.func_175447_b(worldIn);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     return nav;
/*     */   }
/*     */ 
/*     */   
/*     */   public float func_70689_ay() {
/* 131 */     return super.func_70689_ay() * 0.9F;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70636_d() {
/* 136 */     super.func_70636_d();
/*     */     
/* 138 */     if (!this.field_70170_p.field_72995_K) {
/* 139 */       ListIterator<EntityAnimal> itr = this.animalDeliveries.listIterator();
/* 140 */       while (itr.hasNext()) {
/* 141 */         EntitySheep entitySheep; EntityAnimal animal = itr.next();
/* 142 */         if (!animal.func_70089_S()) {
/* 143 */           EntityCow entityCow; itr.remove();
/* 144 */           if (animal instanceof EntityCow)
/* 145 */           { entityCow = new EntityCow(this.field_70170_p); }
/* 146 */           else { EntityChicken entityChicken; if (entityCow instanceof EntityChicken) {
/* 147 */               entityChicken = new EntityChicken(this.field_70170_p);
/* 148 */             } else if (entityChicken instanceof EntitySheep) {
/* 149 */               entitySheep = new EntitySheep(this.field_70170_p);
/* 150 */             } else if (entitySheep instanceof EntityPig) {
/* 151 */               EntityPig entityPig = new EntityPig(this.field_70170_p);
/*     */             } else {
/* 153 */               entitySheep = null;
/*     */             }  }
/* 155 */            if (entitySheep != null) {
/* 156 */             itr.add(entitySheep);
/* 157 */             spawnAnimal((EntityAnimal)entitySheep);
/*     */           }  continue;
/* 159 */         }  if (entitySheep.func_110166_bE() == null) {
/* 160 */           teleportAnimal((EntityAnimal)entitySheep);
/* 161 */           entitySheep.func_110162_b((Entity)this, true); continue;
/* 162 */         }  if (entitySheep.func_110166_bE() != this) {
/*     */           
/* 164 */           itr.remove(); continue;
/* 165 */         }  if (entitySheep.func_70068_e((Entity)this) > 40.0D) {
/* 166 */           teleportAnimal((EntityAnimal)entitySheep);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addTask(int priority, EntityAIBase task) {
/* 175 */     if (task instanceof net.tangotek.tektopia.entities.ai.EntityAIWanderStructure && priority <= 100) {
/*     */       return;
/*     */     }
/* 178 */     if (task instanceof net.tangotek.tektopia.entities.ai.EntityAIReadBook) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     super.addTask(priority, task);
/*     */   }
/*     */ 
/*     */   
/*     */   private void releashAnimals() {
/* 192 */     for (EntityAnimal animal : this.animalDeliveries) {
/* 193 */       if (animal.func_70089_S()) {
/* 194 */         animal.func_110162_b(null, true);
/* 195 */         animal.func_110162_b((Entity)this, true);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMale() {
/* 202 */     return true;
/*     */   }
/*     */   
/*     */   private void teleportAnimal(EntityAnimal animal) {
/* 206 */     animal.func_70634_a(getX(), getY(), getZ());
/*     */   }
/*     */   
/*     */   public void addAnimalDelivery(EntityAnimal animal) {
/* 210 */     this.animalDeliveries.add(animal);
/* 211 */     spawnAnimal(animal);
/*     */   }
/*     */   
/*     */   private BlockPos getDeliveryPos() {
/* 215 */     if (this.animalDeliveries.size() > 0) {
/* 216 */       VillageStructure struct = EntityAIReturnLostAnimal.getDestinationStructure(getVillage(), this.animalDeliveries.get(0), func_180425_c());
/* 217 */       if (struct != null) {
/* 218 */         return struct.getDoorOutside();
/*     */       }
/*     */     } 
/* 221 */     return getVillage().getOrigin();
/*     */   }
/*     */   
/*     */   private void spawnAnimal(EntityAnimal animal) {
/* 225 */     animal.func_70012_b(getX() + 0.5D, getY(), getZ() + 0.5D, 0.0F, 0.0F);
/* 226 */     animal.func_180482_a(this.field_70170_p.func_175649_E(func_190671_u_()), (IEntityLivingData)null);
/* 227 */     this.field_70170_p.func_72838_d((Entity)animal);
/* 228 */     ModEntities.makeTaggedEntity((Entity)animal, EntityTagType.VILLAGER);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addVillagerPosition() {}
/*     */ 
/*     */   
/*     */   public void setStall(int level) {
/* 236 */     this.stallLevel = level;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70932_a_(@Nullable EntityPlayer player) {
/* 241 */     this.buyingPlayer = player;
/* 242 */     func_70661_as().func_75499_g();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public EntityPlayer func_70931_l_() {
/* 248 */     return this.buyingPlayer;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTrading() {
/* 253 */     return (this.buyingPlayer != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void bedCheck() {}
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public MerchantRecipeList func_70934_b(EntityPlayer player) {
/* 264 */     if (this.merchantList == null)
/*     */     {
/* 266 */       populateBuyingList(this.stallLevel);
/*     */     }
/*     */     
/* 269 */     return this.merchantList;
/*     */   }
/*     */   protected boolean getCanUseDoors() {
/* 272 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_184645_a(EntityPlayer player, EnumHand hand) {
/* 277 */     if (func_70089_S() && !isTrading() && !func_70631_g_() && !player.func_70093_af())
/*     */     {
/* 279 */       if (!this.field_70170_p.field_72995_K) {
/* 280 */         if (this.merchantList == null) {
/* 281 */           populateBuyingList(this.stallLevel);
/*     */         }
/*     */         
/* 284 */         if (this.merchantList != null && 
/* 285 */           !this.merchantList.isEmpty()) {
/* 286 */           func_70932_a_(player);
/* 287 */           player.func_180472_a(this);
/* 288 */           func_70661_as().func_75499_g();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 295 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void populateBuyingList(int stallLevel) {
/* 300 */     if (this.merchantList == null && hasVillage()) {
/*     */       
/* 302 */       IVillageData vd = getVillage().getTownData();
/* 303 */       if (vd != null) {
/* 304 */         vd.initEconomy();
/* 305 */         this.merchantList = vd.getEconomy().getMerchantList(getVillage(), stallLevel);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_70930_a(@Nullable MerchantRecipeList recipeList) {}
/*     */ 
/*     */   
/*     */   public World func_190670_t_() {
/* 317 */     return this.field_70170_p;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70933_a(MerchantRecipe recipe) {
/* 322 */     recipe.func_77399_f();
/* 323 */     this.field_70757_a = -func_70627_aG();
/* 324 */     func_184185_a(SoundEvents.field_187915_go, func_70599_aP(), func_70647_i());
/* 325 */     int i = 3 + this.field_70146_Z.nextInt(4);
/*     */     
/* 327 */     if (recipe.func_180321_e() == 1 || this.field_70146_Z.nextInt(5) == 0)
/*     */     {
/* 329 */       i += 5;
/*     */     }
/*     */     
/* 332 */     if (recipe.func_180322_j())
/*     */     {
/* 334 */       this.field_70170_p.func_72838_d((Entity)new EntityXPOrb(this.field_70170_p, this.field_70165_t, this.field_70163_u + 0.5D, this.field_70161_v, i));
/*     */     }
/*     */     
/* 337 */     if (hasVillage()) {
/* 338 */       getVillage().purchaseFromMerchant(recipe, this, func_70931_l_());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_110297_a_(ItemStack stack) {
/* 344 */     if (!this.field_70170_p.field_72995_K && this.field_70757_a > -func_70627_aG() + 20) {
/*     */       
/* 346 */       this.field_70757_a = -func_70627_aG();
/* 347 */       func_184185_a(stack.func_190926_b() ? SoundEvents.field_187913_gm : SoundEvents.field_187915_go, func_70599_aP(), func_70647_i());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ITextComponent func_145748_c_() {
/* 354 */     TextComponentTranslation textComponentTranslation = new TextComponentTranslation("entity.villager.merchant", new Object[0]);
/* 355 */     textComponentTranslation.func_150256_b().func_150209_a(func_174823_aP());
/* 356 */     textComponentTranslation.func_150256_b().func_179989_a(func_189512_bd());
/*     */ 
/*     */ 
/*     */     
/* 360 */     return (ITextComponent)textComponentTranslation;
/*     */   }
/*     */ 
/*     */   
/*     */   public Predicate<Entity> isHostile() {
/* 365 */     return e -> false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFleeFrom(Entity e) {
/* 370 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockPos func_190671_u_() {
/* 376 */     return new BlockPos((Entity)this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound compound) {
/* 382 */     super.func_70014_b(compound);
/*     */     
/* 384 */     NBTTagList nbttaglist = new NBTTagList();
/* 385 */     for (EntityAnimal animal : this.animalDeliveries) {
/* 386 */       nbttaglist.func_74742_a((NBTBase)new NBTTagString(animal.func_110124_au().toString()));
/*     */     }
/* 388 */     compound.func_74782_a("animals", (NBTBase)nbttaglist);
/*     */     
/* 390 */     if (this.merchantList != null)
/*     */     {
/* 392 */       compound.func_74782_a("Offers", (NBTBase)this.merchantList.func_77202_a());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound compound) {
/* 399 */     super.func_70037_a(compound);
/*     */     
/* 401 */     NBTTagList nbttaglist = compound.func_150295_c("animals", 10);
/* 402 */     for (int i = 0; i < nbttaglist.func_74745_c(); i++) {
/*     */       
/* 404 */       UUID uuid = UUID.fromString(nbttaglist.func_150307_f(i));
/* 405 */       for (EntityAnimal animal : this.field_70170_p.func_72872_a(EntityAnimal.class, func_174813_aQ().func_186662_g(12.0D))) {
/*     */         
/* 407 */         if (animal.func_110124_au().equals(uuid)) {
/*     */           
/* 409 */           this.animalDeliveries.add(animal);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 415 */     if (compound.func_150297_b("Offers", 10)) {
/*     */       
/* 417 */       NBTTagCompound nbttagcompound = compound.func_74775_l("Offers");
/* 418 */       this.merchantList = new MerchantRecipeList(nbttagcompound);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityMerchant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */