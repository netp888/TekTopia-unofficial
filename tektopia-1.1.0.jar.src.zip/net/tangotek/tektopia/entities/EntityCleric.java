/*     */ package net.tangotek.tektopia.entities;
/*     */ import com.leviathanstudio.craftstudio.common.animation.AnimationHandler;
/*     */ import java.util.Random;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.SoundCategory;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import net.tangotek.tektopia.ModSoundEvents;
/*     */ import net.tangotek.tektopia.Village;
/*     */ import net.tangotek.tektopia.VillagerRole;
/*     */ 
/*     */ public class EntityCleric extends EntityVillagerTek {
/*  18 */   protected static AnimationHandler animHandler = TekVillager.getNewAnimationHandler(EntityCleric.class);
/*     */   
/*  20 */   private static final DataParameter<Integer> SPELL_TARGET = EntityDataManager.func_187226_a(EntityCleric.class, DataSerializers.field_187192_b);
/*  21 */   private static final DataParameter<Boolean> CAST_BLESS = EntityDataManager.func_187226_a(EntityCleric.class, DataSerializers.field_187198_h);
/*  22 */   private static final DataParameter<Boolean> CAST_HEAL = EntityDataManager.func_187226_a(EntityCleric.class, DataSerializers.field_187198_h);
/*  23 */   private int handParticleTick = 0;
/*     */   
/*     */   static {
/*  26 */     animHandler.addAnim("tektopia", "villager_summon", "cleric_m", false);
/*  27 */     animHandler.addAnim("tektopia", "villager_cast_bless", "cleric_m", false);
/*  28 */     EntityVillagerTek.setupAnimations(animHandler, "cleric_m");
/*     */   }
/*     */   
/*     */   public EntityCleric(World worldIn) {
/*  32 */     super(worldIn, ProfessionType.CLERIC, VillagerRole.VILLAGER.value | VillagerRole.DEFENDER.value);
/*     */     
/*  34 */     Runnable enchantRunner = new Runnable()
/*     */       {
/*     */         public void run() {
/*  37 */           EntityCleric.this.field_70170_p.func_184134_a(EntityCleric.this.field_70165_t, EntityCleric.this.field_70163_u, EntityCleric.this.field_70161_v, ModSoundEvents.villagerEnchant, SoundCategory.NEUTRAL, 1.0F, EntityCleric.this.field_70146_Z.nextFloat() * 0.2F + 0.9F, false);
/*     */         }
/*     */       };
/*     */     
/*  41 */     if (this.field_70170_p.field_72995_K) {
/*  42 */       addAnimationTrigger("tektopia:villager_summon", 12, enchantRunner);
/*  43 */       addAnimationTrigger("tektopia:villager_summon", 20, new Runnable()
/*     */           {
/*     */             public void run() {
/*  46 */               EntityCleric.this.handParticleTick = 25;
/*     */             }
/*     */           });
/*  49 */       addAnimationTrigger("tektopia:villager_summon", 32, enchantRunner);
/*     */     } 
/*     */   }
/*     */   
/*     */   public AnimationHandler getAnimationHandler() {
/*  54 */     return animHandler;
/*     */   }
/*     */   
/*     */   protected void func_184651_r() {
/*  58 */     super.func_184651_r();
/*     */     
/*  60 */     addTask(49, (EntityAIBase)new EntityAIHeal(this, 16.0D));
/*  61 */     addTask(50, (EntityAIBase)new EntityAIBless(this, 12.0D));
/*  62 */     addTask(50, (EntityAIBase)new EntityAIPatrolVillage(this, p -> !p.isSleepingTime()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void attachToVillage(Village v) {
/*  67 */     super.attachToVillage(v);
/*  68 */     this.sleepOffset = v.getNextClericSleepOffset();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addTask(int priority, EntityAIBase task) {
/*  73 */     if (task instanceof net.tangotek.tektopia.entities.ai.EntityAIFleeEntity) {
/*     */       return;
/*     */     }
/*  76 */     super.addTask(priority, task);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_70088_a() {
/*  81 */     super.func_70088_a();
/*  82 */     this.field_70180_af.func_187214_a(SPELL_TARGET, Integer.valueOf(0));
/*     */     
/*  84 */     registerAIFilter("cast_bless", CAST_BLESS);
/*  85 */     registerAIFilter("cast_heal", CAST_HEAL);
/*     */   }
/*     */   
/*     */   public EntityVillagerTek.MovementMode getDefaultMovement() {
/*  89 */     if (this.village.enemySeenRecently()) {
/*  90 */       return EntityVillagerTek.MovementMode.RUN;
/*     */     }
/*  92 */     return super.getDefaultMovement();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSpellcasting() {
/*  97 */     int entityId = ((Integer)this.field_70180_af.func_187225_a(SPELL_TARGET)).intValue();
/*  98 */     return (entityId > 0);
/*     */   }
/*     */   
/*     */   public Entity getSpellTargetEntity() {
/* 102 */     int entityId = ((Integer)this.field_70180_af.func_187225_a(SPELL_TARGET)).intValue();
/* 103 */     if (entityId > 0) {
/* 104 */       return this.field_70170_p.func_73045_a(entityId);
/*     */     }
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSpellTarget(Entity entity) {
/* 111 */     if (entity == null) {
/* 112 */       this.field_70180_af.func_187227_b(SPELL_TARGET, Integer.valueOf(0));
/*     */     } else {
/* 114 */       this.field_70180_af.func_187227_b(SPELL_TARGET, Integer.valueOf(entity.func_145782_y()));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void func_70071_h_() {
/* 119 */     super.func_70071_h_();
/* 120 */     if (this.field_70170_p.field_72995_K && 
/* 121 */       isSpellcasting() && this.handParticleTick > 0) {
/* 122 */       double d0 = 0.7D;
/* 123 */       double d1 = 0.7D;
/* 124 */       double d2 = 0.7D;
/* 125 */       float f = this.field_70761_aq * 0.017453292F + MathHelper.func_76134_b(this.field_70173_aa * 0.6662F) * 0.25F;
/* 126 */       float f1 = MathHelper.func_76134_b(f);
/* 127 */       float f2 = MathHelper.func_76126_a(f);
/* 128 */       this.field_70170_p.func_175688_a(EnumParticleTypes.SPELL_MOB, this.field_70165_t + f1 * 0.6D, this.field_70163_u + 2.0D, this.field_70161_v + f2 * 0.6D, d0, d1, d2, new int[] { 0, 1, 1 });
/* 129 */       this.field_70170_p.func_175688_a(EnumParticleTypes.SPELL_MOB, this.field_70165_t - f1 * 0.6D, this.field_70163_u + 2.0D, this.field_70161_v - f2 * 0.6D, d0, d1, d2, new int[] { 0, 1, 1 });
/* 130 */       this.handParticleTick--;
/*     */       
/* 132 */       if (this.handParticleTick <= 4) {
/* 133 */         Entity spellTarget = getSpellTargetEntity();
/* 134 */         if (spellTarget != null)
/* 135 */           for (int i = 0; i < 20; i++) {
/* 136 */             double dx = func_70681_au().nextGaussian() * 0.5D;
/* 137 */             double dz = func_70681_au().nextGaussian() * 0.5D;
/* 138 */             this.field_70170_p.func_175688_a(EnumParticleTypes.VILLAGER_HAPPY, spellTarget.field_70165_t + dx, spellTarget.field_70163_u + func_70681_au().nextDouble() * 2.0D, spellTarget.field_70161_v + dz, 0.0D, 0.8D, 0.0D, new int[] { 0, 1, 1 });
/*     */           }  
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\entities\EntityCleric.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */