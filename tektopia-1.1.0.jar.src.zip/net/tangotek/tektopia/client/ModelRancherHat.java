/*    */ package net.tangotek.tektopia.client;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.client.model.ModelCraftStudio;
/*    */ import net.minecraft.client.model.ModelBiped;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class ModelRancherHat
/*    */   extends ModelBiped
/*    */ {
/*    */   private final ModelCraftStudio modelHat;
/*    */   
/*    */   public ModelRancherHat() {
/* 22 */     super(0.0F, 0.0F, 64, 64);
/* 23 */     this.modelHat = new ModelCraftStudio("tektopia", "rancher_hat", 64, 64);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_78088_a(Entity entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
/* 29 */     GlStateManager.func_179094_E();
/* 30 */     float rotateAngleY = netHeadYaw * 0.017453292F;
/* 31 */     float rotateAngleX = headPitch * 0.017453292F;
/*    */     
/* 33 */     if (entityIn.func_70093_af())
/*    */     {
/* 35 */       GlStateManager.func_179109_b(0.0F, 0.25F, 0.0F);
/*    */     }
/*    */     
/* 38 */     GlStateManager.func_179114_b(rotateAngleY * 57.295776F, 0.0F, 1.0F, 0.0F);
/* 39 */     GlStateManager.func_179114_b(rotateAngleX * 57.295776F, 1.0F, 0.0F, 0.0F);
/* 40 */     this.modelHat.render();
/* 41 */     GlStateManager.func_179121_F();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
/* 51 */     if (entityIn instanceof net.minecraft.entity.item.EntityArmorStand) {
/*    */       
/* 53 */       this.field_78116_c.field_78795_f = headPitch * 0.017453292F;
/* 54 */       this.field_78116_c.field_78796_g = netHeadYaw * 0.017453292F;
/*    */ 
/*    */       
/* 57 */       this.field_78116_c.func_78793_a(0.0F, 1.0F, 0.0F);
/* 58 */       func_178685_a(this.field_78116_c, this.field_178720_f);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\client\ModelRancherHat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */