/*     */ package net.tangotek.tektopia.client;
/*     */ 
/*     */ import net.minecraft.client.model.ModelSkeletonHead;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.client.registry.IRenderFactory;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.tangotek.tektopia.entities.EntitySpiritSkull;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class RenderSpiritSkull
/*     */   extends Render<EntitySpiritSkull> {
/*  17 */   private static final ResourceLocation SKULL_TEXTURE = new ResourceLocation("tektopia", "textures/entity/spirit_skull.png");
/*  18 */   public static final Factory FACTORY = new Factory<>();
/*     */ 
/*     */   
/*  21 */   private final ModelSkeletonHead skeletonHeadModel = new ModelSkeletonHead();
/*     */ 
/*     */   
/*     */   public RenderSpiritSkull(RenderManager renderManagerIn) {
/*  25 */     super(renderManagerIn);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private float getRenderYaw(float p_82400_1_, float p_82400_2_, float p_82400_3_) {
/*     */     float f;
/*  32 */     for (f = p_82400_2_ - p_82400_1_; f < -180.0F; f += 360.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  37 */     while (f >= 180.0F)
/*     */     {
/*  39 */       f -= 360.0F;
/*     */     }
/*     */     
/*  42 */     return p_82400_1_ + p_82400_3_ * f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doRender(EntitySpiritSkull entity, double x, double y, double z, float entityYaw, float partialTicks) {
/*  50 */     if (entity.func_82150_aj()) {
/*     */       return;
/*     */     }
/*  53 */     GlStateManager.func_179094_E();
/*  54 */     GlStateManager.func_179129_p();
/*  55 */     float f = getRenderYaw(entity.field_70126_B, entity.field_70177_z, partialTicks);
/*  56 */     float f1 = entity.field_70127_C + (entity.field_70125_A - entity.field_70127_C) * partialTicks;
/*  57 */     GlStateManager.func_179109_b((float)x, (float)y, (float)z);
/*     */     
/*  59 */     if (entity.getSkullMode() == EntitySpiritSkull.SkullMode.PROTECTING) {
/*  60 */       float radius = entity.getSpinRadius();
/*  61 */       float speed = entity.getSpinSpeed();
/*  62 */       float xAxis = entity.getSpinAxis();
/*  63 */       GlStateManager.func_179114_b((entity.field_70173_aa + partialTicks) * speed, xAxis, 1.0F, 0.0F);
/*  64 */       GlStateManager.func_179109_b(0.0F, 0.0F, radius);
/*     */     } 
/*     */     
/*  67 */     float f2 = 0.0625F;
/*  68 */     GlStateManager.func_179091_B();
/*  69 */     float scale = 0.6F;
/*  70 */     GlStateManager.func_179152_a(-scale, -scale, scale);
/*  71 */     GlStateManager.func_179141_d();
/*  72 */     func_180548_c((Entity)entity);
/*     */     
/*  74 */     if (this.field_188301_f) {
/*     */       
/*  76 */       GlStateManager.func_179142_g();
/*  77 */       GlStateManager.func_187431_e(func_188298_c((Entity)entity));
/*     */     } 
/*     */     
/*  80 */     this.skeletonHeadModel.func_78088_a((Entity)entity, 0.0F, 0.0F, 0.0F, f, f1, 0.0625F);
/*     */     
/*  82 */     if (this.field_188301_f) {
/*     */       
/*  84 */       GlStateManager.func_187417_n();
/*  85 */       GlStateManager.func_179119_h();
/*     */     } 
/*     */     
/*  88 */     GlStateManager.func_179121_F();
/*  89 */     super.func_76986_a((Entity)entity, x, y, z, entityYaw, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceLocation getEntityTexture(EntitySpiritSkull entity) {
/*  97 */     return SKULL_TEXTURE;
/*     */   }
/*     */   
/*     */   public static class Factory<T extends EntitySpiritSkull>
/*     */     implements IRenderFactory<T>
/*     */   {
/*     */     public Render<? super T> createRenderFor(RenderManager manager) {
/* 104 */       return new RenderSpiritSkull(manager);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\client\RenderSpiritSkull.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */