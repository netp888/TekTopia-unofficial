/*     */ package net.tangotek.tektopia.client;
/*     */ 
/*     */ import com.leviathanstudio.craftstudio.client.model.CSModelRenderer;
/*     */ import com.leviathanstudio.craftstudio.client.model.ModelCraftStudio;
/*     */ import com.leviathanstudio.craftstudio.client.util.MathHelper;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.model.ModelBook;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
/*     */ import net.minecraft.client.renderer.entity.RenderLivingBase;
/*     */ import net.minecraft.client.renderer.entity.layers.LayerRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.EnumHandSide;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.tangotek.tektopia.ModItems;
/*     */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class LayerVillagerHeldItem
/*     */   implements LayerRenderer<EntityLivingBase> {
/*     */   protected final RenderLivingBase<?> livingEntityRenderer;
/*  32 */   private static final ResourceLocation TEXTURE_BOOK = new ResourceLocation("textures/entity/enchanting_table_book.png");
/*  33 */   private final ModelBook modelBook = new ModelBook();
/*     */ 
/*     */ 
/*     */   
/*     */   public LayerVillagerHeldItem(RenderLivingBase<?> livingEntityRendererIn) {
/*  38 */     this.livingEntityRenderer = livingEntityRendererIn;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_177141_a(EntityLivingBase entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
/*  43 */     boolean flag = (entitylivingbaseIn.func_184591_cq() == EnumHandSide.RIGHT);
/*  44 */     ItemStack leftHandItem = flag ? entitylivingbaseIn.func_184592_cb() : entitylivingbaseIn.func_184614_ca();
/*  45 */     ItemStack rightHandItem = flag ? entitylivingbaseIn.func_184614_ca() : entitylivingbaseIn.func_184592_cb();
/*     */     
/*  47 */     boolean showLayer = true;
/*  48 */     if (entitylivingbaseIn instanceof EntityVillagerTek) {
/*  49 */       EntityVillagerTek villager = (EntityVillagerTek)entitylivingbaseIn;
/*     */       
/*  51 */       showLayer = !villager.isSleeping();
/*  52 */       if (!villager.getActionItem().func_190926_b()) {
/*  53 */         rightHandItem = villager.getActionItem();
/*  54 */         if (rightHandItem.func_77973_b() == ModItems.EMPTY_HAND_ITEM.func_77973_b()) {
/*  55 */           rightHandItem = ItemStack.field_190927_a;
/*     */         }
/*     */       } 
/*     */     } 
/*  59 */     if (showLayer && (
/*  60 */       !leftHandItem.func_190926_b() || !rightHandItem.func_190926_b())) {
/*  61 */       GlStateManager.func_179094_E();
/*     */       
/*  63 */       if ((this.livingEntityRenderer.func_177087_b()).field_78091_s) {
/*  64 */         float f = 0.5F;
/*  65 */         GlStateManager.func_179109_b(0.0F, 0.75F, 0.0F);
/*  66 */         GlStateManager.func_179152_a(0.5F, 0.5F, 0.5F);
/*     */       } 
/*     */       
/*  69 */       renderHeldItem(entitylivingbaseIn, rightHandItem, ItemCameraTransforms.TransformType.THIRD_PERSON_RIGHT_HAND, EnumHandSide.RIGHT, ageInTicks, scale);
/*  70 */       renderHeldItem(entitylivingbaseIn, leftHandItem, ItemCameraTransforms.TransformType.THIRD_PERSON_LEFT_HAND, EnumHandSide.LEFT, ageInTicks, scale);
/*  71 */       GlStateManager.func_179121_F();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderHeldItem(EntityLivingBase entity, ItemStack itemStack, ItemCameraTransforms.TransformType transformType, EnumHandSide handSide, float ageInTicks, float scale) {
/*  78 */     if (!itemStack.func_190926_b()) {
/*     */       
/*  80 */       GlStateManager.func_179094_E();
/*     */       
/*  82 */       if (entity.func_70093_af())
/*     */       {
/*  84 */         GlStateManager.func_179109_b(0.0F, 0.2F, 0.0F);
/*     */       }
/*     */       
/*  87 */       translateToHand(handSide, scale);
/*  88 */       GlStateManager.func_179114_b(-90.0F, 1.0F, 0.0F, 0.0F);
/*  89 */       GlStateManager.func_179114_b(180.0F, 0.0F, 1.0F, 0.0F);
/*  90 */       boolean flag = (handSide == EnumHandSide.LEFT);
/*     */       
/*  92 */       if (itemStack.func_77973_b() == Items.field_151122_aG) {
/*  93 */         renderBook(ageInTicks);
/*     */       } else {
/*  95 */         Minecraft.func_71410_x().func_175597_ag().func_187462_a(entity, itemStack, transformType, flag);
/*     */       } 
/*  97 */       GlStateManager.func_179121_F();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void translateToHand(EnumHandSide handSide, float scale) {
/* 103 */     ModelCraftStudio model = (ModelCraftStudio)this.livingEntityRenderer.func_177087_b();
/* 104 */     Deque<CSModelRenderer> stack = new ArrayDeque<>();
/* 105 */     for (CSModelRenderer parent : model.getParentBlocks()) {
/* 106 */       if (findChildChain("ArmRightWrist", parent, stack)) {
/* 107 */         stack.push(parent);
/*     */         
/* 109 */         while (!stack.isEmpty()) {
/* 110 */           CSModelRenderer modelRenderer = stack.pop();
/* 111 */           GlStateManager.func_179109_b(modelRenderer.field_78800_c * scale, modelRenderer.field_78797_d * scale, modelRenderer.field_78798_e * scale);
/* 112 */           FloatBuffer buf = MathHelper.makeFloatBuffer(modelRenderer.getRotationMatrix());
/* 113 */           GlStateManager.func_179110_a(buf);
/* 114 */           GlStateManager.func_179109_b(modelRenderer.field_82906_o * scale, modelRenderer.field_82908_p * scale, modelRenderer.field_82907_q * scale);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean findChildChain(String name, CSModelRenderer modelRenderer, Deque<CSModelRenderer> stack) {
/* 126 */     if (modelRenderer.field_78802_n.equals(name)) {
/* 127 */       return true;
/*     */     }
/* 129 */     if (modelRenderer.field_78805_m != null) {
/* 130 */       for (ModelRenderer child : modelRenderer.field_78805_m) {
/* 131 */         CSModelRenderer csModel = (CSModelRenderer)child;
/* 132 */         if (findChildChain(name, csModel, stack)) {
/* 133 */           stack.push(csModel);
/* 134 */           return true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 139 */     return false;
/*     */   }
/*     */   
/*     */   protected void renderBook(float ageInTicks) {
/* 143 */     GlStateManager.func_179094_E();
/*     */ 
/*     */ 
/*     */     
/* 147 */     float f = 25.5F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     GlStateManager.func_179114_b(90.0F, 0.0F, 0.0F, 1.0F);
/*     */     
/* 165 */     float rot = 80.0F;
/* 166 */     GlStateManager.func_179114_b(rot, 1.0F, 0.0F, 0.0F);
/* 167 */     GlStateManager.func_179114_b(40.0F, 0.0F, 0.0F, 1.0F);
/* 168 */     GlStateManager.func_179137_b(0.0D, -0.2D, -0.3D);
/* 169 */     this.livingEntityRenderer.func_110776_a(TEXTURE_BOOK);
/*     */ 
/*     */     
/* 172 */     float f3 = f + 0.25F;
/* 173 */     float f4 = f + 0.75F;
/*     */     
/* 175 */     f3 = (f3 - MathHelper.func_76140_b(f3)) * 1.6F - 0.3F;
/* 176 */     f4 = (f4 - MathHelper.func_76140_b(f4)) * 1.6F - 0.3F;
/*     */     
/* 178 */     if (f3 < 0.0F)
/*     */     {
/* 180 */       f3 = 0.0F;
/*     */     }
/*     */     
/* 183 */     if (f4 < 0.0F)
/*     */     {
/* 185 */       f4 = 0.0F;
/*     */     }
/*     */     
/* 188 */     if (f3 > 1.0F)
/*     */     {
/* 190 */       f3 = 1.0F;
/*     */     }
/*     */     
/* 193 */     if (f4 > 1.0F)
/*     */     {
/* 195 */       f4 = 1.0F;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 200 */     float f5 = 12.2F;
/* 201 */     GlStateManager.func_179089_o();
/* 202 */     this.modelBook.func_78088_a((Entity)null, 1500.0F, 0.17F, 0.9F, 1.0F, 0.0F, 0.0625F);
/* 203 */     GlStateManager.func_179121_F();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_177142_b() {
/* 210 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\client\LayerVillagerHeldItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */