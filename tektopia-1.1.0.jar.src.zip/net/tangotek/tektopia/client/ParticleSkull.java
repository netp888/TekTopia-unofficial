/*     */ package net.tangotek.tektopia.client;
/*     */ 
/*     */ import net.minecraft.client.particle.Particle;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.client.renderer.vertex.VertexFormat;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class ParticleSkull
/*     */   extends Particle
/*     */ {
/*  19 */   private static final ResourceLocation SAND_TEXTURE = new ResourceLocation("tektopia", "textures/particle/skull.png");
/*  20 */   private static final VertexFormat VERTEX_FORMAT = (new VertexFormat()).func_181721_a(DefaultVertexFormats.field_181713_m).func_181721_a(DefaultVertexFormats.field_181715_o).func_181721_a(DefaultVertexFormats.field_181714_n).func_181721_a(DefaultVertexFormats.field_181716_p).func_181721_a(DefaultVertexFormats.field_181717_q).func_181721_a(DefaultVertexFormats.field_181718_r);
/*     */   
/*     */   private int life;
/*     */   public double radius;
/*     */   public double radiusGrow;
/*     */   public double angle;
/*     */   public double torque;
/*     */   public int lifeTime;
/*     */   private final TextureManager textureManager;
/*     */   public final float size;
/*     */   private final Vec3d origin;
/*     */   
/*     */   public ParticleSkull(World world, TextureManager textureManagerIn, Vec3d pos, double motionY) {
/*  33 */     super(world, pos.field_72450_a, pos.field_72448_b, pos.field_72449_c, 0.0D, 0.0D, 0.0D);
/*  34 */     this.textureManager = textureManagerIn;
/*  35 */     float f = this.field_187136_p.nextFloat() * 0.4F + 0.6F;
/*  36 */     this.field_70552_h = f;
/*  37 */     this.field_70553_i = f;
/*  38 */     this.field_70551_j = f;
/*  39 */     this.size = 0.1F + (float)(Math.random() * 0.15000000596046448D);
/*  40 */     this.field_187130_j = motionY;
/*  41 */     this.origin = new Vec3d(this.field_187126_f, this.field_187127_g, this.field_187128_h);
/*     */     
/*  43 */     this.angle = Math.random() * 360.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_180434_a(BufferBuilder buffer, Entity entityIn, float partialTicks, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ) {
/*  55 */     this.textureManager.func_110577_a(SAND_TEXTURE);
/*  56 */     float f = 0.0F;
/*  57 */     float f1 = 1.0F;
/*  58 */     float f2 = 0.0F;
/*  59 */     float f3 = 1.0F;
/*     */     
/*  61 */     float f4 = this.size;
/*  62 */     float f5 = (float)(this.field_187123_c + (this.field_187126_f - this.field_187123_c) * partialTicks - field_70556_an);
/*  63 */     float f6 = (float)(this.field_187124_d + (this.field_187127_g - this.field_187124_d) * partialTicks - field_70554_ao);
/*  64 */     float f7 = (float)(this.field_187125_e + (this.field_187128_h - this.field_187125_e) * partialTicks - field_70555_ap);
/*  65 */     GlStateManager.func_179147_l();
/*     */     
/*  67 */     GlStateManager.func_187401_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/*     */     
/*  69 */     GlStateManager.func_179094_E();
/*     */ 
/*     */     
/*  72 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, (this.lifeTime - this.life) / this.lifeTime);
/*  73 */     GlStateManager.func_179140_f();
/*  74 */     RenderHelper.func_74518_a();
/*  75 */     buffer.func_181668_a(7, VERTEX_FORMAT);
/*  76 */     buffer.func_181662_b((f5 - rotationX * f4 - rotationXY * f4), (f6 - rotationZ * f4), (f7 - rotationYZ * f4 - rotationXZ * f4)).func_187315_a(f1, f3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, 1.0F).func_187314_a(0, 240).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  77 */     buffer.func_181662_b((f5 - rotationX * f4 + rotationXY * f4), (f6 + rotationZ * f4), (f7 - rotationYZ * f4 + rotationXZ * f4)).func_187315_a(f1, f2).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, 1.0F).func_187314_a(0, 240).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  78 */     buffer.func_181662_b((f5 + rotationX * f4 + rotationXY * f4), (f6 + rotationZ * f4), (f7 + rotationYZ * f4 + rotationXZ * f4)).func_187315_a(f, f2).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, 1.0F).func_187314_a(0, 240).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  79 */     buffer.func_181662_b((f5 + rotationX * f4 - rotationXY * f4), (f6 - rotationZ * f4), (f7 + rotationYZ * f4 - rotationXZ * f4)).func_187315_a(f, f3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, 1.0F).func_187314_a(0, 240).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  80 */     Tessellator.func_178181_a().func_78381_a();
/*  81 */     GlStateManager.func_179121_F();
/*  82 */     GlStateManager.func_179084_k();
/*     */     
/*  84 */     GlStateManager.func_179145_e();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_189213_a() {
/*  95 */     this.field_187123_c = this.field_187126_f;
/*  96 */     this.field_187124_d = this.field_187127_g;
/*  97 */     this.field_187125_e = this.field_187128_h;
/*  98 */     this.life++;
/*     */     
/* 100 */     updatePosition();
/*     */     
/* 102 */     if (this.life == this.lifeTime)
/*     */     {
/* 104 */       func_187112_i();
/*     */     }
/*     */   }
/*     */   
/*     */   private void updatePosition() {
/* 109 */     double x = this.origin.field_72450_a + Math.cos(this.angle) * this.radius;
/* 110 */     double z = this.origin.field_72449_c + Math.sin(this.angle) * this.radius;
/*     */     
/* 112 */     func_187109_b(x, this.field_187127_g + this.field_187130_j, z);
/*     */     
/* 114 */     this.radius += this.radiusGrow;
/* 115 */     this.angle += this.torque;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_70537_b() {
/* 124 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_187111_c() {
/* 129 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\client\ParticleSkull.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */