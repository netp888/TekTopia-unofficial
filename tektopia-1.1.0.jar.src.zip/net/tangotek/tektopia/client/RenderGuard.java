/*    */ package net.tangotek.tektopia.client;
/*    */ 
/*    */ import com.leviathanstudio.craftstudio.client.model.CSModelRenderer;
/*    */ import com.leviathanstudio.craftstudio.client.model.ModelCraftStudio;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import net.minecraft.client.renderer.entity.Render;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.inventory.EntityEquipmentSlot;
/*    */ import net.minecraft.item.ItemArmor;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.client.registry.IRenderFactory;
/*    */ import net.tangotek.tektopia.entities.EntityGuard;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderGuard<T extends EntityGuard>
/*    */   extends RenderVillager<T>
/*    */ {
/* 22 */   public static final Factory FACTORY = new Factory<>();
/*    */   
/*    */   public RenderGuard(RenderManager manager) {
/* 25 */     super(manager, "guard", false, 128, 64, "guard");
/*    */   }
/*    */ 
/*    */   
/*    */   private void updateArmorSlot(CSModelRenderer modelRenderer, EntityGuard entityGuard, String modelPrefix, EntityEquipmentSlot slot) {
/* 30 */     if (modelRenderer.field_78802_n.startsWith(modelPrefix)) {
/* 31 */       ItemStack itemStack = entityGuard.func_184582_a(slot);
/* 32 */       if (itemStack.func_77973_b() instanceof ItemArmor) {
/* 33 */         ItemArmor itemArmor = (ItemArmor)itemStack.func_77973_b();
/* 34 */         if (itemArmor.func_185083_B_() == slot) {
/* 35 */           String matName = itemArmor.func_82812_d().func_179242_c();
/* 36 */           String modelMat = modelRenderer.field_78802_n.substring(modelPrefix.length());
/* 37 */           modelRenderer.field_78806_j = modelMat.toLowerCase().startsWith(matName);
/* 38 */           if (modelRenderer.field_78806_j && 
/* 39 */             modelRenderer.field_78802_n.substring(modelPrefix.length() + matName.length()).startsWith("Capt")) {
/* 40 */             modelRenderer.field_78806_j = entityGuard.isCaptain();
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private void updateArmor(CSModelRenderer modelRenderer, EntityGuard entityGuard) {
/* 48 */     modelRenderer.field_78806_j = !modelRenderer.field_78802_n.startsWith("Armor");
/*    */     
/* 50 */     if (!entityGuard.isSleeping()) {
/* 51 */       updateArmorSlot(modelRenderer, entityGuard, "ArmorChest", EntityEquipmentSlot.CHEST);
/*    */       
/* 53 */       if (!modelRenderer.field_78806_j) {
/* 54 */         updateArmorSlot(modelRenderer, entityGuard, "ArmorLeg", EntityEquipmentSlot.LEGS);
/*    */       }
/* 56 */       if (!modelRenderer.field_78806_j) {
/* 57 */         updateArmorSlot(modelRenderer, entityGuard, "ArmorHead", EntityEquipmentSlot.HEAD);
/*    */       }
/* 59 */       if (!modelRenderer.field_78806_j) {
/* 60 */         updateArmorSlot(modelRenderer, entityGuard, "ArmorFeet", EntityEquipmentSlot.FEET);
/*    */       }
/*    */     } 
/* 63 */     if (modelRenderer.field_78805_m != null) {
/* 64 */       for (ModelRenderer child : modelRenderer.field_78805_m) {
/* 65 */         updateArmor((CSModelRenderer)child, entityGuard);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   protected void preRenderCallback(EntityGuard entityGuard, float partialTickTime) {
/* 72 */     ModelCraftStudio model = (ModelCraftStudio)func_177087_b();
/* 73 */     for (CSModelRenderer parent : model.getParentBlocks()) {
/* 74 */       updateArmor(parent, entityGuard);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class Factory<T extends EntityGuard>
/*    */     implements IRenderFactory<T>
/*    */   {
/*    */     public Render<? super T> createRenderFor(RenderManager manager) {
/* 82 */       return (Render)new RenderGuard<>(manager);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\client\RenderGuard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */