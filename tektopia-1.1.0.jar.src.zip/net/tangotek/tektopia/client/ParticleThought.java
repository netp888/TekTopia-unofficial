/*     */ package net.tangotek.tektopia.client;
/*     */ 
/*     */ import net.minecraft.client.particle.Particle;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.client.renderer.vertex.VertexFormat;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class ParticleThought
/*     */   extends Particle
/*     */ {
/*     */   private final ResourceLocation texture;
/*  27 */   private static final VertexFormat VERTEX_FORMAT = (new VertexFormat()).func_181721_a(DefaultVertexFormats.field_181713_m).func_181721_a(DefaultVertexFormats.field_181715_o).func_181721_a(DefaultVertexFormats.field_181714_n).func_181721_a(DefaultVertexFormats.field_181716_p).func_181721_a(DefaultVertexFormats.field_181717_q).func_181721_a(DefaultVertexFormats.field_181718_r);
/*     */   
/*     */   private final TextureManager textureManager;
/*     */   private int life;
/*     */   private final float scale;
/*     */   private final int lifeTime;
/*     */   private final Entity ent;
/*     */   
/*     */   public ParticleThought(World worldIn, TextureManager tm, Entity ent, float scale, String texture) {
/*  36 */     super(worldIn, ent.field_70165_t, ent.field_70163_u + 2.5D, ent.field_70161_v, 0.0D, 0.0D, 0.0D);
/*  37 */     this.texture = new ResourceLocation("tektopia:textures/particle/" + texture);
/*  38 */     this.textureManager = tm;
/*  39 */     this.ent = ent;
/*  40 */     this.lifeTime = 40;
/*  41 */     this.scale = scale;
/*  42 */     this.field_70552_h = 1.0F;
/*  43 */     this.field_70553_i = 1.0F;
/*  44 */     this.field_70551_j = 1.0F;
/*  45 */     this.field_187129_i = 0.0D;
/*  46 */     this.field_187130_j = 0.005D;
/*  47 */     this.field_187131_k = 0.0D;
/*  48 */     this.field_82339_as = 1.0F;
/*  49 */     this.field_190017_n = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_189213_a() {
/*  54 */     this.field_187127_g += this.field_187130_j;
/*     */     
/*  56 */     this.field_187123_c = this.field_187126_f;
/*  57 */     this.field_187124_d = this.field_187127_g;
/*  58 */     this.field_187125_e = this.field_187128_h;
/*  59 */     func_187110_a(this.ent.field_70165_t - this.field_187123_c, this.field_187130_j, this.ent.field_70161_v - this.field_187125_e);
/*  60 */     this.life++;
/*     */     
/*  62 */     if (this.life * 2 > this.lifeTime) {
/*  63 */       this.field_82339_as -= 2.0F / this.lifeTime;
/*     */       
/*  65 */       if (this.life == this.lifeTime) {
/*  66 */         func_187112_i();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_70537_b() {
/*  77 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_180434_a(BufferBuilder buffer, Entity entityIn, float partialTicks, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ) {
/*  85 */     this.textureManager.func_110577_a(this.texture);
/*  86 */     float f = 0.0F;
/*  87 */     float f1 = 1.0F;
/*  88 */     float f2 = 0.0F;
/*  89 */     float f3 = 1.0F;
/*     */     
/*  91 */     float f4 = 0.3F * this.scale;
/*  92 */     float f5 = (float)(this.field_187123_c + (this.field_187126_f - this.field_187123_c) * partialTicks - field_70556_an);
/*  93 */     float f6 = (float)(this.field_187124_d + (this.field_187127_g - this.field_187124_d) * partialTicks - field_70554_ao);
/*  94 */     float f7 = (float)(this.field_187125_e + (this.field_187128_h - this.field_187125_e) * partialTicks - field_70555_ap);
/*  95 */     GlStateManager.func_179094_E();
/*  96 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*  97 */     GlStateManager.func_179140_f();
/*  98 */     GlStateManager.func_179132_a(true);
/*  99 */     GlStateManager.func_179147_l();
/* 100 */     GlStateManager.func_179126_j();
/* 101 */     GlStateManager.func_187401_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/*     */ 
/*     */     
/* 104 */     buffer.func_181668_a(7, DefaultVertexFormats.field_181709_i);
/* 105 */     buffer.func_181662_b((f5 - rotationX * f4 - rotationXY * f4), (f6 - rotationZ * f4), (f7 - rotationYZ * f4 - rotationXZ * f4)).func_187315_a(f1, f3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, this.field_82339_as).func_181675_d();
/* 106 */     buffer.func_181662_b((f5 - rotationX * f4 + rotationXY * f4), (f6 + rotationZ * f4), (f7 - rotationYZ * f4 + rotationXZ * f4)).func_187315_a(f1, f2).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, this.field_82339_as).func_181675_d();
/* 107 */     buffer.func_181662_b((f5 + rotationX * f4 + rotationXY * f4), (f6 + rotationZ * f4), (f7 + rotationYZ * f4 + rotationXZ * f4)).func_187315_a(f, f2).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, this.field_82339_as).func_181675_d();
/* 108 */     buffer.func_181662_b((f5 + rotationX * f4 - rotationXY * f4), (f6 - rotationZ * f4), (f7 + rotationYZ * f4 - rotationXZ * f4)).func_187315_a(f, f3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, this.field_82339_as).func_181675_d();
/* 109 */     Tessellator.func_178181_a().func_78381_a();
/* 110 */     GlStateManager.func_179084_k();
/* 111 */     GlStateManager.func_179145_e();
/* 112 */     GlStateManager.func_179121_F();
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_189214_a(float p_189214_1_) {
/* 117 */     return 61680;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\client\ParticleThought.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */