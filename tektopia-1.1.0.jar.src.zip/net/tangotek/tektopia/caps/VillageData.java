/*     */ package net.tangotek.tektopia.caps;
/*     */ 
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.BlockPlanks;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.EnumDyeColor;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.tileentity.TileEntityChest;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.capabilities.Capability;
/*     */ import net.tangotek.tektopia.ItemTagType;
/*     */ import net.tangotek.tektopia.ModItems;
/*     */ import net.tangotek.tektopia.ProfessionType;
/*     */ import net.tangotek.tektopia.Village;
/*     */ import net.tangotek.tektopia.economy.ItemEconomy;
/*     */ import net.tangotek.tektopia.economy.ItemValue;
/*     */ 
/*     */ public class VillageData
/*     */   implements IVillageData, Capability.IStorage<IVillageData>
/*     */ {
/*  30 */   private long childSpawnTime = 0L;
/*  31 */   private int totalProfessionSales = 0;
/*     */   
/*     */   private boolean checkedMerchants = false;
/*     */   
/*     */   private boolean checkedNomads = false;
/*     */   private boolean startingGifts = false;
/*     */   private boolean isEmpty = true;
/*  38 */   protected ItemEconomy economy = new ItemEconomy();
/*  39 */   private UUID uuid = UUID.randomUUID();
/*     */ 
/*     */ 
/*     */   
/*     */   public void initEconomy() {
/*  44 */     if (this.economy.hasItems()) {
/*     */       return;
/*     */     }
/*  47 */     this.economy.addItem(new ItemValue(new ItemStack(Blocks.field_150364_r, 64, BlockPlanks.EnumType.JUNGLE.func_176839_a()), 4, 22, ProfessionType.LUMBERJACK));
/*  48 */     this.economy.addItem(new ItemValue(new ItemStack(Blocks.field_150364_r, 64, BlockPlanks.EnumType.BIRCH.func_176839_a()), 4, 22, ProfessionType.LUMBERJACK));
/*  49 */     this.economy.addItem(new ItemValue(new ItemStack(Blocks.field_150364_r, 64, BlockPlanks.EnumType.OAK.func_176839_a()), 4, 22, ProfessionType.LUMBERJACK));
/*  50 */     this.economy.addItem(new ItemValue(new ItemStack(Blocks.field_150364_r, 64, BlockPlanks.EnumType.SPRUCE.func_176839_a()), 4, 22, ProfessionType.LUMBERJACK));
/*     */     
/*  52 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151015_O, 64), 4, 20, ProfessionType.FARMER));
/*  53 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151174_bG, 64), 4, 20, ProfessionType.FARMER));
/*  54 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_185164_cV, 64), 4, 20, ProfessionType.FARMER));
/*  55 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151172_bF, 64), 4, 20, ProfessionType.FARMER));
/*     */ 
/*     */     
/*  58 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151025_P, 16), 8, 10, ProfessionType.CHEF));
/*     */ 
/*     */     
/*  61 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151105_aU, 1), 4, 5, ProfessionType.CHEF));
/*     */     
/*  63 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151157_am, 32), 10, 15, ProfessionType.CHEF));
/*  64 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151083_be, 32), 10, 15, ProfessionType.CHEF));
/*  65 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151077_bg, 32), 10, 15, ProfessionType.CHEF));
/*  66 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_179557_bn, 32), 10, 15, ProfessionType.CHEF));
/*  67 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151168_bH, 32), 4, 15, ProfessionType.CHEF));
/*     */     
/*  69 */     this.economy.addItem(new ItemValue(new ItemStack((Item)Items.field_151024_Q, 1), 2, 10, ProfessionType.BUTCHER));
/*  70 */     this.economy.addItem(new ItemValue(new ItemStack((Item)Items.field_151027_R, 1), 3, 10, ProfessionType.BUTCHER));
/*  71 */     this.economy.addItem(new ItemValue(new ItemStack((Item)Items.field_151026_S, 1), 3, 10, ProfessionType.BUTCHER));
/*  72 */     this.economy.addItem(new ItemValue(new ItemStack((Item)Items.field_151021_T, 1), 2, 10, ProfessionType.BUTCHER));
/*     */     
/*  74 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151110_aK, 16), 2, 20, ProfessionType.RANCHER));
/*  75 */     this.economy.addItem(new ItemValue(new ItemStack(Item.func_150898_a(Blocks.field_150325_L), 64), 7, 20, ProfessionType.RANCHER));
/*     */     
/*  77 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151137_ax, 64), 5, 20, ProfessionType.MINER));
/*  78 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151045_i, 4), 12, 10, ProfessionType.MINER));
/*  79 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151100_aR, 16, EnumDyeColor.BLUE.func_176767_b()), 5, 15, ProfessionType.MINER));
/*     */ 
/*     */     
/*  82 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151043_k, 16), 12, 10, ProfessionType.BLACKSMITH));
/*  83 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151035_b, 1), 5, 5, ProfessionType.BLACKSMITH));
/*  84 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151036_c, 1), 5, 5, ProfessionType.BLACKSMITH));
/*  85 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151040_l, 1), 4, 5, ProfessionType.BLACKSMITH));
/*  86 */     this.economy.addItem(new ItemValue(new ItemStack((Item)Items.field_151030_Z, 1), 10, 5, ProfessionType.BLACKSMITH));
/*  87 */     this.economy.addItem(new ItemValue(new ItemStack((Item)Items.field_151165_aa, 1), 9, 5, ProfessionType.BLACKSMITH));
/*  88 */     this.economy.addItem(new ItemValue(new ItemStack((Item)Items.field_151028_Y, 1), 7, 5, ProfessionType.BLACKSMITH));
/*  89 */     this.economy.addItem(new ItemValue(new ItemStack((Item)Items.field_151167_ab, 1), 6, 5, ProfessionType.BLACKSMITH));
/*  90 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151046_w, 1), 10, 5, ProfessionType.BLACKSMITH));
/*  91 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151056_x, 1), 10, 5, ProfessionType.BLACKSMITH));
/*  92 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151048_u, 1), 8, 5, ProfessionType.BLACKSMITH));
/*  93 */     this.economy.addItem(new ItemValue(new ItemStack((Item)Items.field_151163_ad, 1), 20, 5, ProfessionType.BLACKSMITH));
/*  94 */     this.economy.addItem(new ItemValue(new ItemStack((Item)Items.field_151173_ae, 1), 18, 5, ProfessionType.BLACKSMITH));
/*  95 */     this.economy.addItem(new ItemValue(new ItemStack((Item)Items.field_151161_ac, 1), 14, 5, ProfessionType.BLACKSMITH));
/*  96 */     this.economy.addItem(new ItemValue(new ItemStack((Item)Items.field_151175_af, 1), 12, 5, ProfessionType.BLACKSMITH));
/*     */     
/*  98 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151121_aF, 16), 3, 20, ProfessionType.ENCHANTER));
/*  99 */     this.economy.addItem(new ItemValue(new ItemStack(Items.field_151122_aG, 8), 8, 20, ProfessionType.ENCHANTER));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemEconomy getEconomy() {
/* 116 */     return this.economy;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNomadsCheckedToday(boolean checked) {
/* 121 */     this.checkedNomads = checked;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getNomadsCheckedToday() {
/* 126 */     return this.checkedNomads;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMerchantCheckedToday(boolean checked) {
/* 131 */     this.checkedMerchants = checked;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getMerchantCheckedToday() {
/* 136 */     return this.checkedMerchants;
/*     */   }
/*     */ 
/*     */   
/*     */   public UUID getUUID() {
/* 141 */     return this.uuid;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isChildReady(long totalWorldTime) {
/* 146 */     return (totalWorldTime > this.childSpawnTime);
/*     */   }
/*     */ 
/*     */   
/*     */   public void childSpawned(World w) {
/* 151 */     this.childSpawnTime = w.func_82737_E() + MathHelper.func_76136_a(w.field_73012_v, 20000, 30000);
/*     */   }
/*     */ 
/*     */   
/*     */   public void incrementProfessionSales() {
/* 156 */     this.totalProfessionSales++;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getProfessionSales() {
/* 161 */     return this.totalProfessionSales;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean completedStartingGifts() {
/* 166 */     return this.startingGifts;
/*     */   }
/*     */ 
/*     */   
/*     */   public void skipStartingGifts() {
/* 171 */     this.startingGifts = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void executeStartingGifts(World world, Village village, BlockPos pos) {
/* 176 */     this.startingGifts = true;
/*     */     
/* 178 */     world.func_175656_a(pos, Blocks.field_150486_ae.func_176223_P());
/* 179 */     TileEntity tileEntity = world.func_175625_s(pos);
/* 180 */     if (tileEntity instanceof TileEntityChest) {
/* 181 */       TileEntityChest chest = (TileEntityChest)tileEntity;
/* 182 */       addGiftItem(chest, village, (Item)ModItems.structureStorage, 12);
/* 183 */       addGiftItem(chest, village, (Item)ModItems.structureHome2, 13);
/* 184 */       addGiftItem(chest, village, (Item)ModItems.itemFarmer, 14);
/* 185 */       addGiftItem(chest, village, (Item)ModItems.itemLumberjack, 15);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addGiftItem(TileEntityChest chest, Village village, Item item, int slot) {
/* 190 */     ItemStack itemStack = ModItems.createTaggedItem(item, ItemTagType.VILLAGER);
/* 191 */     ModItems.bindItemToVillage(itemStack, village);
/* 192 */     chest.func_70299_a(slot, itemStack);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNBT(NBTTagCompound compound) {
/* 197 */     compound.func_186854_a("uuid", this.uuid);
/*     */     
/* 199 */     compound.func_74772_a("childTime", this.childSpawnTime);
/* 200 */     compound.func_74757_a("checkedMerchants", this.checkedMerchants);
/* 201 */     compound.func_74757_a("checkedNomads", this.checkedNomads);
/* 202 */     compound.func_74768_a("totalProfessionSales", this.totalProfessionSales);
/* 203 */     compound.func_74757_a("startingGifts", this.startingGifts);
/*     */ 
/*     */     
/* 206 */     if (this.economy != null) {
/* 207 */       this.economy.writeNBT(compound);
/*     */     }
/*     */   }
/*     */   
/*     */   public void readNBT(NBTTagCompound compound) {
/* 212 */     this.uuid = compound.func_186857_a("uuid");
/* 213 */     if (this.uuid.getLeastSignificantBits() == 0L && this.uuid.getMostSignificantBits() == 0L) {
/* 214 */       this.uuid = UUID.randomUUID();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 220 */     this.childSpawnTime = compound.func_74763_f("childTime");
/* 221 */     this.checkedMerchants = compound.func_74767_n("checkedMerchants");
/* 222 */     this.checkedNomads = compound.func_74767_n("checkedNomads");
/* 223 */     this.totalProfessionSales = compound.func_74762_e("totalProfessionSales");
/* 224 */     this.startingGifts = compound.func_74767_n("startingGifts");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 229 */     if (compound.func_74764_b("SalesHistory")) {
/* 230 */       initEconomy();
/* 231 */       getEconomy().readNBT(compound);
/*     */     } 
/*     */     
/* 234 */     this.isEmpty = false;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 238 */     return this.isEmpty;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public NBTBase writeNBT(Capability<IVillageData> capability, IVillageData instance, EnumFacing side) {
/* 244 */     NBTTagCompound compound = new NBTTagCompound();
/* 245 */     instance.writeNBT(compound);
/* 246 */     return (NBTBase)compound;
/*     */   }
/*     */ 
/*     */   
/*     */   public void readNBT(Capability<IVillageData> capability, IVillageData instance, EnumFacing side, NBTBase nbt) {
/* 251 */     if (nbt instanceof NBTTagCompound) {
/* 252 */       NBTTagCompound compound = (NBTTagCompound)nbt;
/* 253 */       instance.readNBT(compound);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\caps\VillageData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */