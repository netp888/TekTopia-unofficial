/*    */ package net.tangotek.tektopia.generation;
/*    */ import java.util.Random;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.item.EntityItemFrame;
/*    */ import net.minecraft.entity.passive.EntityVillager;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.gen.structure.MapGenStructureIO;
/*    */ import net.minecraft.world.gen.structure.StructureBoundingBox;
/*    */ import net.minecraftforge.fml.common.registry.VillagerRegistry;
/*    */ import net.tangotek.tektopia.ModItems;
/*    */ import net.tangotek.tektopia.entities.EntityBard;
/*    */ import net.tangotek.tektopia.entities.EntityBlacksmith;
/*    */ import net.tangotek.tektopia.entities.EntityCleric;
/*    */ import net.tangotek.tektopia.entities.EntityDruid;
/*    */ import net.tangotek.tektopia.entities.EntityFarmer;
/*    */ import net.tangotek.tektopia.entities.EntityGuard;
/*    */ import net.tangotek.tektopia.entities.EntityLumberjack;
/*    */ import net.tangotek.tektopia.entities.EntityNitwit;
/*    */ import net.tangotek.tektopia.entities.EntityVillagerTek;
/*    */ import net.tangotek.tektopia.structures.VillageStructureType;
/*    */ 
/*    */ public class TekStructureVillagePieces {
/*    */   public static void registerVillagePieces() {
/* 27 */     System.out.println("Registering Tek Village Structures");
/* 28 */     MapGenStructureIO.func_143031_a(TekTownHall.class, "TekTownHall");
/* 29 */     MapGenStructureIO.func_143031_a(TekStorageHall.class, "TekStorage");
/* 30 */     MapGenStructureIO.func_143031_a(TekHouse6.class, "TekHouse6");
/* 31 */     MapGenStructureIO.func_143031_a(TekHouse2.class, "TekHouse2");
/* 32 */     MapGenStructureIO.func_143031_a(TekHouse2b.class, "TekHouse2b");
/*    */ 
/*    */     
/* 35 */     VillagerRegistry.instance().registerVillageCreationHandler(new TekTownHallHandler());
/* 36 */     VillagerRegistry.instance().registerVillageCreationHandler(new TekStorageHallHandler());
/* 37 */     VillagerRegistry.instance().registerVillageCreationHandler(new TekHouse6Handler());
/* 38 */     VillagerRegistry.instance().registerVillageCreationHandler(new TekHouse2Handler());
/* 39 */     VillagerRegistry.instance().registerVillageCreationHandler(new TekHouse2bHandler());
/*    */   }
/*    */   
/*    */   public static EntityItemFrame addStructureFrame(World worldIn, StructureBoundingBox bbox, BlockPos doorPos, VillageStructureType structType) {
/* 43 */     EnumFacing facing = BlockDoor.func_176517_h((IBlockAccess)worldIn, doorPos).func_176734_d();
/* 44 */     BlockPos framePos = doorPos.func_177967_a(facing, 1).func_177967_a(facing.func_176746_e(), 1).func_177984_a();
/* 45 */     if (bbox.func_175898_b((Vec3i)framePos)) {
/* 46 */       EntityItemFrame itemFrame = new EntityItemFrame(worldIn, framePos, facing);
/* 47 */       itemFrame.func_82334_a(structType.itemStack);
/* 48 */       worldIn.func_72838_d((Entity)itemFrame);
/* 49 */       return itemFrame;
/*    */     } 
/*    */     
/* 52 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void replaceVillagers(World world, Random ran, double x1, double y1, double z1, double x2, double y2, double z2) {
/* 58 */     List<EntityVillager> villagerList = world.func_72872_a(EntityVillager.class, new AxisAlignedBB(x1, y1, z1, x2, y2, z2));
/* 59 */     for (EntityVillager vil : villagerList) {
/*    */       
/* 61 */       EntityVillagerTek newVillager = generateVillager(world, ran);
/* 62 */       newVillager.func_82149_j((Entity)vil);
/* 63 */       newVillager.func_180482_a(world.func_175649_E(newVillager.func_180425_c()), (IEntityLivingData)null);
/* 64 */       world.func_72838_d((Entity)newVillager);
/* 65 */       vil.func_70106_y();
/*    */     } 
/*    */   }
/*    */   public static EntityVillagerTek generateVillager(World world, Random ran) {
/*    */     EntityNitwit entityNitwit;
/* 70 */     int rnd = ran.nextInt(80);
/*    */     
/* 72 */     if (rnd < 40) {
/* 73 */       EntityFarmer entityFarmer = new EntityFarmer(world);
/*    */     }
/* 75 */     else if (rnd < 60) {
/* 76 */       EntityLumberjack entityLumberjack = new EntityLumberjack(world);
/* 77 */       entityLumberjack.getInventory().func_174894_a(ModItems.createTaggedItem(Items.field_151049_t, 1, ItemTagType.VILLAGER));
/*    */     }
/* 79 */     else if (rnd < 70) {
/* 80 */       EntityGuard entityGuard = new EntityGuard(world);
/* 81 */       entityGuard.getInventory().func_174894_a(ModItems.createTaggedItem(Items.field_151052_q, 1, ItemTagType.VILLAGER));
/*    */     }
/* 83 */     else if (rnd == 70) {
/* 84 */       EntityBard entityBard = new EntityBard(world);
/*    */     }
/* 86 */     else if (rnd == 71) {
/* 87 */       EntityCleric entityCleric = new EntityCleric(world);
/*    */     }
/* 89 */     else if (rnd == 72) {
/* 90 */       EntityBlacksmith entityBlacksmith = new EntityBlacksmith(world);
/*    */     }
/* 92 */     else if (rnd == 73) {
/* 93 */       EntityDruid entityDruid = new EntityDruid(world);
/*    */     } else {
/*    */       
/* 96 */       entityNitwit = new EntityNitwit(world);
/*    */     } 
/*    */     
/* 99 */     return (EntityVillagerTek)entityNitwit;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\generation\TekStructureVillagePieces.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */