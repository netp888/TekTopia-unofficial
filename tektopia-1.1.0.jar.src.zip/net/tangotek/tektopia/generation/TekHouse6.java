/*    */ package net.tangotek.tektopia.generation;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.BlockBed;
/*    */ import net.minecraft.block.BlockDoor;
/*    */ import net.minecraft.block.BlockFlowerPot;
/*    */ import net.minecraft.block.properties.IProperty;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.gen.structure.StructureBoundingBox;
/*    */ import net.minecraft.world.gen.structure.StructureVillagePieces;
/*    */ import net.tangotek.tektopia.ModBlocks;
/*    */ import net.tangotek.tektopia.structures.VillageStructureType;
/*    */ 
/*    */ public class TekHouse6 extends StructureVillagePieces.House3 {
/*    */   private int craftingIndex;
/*    */   private int villagersSpawned;
/*    */   
/*    */   public TekHouse6(StructureVillagePieces.Start start, int type, Random rand, StructureBoundingBox bbox, EnumFacing facing) {
/* 23 */     super(start, type, rand, bbox, facing);
/* 24 */     this.craftingIndex = rand.nextInt(4);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TekHouse6() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_74875_a(World worldIn, Random randomIn, StructureBoundingBox structureBoundingBoxIn) {
/* 34 */     boolean result = super.func_74875_a(worldIn, randomIn, structureBoundingBoxIn);
/*    */     
/* 36 */     if (!this.field_189929_i) {
/*    */       
/* 38 */       placeBedPiece(worldIn, structureBoundingBoxIn, 3, 1, 8, EnumFacing.NORTH, BlockBed.EnumPartType.FOOT);
/* 39 */       placeBedPiece(worldIn, structureBoundingBoxIn, 3, 1, 9, EnumFacing.NORTH, BlockBed.EnumPartType.HEAD);
/*    */       
/* 41 */       placeBedPiece(worldIn, structureBoundingBoxIn, 5, 1, 8, EnumFacing.NORTH, BlockBed.EnumPartType.FOOT);
/* 42 */       placeBedPiece(worldIn, structureBoundingBoxIn, 5, 1, 9, EnumFacing.NORTH, BlockBed.EnumPartType.HEAD);
/*    */       
/* 44 */       placeBedPiece(worldIn, structureBoundingBoxIn, 7, 1, 8, EnumFacing.NORTH, BlockBed.EnumPartType.FOOT);
/* 45 */       placeBedPiece(worldIn, structureBoundingBoxIn, 7, 1, 9, EnumFacing.NORTH, BlockBed.EnumPartType.HEAD);
/*    */       
/* 47 */       switch (this.craftingIndex) {
/*    */         case 0:
/* 49 */           func_175811_a(worldIn, Blocks.field_150462_ai.func_176223_P(), 4, 1, 9, structureBoundingBoxIn);
/* 50 */           func_175811_a(worldIn, Blocks.field_150457_bL.func_176223_P().func_177226_a((IProperty)BlockFlowerPot.field_176443_b, (Comparable)BlockFlowerPot.EnumFlowerType.MUSHROOM_RED), 4, 2, 9, structureBoundingBoxIn);
/*    */           break;
/*    */         case 1:
/* 53 */           func_175811_a(worldIn, Blocks.field_150462_ai.func_176223_P(), 6, 1, 9, structureBoundingBoxIn);
/*    */           break;
/*    */         case 2:
/* 56 */           func_175811_a(worldIn, Blocks.field_150462_ai.func_176223_P(), 7, 1, 4, structureBoundingBoxIn);
/* 57 */           func_175811_a(worldIn, Blocks.field_150457_bL.func_176223_P().func_177226_a((IProperty)BlockFlowerPot.field_176443_b, (Comparable)BlockFlowerPot.EnumFlowerType.MUSHROOM_RED), 7, 2, 4, structureBoundingBoxIn);
/*    */           break;
/*    */         case 3:
/* 60 */           func_175811_a(worldIn, Blocks.field_150462_ai.func_176223_P(), 7, 1, 2, structureBoundingBoxIn);
/*    */           break;
/*    */       } 
/*    */       
/* 64 */       if (randomIn.nextBoolean()) {
/* 65 */         func_175811_a(worldIn, ModBlocks.blockChair.func_176223_P().func_177226_a((IProperty)BlockDoor.field_176520_a, (Comparable)EnumFacing.SOUTH), 2, 1, 4, structureBoundingBoxIn);
/*    */       }
/* 67 */       if (randomIn.nextBoolean()) {
/* 68 */         func_175811_a(worldIn, ModBlocks.blockChair.func_176223_P().func_177226_a((IProperty)BlockDoor.field_176520_a, (Comparable)EnumFacing.NORTH), 4, 1, 1, structureBoundingBoxIn);
/*    */       }
/* 70 */       func_189926_a(worldIn, EnumFacing.WEST, 7, 1, 6, structureBoundingBoxIn);
/*    */ 
/*    */       
/* 73 */       placeBedPiece(worldIn, structureBoundingBoxIn, 6, 1, 5, EnumFacing.EAST, BlockBed.EnumPartType.FOOT);
/* 74 */       placeBedPiece(worldIn, structureBoundingBoxIn, 7, 1, 5, EnumFacing.EAST, BlockBed.EnumPartType.HEAD);
/*    */       
/* 76 */       placeBedPiece(worldIn, structureBoundingBoxIn, 6, 1, 3, EnumFacing.EAST, BlockBed.EnumPartType.FOOT);
/* 77 */       placeBedPiece(worldIn, structureBoundingBoxIn, 7, 1, 3, EnumFacing.EAST, BlockBed.EnumPartType.HEAD);
/*    */       
/* 79 */       placeBedPiece(worldIn, structureBoundingBoxIn, 6, 1, 1, EnumFacing.EAST, BlockBed.EnumPartType.FOOT);
/* 80 */       placeBedPiece(worldIn, structureBoundingBoxIn, 7, 1, 1, EnumFacing.EAST, BlockBed.EnumPartType.HEAD);
/*    */     } 
/* 82 */     return result;
/*    */   }
/*    */   
/*    */   public BlockPos getBlockPos(int x, int y, int z) {
/* 86 */     return new BlockPos(func_74865_a(x, z), func_74862_a(y), func_74873_b(x, z));
/*    */   }
/*    */ 
/*    */   
/*    */   protected void func_189927_a(World w, StructureBoundingBox bb, Random rand, int x, int y, int z, EnumFacing facing) {
/* 91 */     super.func_189927_a(w, bb, rand, x, y, z, facing);
/* 92 */     TekStructureVillagePieces.addStructureFrame(w, bb, getBlockPos(x, y, z), VillageStructureType.HOME6);
/*    */   }
/*    */   
/*    */   private void placeBedPiece(World worldIn, StructureBoundingBox bbox, int x, int y, int z, EnumFacing facing, BlockBed.EnumPartType partType) {
/* 96 */     func_175811_a(worldIn, Blocks.field_150350_a.func_176223_P(), x, y + 1, z, bbox);
/* 97 */     IBlockState bedState = Blocks.field_150324_C.func_176223_P().func_177226_a((IProperty)BlockBed.field_176471_b, Boolean.valueOf(false)).func_177226_a((IProperty)BlockBed.field_185512_D, (Comparable)facing);
/* 98 */     func_175811_a(worldIn, bedState.func_177226_a((IProperty)BlockBed.field_176472_a, (Comparable)partType), x, y, z, bbox);
/*    */   }
/*    */   
/*    */   protected void func_74893_a(World worldIn, StructureBoundingBox structurebb, int x, int y, int z, int count) {}
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\generation\TekHouse6.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */