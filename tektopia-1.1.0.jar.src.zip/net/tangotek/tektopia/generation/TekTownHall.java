/*    */ package net.tangotek.tektopia.generation;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.BlockDoor;
/*    */ import net.minecraft.block.properties.IProperty;
/*    */ import net.minecraft.entity.item.EntityItemFrame;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.gen.structure.StructureBoundingBox;
/*    */ import net.minecraft.world.gen.structure.StructureVillagePieces;
/*    */ import net.tangotek.tektopia.ModBlocks;
/*    */ import net.tangotek.tektopia.caps.IVillageData;
/*    */ import net.tangotek.tektopia.caps.VillageDataProvider;
/*    */ import net.tangotek.tektopia.structures.VillageStructureType;
/*    */ 
/*    */ public class TekTownHall
/*    */   extends StructureVillagePieces.House1 {
/*    */   public TekTownHall(StructureVillagePieces.Start start, int type, Random rand, StructureBoundingBox p_i45571_4_, EnumFacing facing) {
/* 21 */     super(start, type, rand, p_i45571_4_, facing);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TekTownHall() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_74875_a(World worldIn, Random randomIn, StructureBoundingBox structureBoundingBoxIn) {
/* 31 */     boolean result = super.func_74875_a(worldIn, randomIn, structureBoundingBoxIn);
/*    */ 
/*    */     
/* 34 */     if (!this.field_189929_i) {
/* 35 */       func_175811_a(worldIn, Blocks.field_150350_a.func_176223_P(), 6, 1, 4, structureBoundingBoxIn);
/* 36 */       func_175811_a(worldIn, Blocks.field_150350_a.func_176223_P(), 5, 1, 4, structureBoundingBoxIn);
/* 37 */       func_175811_a(worldIn, Blocks.field_150350_a.func_176223_P(), 4, 1, 4, structureBoundingBoxIn);
/* 38 */       func_175811_a(worldIn, Blocks.field_150350_a.func_176223_P(), 3, 1, 4, structureBoundingBoxIn);
/*    */       
/* 40 */       func_175811_a(worldIn, Blocks.field_150350_a.func_176223_P(), 7, 1, 4, structureBoundingBoxIn);
/* 41 */       func_175811_a(worldIn, Blocks.field_150350_a.func_176223_P(), 7, 1, 3, structureBoundingBoxIn);
/* 42 */       func_175811_a(worldIn, Blocks.field_150350_a.func_176223_P(), 7, 1, 2, structureBoundingBoxIn);
/*    */       
/* 44 */       func_175811_a(worldIn, ModBlocks.blockChair.func_176223_P().func_177226_a((IProperty)BlockDoor.field_176520_a, (Comparable)EnumFacing.WEST), 7, 1, 3, structureBoundingBoxIn);
/*    */       
/* 46 */       func_175811_a(worldIn, ModBlocks.blockChair.func_176223_P().func_177226_a((IProperty)BlockDoor.field_176520_a, (Comparable)EnumFacing.SOUTH), 4, 1, 4, structureBoundingBoxIn);
/*    */     } 
/* 48 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_74893_a(World worldIn, StructureBoundingBox structurebb, int x, int y, int z, int count) {}
/*    */ 
/*    */   
/*    */   public BlockPos getBlockPos(int x, int y, int z) {
/* 57 */     return new BlockPos(func_74865_a(x, z), func_74862_a(y), func_74873_b(x, z));
/*    */   }
/*    */ 
/*    */   
/*    */   protected void func_189927_a(World w, StructureBoundingBox bb, Random rand, int x, int y, int z, EnumFacing facing) {
/* 62 */     super.func_189927_a(w, bb, rand, x, y, z, facing);
/* 63 */     EntityItemFrame itemFrame = TekStructureVillagePieces.addStructureFrame(w, bb, getBlockPos(x, y, z), VillageStructureType.TOWNHALL);
/* 64 */     if (itemFrame != null) {
/* 65 */       IVillageData vd = (IVillageData)itemFrame.func_82335_i().getCapability(VillageDataProvider.VILLAGE_DATA_CAPABILITY, null);
/* 66 */       if (vd != null)
/* 67 */         vd.skipStartingGifts(); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\generation\TekTownHall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */