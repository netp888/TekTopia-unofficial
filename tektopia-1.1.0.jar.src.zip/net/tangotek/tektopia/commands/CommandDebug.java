/*    */ package net.tangotek.tektopia.commands;
/*    */ 
/*    */ import net.minecraft.command.CommandException;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.command.WrongUsageException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.tangotek.tektopia.VillageManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CommandDebug
/*    */   extends CommandVillageBase
/*    */ {
/*    */   public CommandDebug() {
/* 18 */     super("debug");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
/* 27 */     boolean enable = false;
/* 28 */     if (args.length != 1)
/*    */     {
/* 30 */       throw new WrongUsageException("commands.village.debug.usage", new Object[0]);
/*    */     }
/*    */ 
/*    */     
/* 34 */     enable = Boolean.parseBoolean(args[0]);
/* 35 */     EntityPlayerMP entityPlayerMP = func_71521_c(sender);
/* 36 */     VillageManager.get(((EntityPlayer)entityPlayerMP).field_70170_p).setDebugOn(enable);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\commands\CommandDebug.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */