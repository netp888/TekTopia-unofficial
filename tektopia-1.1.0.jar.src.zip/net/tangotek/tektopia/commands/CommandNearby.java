/*    */ package net.tangotek.tektopia.commands;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.command.CommandException;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.command.WrongUsageException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.tangotek.tektopia.Village;
/*    */ import net.tangotek.tektopia.VillageManager;
/*    */ 
/*    */ class CommandNearby
/*    */   extends CommandVillageBase
/*    */ {
/*    */   public CommandNearby() {
/* 19 */     super("nearby");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
/* 28 */     if (args.length > 0)
/*    */     {
/* 30 */       throw new WrongUsageException("commands.village.nearby.usage", new Object[0]);
/*    */     }
/*    */ 
/*    */     
/* 34 */     EntityPlayerMP entityPlayerMP = func_71521_c(sender);
/* 35 */     Integer range = Integer.valueOf(360);
/* 36 */     List<Village> villages = VillageManager.get(((EntityPlayer)entityPlayerMP).field_70170_p).getVillagesNear(entityPlayerMP.func_180425_c(), range.intValue());
/* 37 */     if (villages.isEmpty()) {
/* 38 */       func_152373_a(sender, (ICommand)this, "commands.nearby.none", new Object[] { range });
/*    */     } else {
/*    */       
/* 41 */       BlockPos p = entityPlayerMP.func_180425_c();
/* 42 */       villages.stream().forEach(v -> func_152373_a(sender, (ICommand)this, "commands.nearby.set", new Object[] { range, v.getOrigin(), Double.valueOf(v.getOrigin().func_185332_f(p.func_177958_n(), p.func_177956_o(), p.func_177952_p())) }));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\commands\CommandNearby.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */