/*    */ package net.tangotek.tektopia.pathing;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import net.minecraft.client.multiplayer.WorldClient;
/*    */ import net.minecraft.client.renderer.BufferBuilder;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*    */ import net.minecraft.util.math.ChunkPos;
/*    */ import net.minecraftforge.client.event.RenderWorldLastEvent;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathingOverlayRenderer
/*    */ {
/* 25 */   private Map<ChunkPos, PathingOverlayChunk> chunks = new HashMap<>();
/*    */   private boolean enabled = false;
/*    */   
/*    */   public PathingOverlayRenderer() {
/* 29 */     MinecraftForge.EVENT_BUS.register(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public void handleNodeUpdate(PathingNodeClient node) {
/* 34 */     this.enabled = (node != null);
/* 35 */     if (this.enabled) {
/* 36 */       ChunkPos chunkPos = new ChunkPos(node.pos);
/* 37 */       PathingOverlayChunk overlayChunk = this.chunks.get(chunkPos);
/* 38 */       if (overlayChunk == null) {
/* 39 */         overlayChunk = new PathingOverlayChunk(chunkPos);
/* 40 */         this.chunks.put(chunkPos, overlayChunk);
/*    */       } 
/*    */       
/* 43 */       overlayChunk.putNode(node);
/*    */     } else {
/*    */       
/* 46 */       this.chunks.clear();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void renderOverlays(RenderWorldLastEvent event) {
/* 54 */     if (!this.enabled) {
/*    */       return;
/*    */     }
/*    */     
/* 58 */     Minecraft minecraft = Minecraft.func_71410_x();
/* 59 */     WorldClient world = minecraft.field_71441_e;
/* 60 */     EntityPlayerSP player = minecraft.field_71439_g;
/* 61 */     if (world == null || player == null) {
/*    */       return;
/*    */     }
/*    */     
/* 65 */     double partialTicks = event.getPartialTicks();
/* 66 */     double viewX = player.field_70142_S + (player.field_70165_t - player.field_70142_S) * partialTicks;
/* 67 */     double viewY = player.field_70137_T + (player.field_70163_u - player.field_70137_T) * partialTicks;
/* 68 */     double viewZ = player.field_70136_U + (player.field_70161_v - player.field_70136_U) * partialTicks;
/*    */     
/* 70 */     GlStateManager.func_179094_E();
/* 71 */     GlStateManager.func_179090_x();
/* 72 */     GlStateManager.func_179141_d();
/* 73 */     GlStateManager.func_179147_l();
/* 74 */     BufferBuilder vertexBuffer = Tessellator.func_178181_a().func_178180_c();
/* 75 */     vertexBuffer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
/* 76 */     vertexBuffer.func_178969_c(-viewX, -viewY, -viewZ);
/*    */     
/* 78 */     renderOverlays(world, vertexBuffer, viewX, viewY, viewZ);
/*    */     
/* 80 */     vertexBuffer.func_178969_c(0.0D, 0.0D, 0.0D);
/* 81 */     Tessellator.func_178181_a().func_78381_a();
/*    */     
/* 83 */     GlStateManager.func_179098_w();
/* 84 */     GlStateManager.func_179121_F();
/*    */   }
/*    */   
/*    */   private void renderOverlays(WorldClient world, BufferBuilder vertexBuffer, double viewX, double viewY, double viewZ) {
/* 88 */     this.chunks.values().forEach(c -> c.renderOverlays(world, vertexBuffer, viewX, viewY, viewZ));
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\pathing\PathingOverlayRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */