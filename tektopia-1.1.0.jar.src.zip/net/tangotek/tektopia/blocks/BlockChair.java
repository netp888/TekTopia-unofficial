/*     */ package net.tangotek.tektopia.blocks;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockHorizontal;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.properties.PropertyDirection;
/*     */ import net.minecraft.block.state.BlockFaceShape;
/*     */ import net.minecraft.block.state.BlockStateContainer;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.util.BlockRenderLayer;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.Mirror;
/*     */ import net.minecraft.util.Rotation;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import net.tangotek.tektopia.TekVillager;
/*     */ 
/*     */ public class BlockChair extends BlockHorizontal {
/*  29 */   public static final PropertyDirection FACING = BlockHorizontal.field_185512_D;
/*     */   
/*     */   protected String name;
/*  32 */   protected static final AxisAlignedBB CHAIR_AABB = new AxisAlignedBB(0.25D, 0.0D, 0.25D, 0.75D, 0.45D, 0.75D);
/*     */   
/*     */   public BlockChair(String name) {
/*  35 */     super(Material.field_151594_q);
/*  36 */     this.name = name;
/*     */     
/*  38 */     func_149663_c(name);
/*  39 */     setRegistryName(name);
/*  40 */     func_149647_a(CreativeTabs.field_78031_c);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB func_185496_a(IBlockState state, IBlockAccess source, BlockPos pos) {
/*  46 */     return CHAIR_AABB;
/*     */   }
/*     */   
/*     */   public void registerItemModel(Item itemBlock) {
/*  50 */     TekVillager.proxy.registerItemRenderer(itemBlock, 0, this.name);
/*     */   }
/*     */   
/*     */   public Item createItemBlock() {
/*  54 */     return (Item)(new ItemBlock((Block)this)).setRegistryName(getRegistryName());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149662_c(IBlockState state) {
/*  59 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public AxisAlignedBB func_180646_a(IBlockState blockState, IBlockAccess worldIn, BlockPos pos) {
/*  65 */     return field_185506_k;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_176205_b(IBlockAccess worldIn, BlockPos pos) {
/*  70 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149686_d(IBlockState state) {
/*  75 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_176196_c(World worldIn, BlockPos pos) {
/*  80 */     IBlockState downState = worldIn.func_180495_p(pos.func_177977_b());
/*  81 */     return (super.func_176196_c(worldIn, pos) && (downState.func_185896_q() || downState.func_193401_d((IBlockAccess)worldIn, pos.func_177977_b(), EnumFacing.UP) == BlockFaceShape.SOLID));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_180642_a(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
/*  90 */     return func_176223_P().func_177226_a((IProperty)FACING, (Comparable)placer.func_174811_aO().func_176734_d());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_176203_a(int meta) {
/*  98 */     EnumFacing enumfacing = EnumFacing.func_82600_a(meta);
/*     */     
/* 100 */     if (enumfacing.func_176740_k() == EnumFacing.Axis.Y)
/*     */     {
/* 102 */       enumfacing = EnumFacing.NORTH;
/*     */     }
/*     */     
/* 105 */     return func_176223_P().func_177226_a((IProperty)FACING, (Comparable)enumfacing);
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public BlockRenderLayer func_180664_k() {
/* 111 */     return BlockRenderLayer.CUTOUT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_176201_c(IBlockState state) {
/* 119 */     return ((EnumFacing)state.func_177229_b((IProperty)FACING)).func_176745_a();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_185499_a(IBlockState state, Rotation rot) {
/* 128 */     return state.func_177226_a((IProperty)FACING, (Comparable)rot.func_185831_a((EnumFacing)state.func_177229_b((IProperty)FACING)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_185471_a(IBlockState state, Mirror mirrorIn) {
/* 137 */     return state.func_185907_a(mirrorIn.func_185800_a((EnumFacing)state.func_177229_b((IProperty)FACING)));
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockStateContainer func_180661_e() {
/* 142 */     return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)FACING });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockFaceShape func_193383_a(IBlockAccess worldIn, IBlockState state, BlockPos pos, EnumFacing face) {
/* 156 */     return BlockFaceShape.UNDEFINED;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\tektopia-1.1.0.jar!\net\tangotek\tektopia\blocks\BlockChair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */